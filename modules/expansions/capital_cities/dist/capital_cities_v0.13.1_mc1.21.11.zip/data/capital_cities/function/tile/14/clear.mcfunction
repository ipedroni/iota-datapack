fill 320 81 160 399 84 239 minecraft:air
fill 320 85 160 399 88 239 minecraft:air
fill 320 89 160 399 92 239 minecraft:air
fill 320 93 160 399 96 239 minecraft:air
fill 320 97 160 399 100 239 minecraft:air
fill 320 101 160 399 104 239 minecraft:air
fill 320 105 160 399 108 239 minecraft:air
fill 320 109 160 399 112 239 minecraft:air
fill 320 113 160 399 116 239 minecraft:air
fill 320 117 160 399 120 239 minecraft:air
fill 320 121 160 399 124 239 minecraft:air
fill 320 70 160 399 73 239 minecraft:stone
fill 320 74 160 399 77 239 minecraft:stone
fill 320 78 160 399 79 239 minecraft:dirt
fill 320 80 160 399 80 239 minecraft:grass_block
kill @e[type=!minecraft:player,x=320,y=70,z=160,dx=79,dy=54,dz=79]
