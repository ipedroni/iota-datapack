forceload add 0 160 79 239
scoreboard players set #loading cc_400 1
