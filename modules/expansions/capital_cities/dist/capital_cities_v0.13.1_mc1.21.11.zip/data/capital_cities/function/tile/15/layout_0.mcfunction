fill 78 80 240 79 80 240 minecraft:dirt
fill 78 80 241 79 80 241 minecraft:dirt
fill 78 80 242 79 80 242 minecraft:dirt
fill 79 80 243 79 80 243 minecraft:cobblestone
fill 79 80 244 79 80 244 minecraft:dirt
fill 79 80 245 79 80 245 minecraft:gravel
fill 79 80 246 79 80 246 minecraft:dirt
fill 79 80 247 79 80 247 minecraft:dirt
