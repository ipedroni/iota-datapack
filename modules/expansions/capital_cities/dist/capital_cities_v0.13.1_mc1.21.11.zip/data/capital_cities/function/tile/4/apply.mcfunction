execute if score #state cc_400 matches 1 run function capital_cities:tile/4/build
execute if score #state cc_400 matches 3 run function capital_cities:tile/4/clear
forceload remove 320 0 399 79
scoreboard players set #loading cc_400 0
scoreboard players add #tile cc_400 1
