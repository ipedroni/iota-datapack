fill 0 81 0 79 84 79 minecraft:air
fill 0 85 0 79 88 79 minecraft:air
fill 0 89 0 79 92 79 minecraft:air
fill 0 93 0 79 96 79 minecraft:air
fill 0 97 0 79 100 79 minecraft:air
fill 0 101 0 79 104 79 minecraft:air
fill 0 105 0 79 108 79 minecraft:air
fill 0 109 0 79 112 79 minecraft:air
fill 0 113 0 79 116 79 minecraft:air
fill 0 117 0 79 120 79 minecraft:air
fill 0 121 0 79 124 79 minecraft:air
fill 0 70 0 79 73 79 minecraft:stone
fill 0 74 0 79 77 79 minecraft:stone
fill 0 78 0 79 79 79 minecraft:dirt
fill 0 80 0 79 80 79 minecraft:grass_block
kill @e[type=!minecraft:player,x=0,y=70,z=0,dx=79,dy=54,dz=79]
