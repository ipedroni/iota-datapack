fill 240 81 240 319 84 319 minecraft:air
fill 240 85 240 319 88 319 minecraft:air
fill 240 89 240 319 92 319 minecraft:air
fill 240 93 240 319 96 319 minecraft:air
fill 240 97 240 319 100 319 minecraft:air
fill 240 101 240 319 104 319 minecraft:air
fill 240 105 240 319 108 319 minecraft:air
fill 240 109 240 319 112 319 minecraft:air
fill 240 113 240 319 116 319 minecraft:air
fill 240 117 240 319 120 319 minecraft:air
fill 240 121 240 319 124 319 minecraft:air
fill 240 70 240 319 73 319 minecraft:stone
fill 240 74 240 319 77 319 minecraft:stone
fill 240 78 240 319 79 319 minecraft:dirt
fill 240 80 240 319 80 319 minecraft:grass_block
kill @e[type=!minecraft:player,x=240,y=70,z=240,dx=79,dy=54,dz=79]
