fill 0 81 80 79 84 159 minecraft:air
fill 0 85 80 79 88 159 minecraft:air
fill 0 89 80 79 92 159 minecraft:air
fill 0 93 80 79 96 159 minecraft:air
fill 0 97 80 79 100 159 minecraft:air
fill 0 101 80 79 104 159 minecraft:air
fill 0 105 80 79 108 159 minecraft:air
fill 0 109 80 79 112 159 minecraft:air
fill 0 113 80 79 116 159 minecraft:air
fill 0 117 80 79 120 159 minecraft:air
fill 0 121 80 79 124 159 minecraft:air
fill 0 70 80 79 73 159 minecraft:stone
fill 0 74 80 79 77 159 minecraft:stone
fill 0 78 80 79 79 159 minecraft:dirt
fill 0 80 80 79 80 159 minecraft:grass_block
kill @e[type=!minecraft:player,x=0,y=70,z=80,dx=79,dy=54,dz=79]
