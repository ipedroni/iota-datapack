forceload add 320 160 399 239
scoreboard players set #loading cc_400 1
