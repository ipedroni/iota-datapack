forceload add 160 160 239 239
scoreboard players set #loading cc_400 1
