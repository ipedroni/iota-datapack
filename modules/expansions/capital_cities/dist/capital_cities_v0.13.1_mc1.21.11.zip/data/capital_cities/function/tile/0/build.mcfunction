execute if score #layout cc_400 matches 0 run function capital_cities:tile/0/layout_0
execute if score #layout cc_400 matches 1 run function capital_cities:tile/0/layout_1
execute if score #layout cc_400 matches 2 run function capital_cities:tile/0/layout_2
execute if score #layout cc_400 matches 3 run function capital_cities:tile/0/layout_3
