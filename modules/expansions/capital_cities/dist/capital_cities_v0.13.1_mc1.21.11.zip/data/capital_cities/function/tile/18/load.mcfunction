forceload add 240 240 319 319
scoreboard players set #loading cc_400 1
