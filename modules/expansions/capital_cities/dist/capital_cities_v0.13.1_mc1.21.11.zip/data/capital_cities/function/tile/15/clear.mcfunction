fill 0 81 240 79 84 319 minecraft:air
fill 0 85 240 79 88 319 minecraft:air
fill 0 89 240 79 92 319 minecraft:air
fill 0 93 240 79 96 319 minecraft:air
fill 0 97 240 79 100 319 minecraft:air
fill 0 101 240 79 104 319 minecraft:air
fill 0 105 240 79 108 319 minecraft:air
fill 0 109 240 79 112 319 minecraft:air
fill 0 113 240 79 116 319 minecraft:air
fill 0 117 240 79 120 319 minecraft:air
fill 0 121 240 79 124 319 minecraft:air
fill 0 70 240 79 73 319 minecraft:stone
fill 0 74 240 79 77 319 minecraft:stone
fill 0 78 240 79 79 319 minecraft:dirt
fill 0 80 240 79 80 319 minecraft:grass_block
kill @e[type=!minecraft:player,x=0,y=70,z=240,dx=79,dy=54,dz=79]
