fill 240 81 0 319 84 79 minecraft:air
fill 240 85 0 319 88 79 minecraft:air
fill 240 89 0 319 92 79 minecraft:air
fill 240 93 0 319 96 79 minecraft:air
fill 240 97 0 319 100 79 minecraft:air
fill 240 101 0 319 104 79 minecraft:air
fill 240 105 0 319 108 79 minecraft:air
fill 240 109 0 319 112 79 minecraft:air
fill 240 113 0 319 116 79 minecraft:air
fill 240 117 0 319 120 79 minecraft:air
fill 240 121 0 319 124 79 minecraft:air
fill 240 70 0 319 73 79 minecraft:stone
fill 240 74 0 319 77 79 minecraft:stone
fill 240 78 0 319 79 79 minecraft:dirt
fill 240 80 0 319 80 79 minecraft:grass_block
kill @e[type=!minecraft:player,x=240,y=70,z=0,dx=79,dy=54,dz=79]
