fill 80 81 0 159 84 79 minecraft:air
fill 80 85 0 159 88 79 minecraft:air
fill 80 89 0 159 92 79 minecraft:air
fill 80 93 0 159 96 79 minecraft:air
fill 80 97 0 159 100 79 minecraft:air
fill 80 101 0 159 104 79 minecraft:air
fill 80 105 0 159 108 79 minecraft:air
fill 80 109 0 159 112 79 minecraft:air
fill 80 113 0 159 116 79 minecraft:air
fill 80 117 0 159 120 79 minecraft:air
fill 80 121 0 159 124 79 minecraft:air
fill 80 70 0 159 73 79 minecraft:stone
fill 80 74 0 159 77 79 minecraft:stone
fill 80 78 0 159 79 79 minecraft:dirt
fill 80 80 0 159 80 79 minecraft:grass_block
kill @e[type=!minecraft:player,x=80,y=70,z=0,dx=79,dy=54,dz=79]
