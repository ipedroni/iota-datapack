forceload add 320 240 399 319
scoreboard players set #loading cc_400 1
