forceload add 160 320 239 399
scoreboard players set #loading cc_400 1
