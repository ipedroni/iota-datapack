scoreboard players set #occupied cc_400 0
execute as @a at @s if dimension capital_cities:settlement_400 run scoreboard players set #occupied cc_400 1
execute if score #occupied cc_400 matches 1 run return run tellraw @s "Todos devem sair da capital antes do reset."
execute unless score #state cc_400 matches 2 run return run tellraw @s "O reset exige uma capital pronta. Consulte /function capital_cities:status."
tag @s add cc13_reset
scoreboard players set #tile cc_400 0
scoreboard players set #loading cc_400 0
scoreboard players set #state cc_400 3
tellraw @s "Limpando a planta da assentamento 0.13."
