forceload add 320 320 399 399
scoreboard players set #loading cc_400 1
