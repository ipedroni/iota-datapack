forceload add 240 0 319 79
scoreboard players set #loading cc_400 1
