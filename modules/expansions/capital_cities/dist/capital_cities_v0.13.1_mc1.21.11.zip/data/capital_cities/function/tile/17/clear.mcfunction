fill 160 81 240 239 84 319 minecraft:air
fill 160 85 240 239 88 319 minecraft:air
fill 160 89 240 239 92 319 minecraft:air
fill 160 93 240 239 96 319 minecraft:air
fill 160 97 240 239 100 319 minecraft:air
fill 160 101 240 239 104 319 minecraft:air
fill 160 105 240 239 108 319 minecraft:air
fill 160 109 240 239 112 319 minecraft:air
fill 160 113 240 239 116 319 minecraft:air
fill 160 117 240 239 120 319 minecraft:air
fill 160 121 240 239 124 319 minecraft:air
fill 160 70 240 239 73 319 minecraft:stone
fill 160 74 240 239 77 319 minecraft:stone
fill 160 78 240 239 79 319 minecraft:dirt
fill 160 80 240 239 80 319 minecraft:grass_block
kill @e[type=!minecraft:player,x=160,y=70,z=240,dx=79,dy=54,dz=79]
