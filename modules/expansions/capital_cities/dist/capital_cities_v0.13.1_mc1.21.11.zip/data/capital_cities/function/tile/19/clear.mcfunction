fill 320 81 240 399 84 319 minecraft:air
fill 320 85 240 399 88 319 minecraft:air
fill 320 89 240 399 92 319 minecraft:air
fill 320 93 240 399 96 319 minecraft:air
fill 320 97 240 399 100 319 minecraft:air
fill 320 101 240 399 104 319 minecraft:air
fill 320 105 240 399 108 319 minecraft:air
fill 320 109 240 399 112 319 minecraft:air
fill 320 113 240 399 116 319 minecraft:air
fill 320 117 240 399 120 319 minecraft:air
fill 320 121 240 399 124 319 minecraft:air
fill 320 70 240 399 73 319 minecraft:stone
fill 320 74 240 399 77 319 minecraft:stone
fill 320 78 240 399 79 319 minecraft:dirt
fill 320 80 240 399 80 319 minecraft:grass_block
kill @e[type=!minecraft:player,x=320,y=70,z=240,dx=79,dy=54,dz=79]
