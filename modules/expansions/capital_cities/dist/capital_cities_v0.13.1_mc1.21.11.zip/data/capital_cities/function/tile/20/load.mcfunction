forceload add 0 320 79 399
scoreboard players set #loading cc_400 1
