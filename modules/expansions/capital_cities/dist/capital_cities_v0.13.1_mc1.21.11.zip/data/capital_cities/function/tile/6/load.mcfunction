forceload add 80 80 159 159
scoreboard players set #loading cc_400 1
