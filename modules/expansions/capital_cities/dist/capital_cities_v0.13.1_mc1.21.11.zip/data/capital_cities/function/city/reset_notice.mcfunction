tag @s remove cc13_reset
tellraw @s "Planta limpa. Use /function capital_cities:visit para reconstruir."
