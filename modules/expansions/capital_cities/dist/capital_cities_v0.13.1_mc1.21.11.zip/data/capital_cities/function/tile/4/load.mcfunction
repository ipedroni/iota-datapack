forceload add 320 0 399 79
scoreboard players set #loading cc_400 1
