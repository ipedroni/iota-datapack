fill 320 81 0 399 84 79 minecraft:air
fill 320 85 0 399 88 79 minecraft:air
fill 320 89 0 399 92 79 minecraft:air
fill 320 93 0 399 96 79 minecraft:air
fill 320 97 0 399 100 79 minecraft:air
fill 320 101 0 399 104 79 minecraft:air
fill 320 105 0 399 108 79 minecraft:air
fill 320 109 0 399 112 79 minecraft:air
fill 320 113 0 399 116 79 minecraft:air
fill 320 117 0 399 120 79 minecraft:air
fill 320 121 0 399 124 79 minecraft:air
fill 320 70 0 399 73 79 minecraft:stone
fill 320 74 0 399 77 79 minecraft:stone
fill 320 78 0 399 79 79 minecraft:dirt
fill 320 80 0 399 80 79 minecraft:grass_block
kill @e[type=!minecraft:player,x=320,y=70,z=0,dx=79,dy=54,dz=79]
