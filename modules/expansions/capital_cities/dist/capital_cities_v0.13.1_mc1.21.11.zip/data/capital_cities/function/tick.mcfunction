execute if score #state cc_400 matches 1 in capital_cities:settlement_400 run function capital_cities:city/work
execute if score #state cc_400 matches 3 in capital_cities:settlement_400 run function capital_cities:city/work
execute if score #state cc_400 matches 2 as @a[tag=cc13_visit] run function capital_cities:city/arrive
execute if score #state cc_400 matches 0 as @a[tag=cc13_reset] run function capital_cities:city/reset_notice
