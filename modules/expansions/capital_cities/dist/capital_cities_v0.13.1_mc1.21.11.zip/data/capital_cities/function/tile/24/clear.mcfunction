fill 320 81 320 399 84 399 minecraft:air
fill 320 85 320 399 88 399 minecraft:air
fill 320 89 320 399 92 399 minecraft:air
fill 320 93 320 399 96 399 minecraft:air
fill 320 97 320 399 100 399 minecraft:air
fill 320 101 320 399 104 399 minecraft:air
fill 320 105 320 399 108 399 minecraft:air
fill 320 109 320 399 112 399 minecraft:air
fill 320 113 320 399 116 399 minecraft:air
fill 320 117 320 399 120 399 minecraft:air
fill 320 121 320 399 124 399 minecraft:air
fill 320 70 320 399 73 399 minecraft:stone
fill 320 74 320 399 77 399 minecraft:stone
fill 320 78 320 399 79 399 minecraft:dirt
fill 320 80 320 399 80 399 minecraft:grass_block
kill @e[type=!minecraft:player,x=320,y=70,z=320,dx=79,dy=54,dz=79]
