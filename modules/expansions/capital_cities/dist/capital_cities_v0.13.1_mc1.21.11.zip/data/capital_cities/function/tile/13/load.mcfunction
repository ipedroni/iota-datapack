forceload add 240 160 319 239
scoreboard players set #loading cc_400 1
