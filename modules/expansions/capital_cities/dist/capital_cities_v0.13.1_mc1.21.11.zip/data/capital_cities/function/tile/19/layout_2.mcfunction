fill 320 80 240 320 80 240 minecraft:coarse_dirt
fill 321 80 240 321 80 240 minecraft:stone
fill 322 80 240 322 80 240 minecraft:coarse_dirt
fill 320 80 241 322 80 241 minecraft:coarse_dirt
fill 320 80 242 321 80 242 minecraft:coarse_dirt
fill 320 80 243 321 80 243 minecraft:coarse_dirt
fill 320 80 244 320 80 244 minecraft:coarse_dirt
fill 320 80 245 320 80 245 minecraft:dirt
