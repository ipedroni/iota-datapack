execute if score #state cc_400 matches 1 run function capital_cities:tile/10/build
execute if score #state cc_400 matches 3 run function capital_cities:tile/10/clear
forceload remove 0 160 79 239
scoreboard players set #loading cc_400 0
scoreboard players add #tile cc_400 1
