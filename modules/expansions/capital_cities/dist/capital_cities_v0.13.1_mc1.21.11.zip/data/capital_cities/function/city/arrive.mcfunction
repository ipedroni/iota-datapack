tag @s remove cc13_visit
execute in capital_cities:settlement_400 run teleport @s 200.5 81 335.5 180 0
function capital_cities:status
