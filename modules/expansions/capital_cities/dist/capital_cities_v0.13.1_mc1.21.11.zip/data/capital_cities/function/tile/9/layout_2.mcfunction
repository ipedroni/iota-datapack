fill 320 80 155 320 80 155 minecraft:dirt
fill 320 80 156 320 80 156 minecraft:dirt
fill 320 80 157 320 80 157 minecraft:coarse_dirt
fill 321 80 157 321 80 157 minecraft:dirt
fill 320 80 158 320 80 158 minecraft:dirt
fill 321 80 158 321 80 158 minecraft:coarse_dirt
fill 320 80 159 322 80 159 minecraft:dirt
