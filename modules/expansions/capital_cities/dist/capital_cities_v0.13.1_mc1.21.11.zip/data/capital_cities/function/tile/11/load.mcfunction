forceload add 80 160 159 239
scoreboard players set #loading cc_400 1
