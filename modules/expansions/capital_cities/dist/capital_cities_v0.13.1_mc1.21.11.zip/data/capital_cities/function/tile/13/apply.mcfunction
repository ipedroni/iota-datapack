execute if score #state cc_400 matches 1 run function capital_cities:tile/13/build
execute if score #state cc_400 matches 3 run function capital_cities:tile/13/clear
forceload remove 240 160 319 239
scoreboard players set #loading cc_400 0
scoreboard players add #tile cc_400 1
