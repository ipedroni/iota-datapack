forceload add 80 240 159 319
scoreboard players set #loading cc_400 1
