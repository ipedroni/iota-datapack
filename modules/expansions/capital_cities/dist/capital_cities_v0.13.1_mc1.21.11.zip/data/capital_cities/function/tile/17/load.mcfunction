forceload add 160 240 239 319
scoreboard players set #loading cc_400 1
