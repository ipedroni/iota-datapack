execute if score #state cc_400 matches 1 run function capital_cities:tile/21/build
execute if score #state cc_400 matches 3 run function capital_cities:tile/21/clear
forceload remove 80 320 159 399
scoreboard players set #loading cc_400 0
scoreboard players add #tile cc_400 1
