forceload add 240 80 319 159
scoreboard players set #loading cc_400 1
