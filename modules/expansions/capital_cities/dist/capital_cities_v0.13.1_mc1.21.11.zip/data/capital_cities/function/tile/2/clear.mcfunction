fill 160 81 0 239 84 79 minecraft:air
fill 160 85 0 239 88 79 minecraft:air
fill 160 89 0 239 92 79 minecraft:air
fill 160 93 0 239 96 79 minecraft:air
fill 160 97 0 239 100 79 minecraft:air
fill 160 101 0 239 104 79 minecraft:air
fill 160 105 0 239 108 79 minecraft:air
fill 160 109 0 239 112 79 minecraft:air
fill 160 113 0 239 116 79 minecraft:air
fill 160 117 0 239 120 79 minecraft:air
fill 160 121 0 239 124 79 minecraft:air
fill 160 70 0 239 73 79 minecraft:stone
fill 160 74 0 239 77 79 minecraft:stone
fill 160 78 0 239 79 79 minecraft:dirt
fill 160 80 0 239 80 79 minecraft:grass_block
kill @e[type=!minecraft:player,x=160,y=70,z=0,dx=79,dy=54,dz=79]
