execute if score #state cc_400 matches 1 run function capital_cities:tile/16/build
execute if score #state cc_400 matches 3 run function capital_cities:tile/16/clear
forceload remove 80 240 159 319
scoreboard players set #loading cc_400 0
scoreboard players add #tile cc_400 1
