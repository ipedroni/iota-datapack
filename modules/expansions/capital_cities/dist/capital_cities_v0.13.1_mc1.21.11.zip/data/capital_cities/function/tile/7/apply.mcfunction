execute if score #state cc_400 matches 1 run function capital_cities:tile/7/build
execute if score #state cc_400 matches 3 run function capital_cities:tile/7/clear
forceload remove 160 80 239 159
scoreboard players set #loading cc_400 0
scoreboard players add #tile cc_400 1
