fill 80 81 240 159 84 319 minecraft:air
fill 80 85 240 159 88 319 minecraft:air
fill 80 89 240 159 92 319 minecraft:air
fill 80 93 240 159 96 319 minecraft:air
fill 80 97 240 159 100 319 minecraft:air
fill 80 101 240 159 104 319 minecraft:air
fill 80 105 240 159 108 319 minecraft:air
fill 80 109 240 159 112 319 minecraft:air
fill 80 113 240 159 116 319 minecraft:air
fill 80 117 240 159 120 319 minecraft:air
fill 80 121 240 159 124 319 minecraft:air
fill 80 70 240 159 73 319 minecraft:stone
fill 80 74 240 159 77 319 minecraft:stone
fill 80 78 240 159 79 319 minecraft:dirt
fill 80 80 240 159 80 319 minecraft:grass_block
kill @e[type=!minecraft:player,x=80,y=70,z=240,dx=79,dy=54,dz=79]
