fill 160 81 160 239 84 239 minecraft:air
fill 160 85 160 239 88 239 minecraft:air
fill 160 89 160 239 92 239 minecraft:air
fill 160 93 160 239 96 239 minecraft:air
fill 160 97 160 239 100 239 minecraft:air
fill 160 101 160 239 104 239 minecraft:air
fill 160 105 160 239 108 239 minecraft:air
fill 160 109 160 239 112 239 minecraft:air
fill 160 113 160 239 116 239 minecraft:air
fill 160 117 160 239 120 239 minecraft:air
fill 160 121 160 239 124 239 minecraft:air
fill 160 70 160 239 73 239 minecraft:stone
fill 160 74 160 239 77 239 minecraft:stone
fill 160 78 160 239 79 239 minecraft:dirt
fill 160 80 160 239 80 239 minecraft:grass_block
kill @e[type=!minecraft:player,x=160,y=70,z=160,dx=79,dy=54,dz=79]
