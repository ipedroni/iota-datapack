fill 320 81 80 399 84 159 minecraft:air
fill 320 85 80 399 88 159 minecraft:air
fill 320 89 80 399 92 159 minecraft:air
fill 320 93 80 399 96 159 minecraft:air
fill 320 97 80 399 100 159 minecraft:air
fill 320 101 80 399 104 159 minecraft:air
fill 320 105 80 399 108 159 minecraft:air
fill 320 109 80 399 112 159 minecraft:air
fill 320 113 80 399 116 159 minecraft:air
fill 320 117 80 399 120 159 minecraft:air
fill 320 121 80 399 124 159 minecraft:air
fill 320 70 80 399 73 159 minecraft:stone
fill 320 74 80 399 77 159 minecraft:stone
fill 320 78 80 399 79 159 minecraft:dirt
fill 320 80 80 399 80 159 minecraft:grass_block
kill @e[type=!minecraft:player,x=320,y=70,z=80,dx=79,dy=54,dz=79]
