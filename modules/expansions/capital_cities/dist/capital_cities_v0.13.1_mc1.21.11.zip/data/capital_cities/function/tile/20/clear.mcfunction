fill 0 81 320 79 84 399 minecraft:air
fill 0 85 320 79 88 399 minecraft:air
fill 0 89 320 79 92 399 minecraft:air
fill 0 93 320 79 96 399 minecraft:air
fill 0 97 320 79 100 399 minecraft:air
fill 0 101 320 79 104 399 minecraft:air
fill 0 105 320 79 108 399 minecraft:air
fill 0 109 320 79 112 399 minecraft:air
fill 0 113 320 79 116 399 minecraft:air
fill 0 117 320 79 120 399 minecraft:air
fill 0 121 320 79 124 399 minecraft:air
fill 0 70 320 79 73 399 minecraft:stone
fill 0 74 320 79 77 399 minecraft:stone
fill 0 78 320 79 79 399 minecraft:dirt
fill 0 80 320 79 80 399 minecraft:grass_block
kill @e[type=!minecraft:player,x=0,y=70,z=320,dx=79,dy=54,dz=79]
