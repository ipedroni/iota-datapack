forceload add 160 0 239 79
scoreboard players set #loading cc_400 1
