forceload add 80 320 159 399
scoreboard players set #loading cc_400 1
