fill 240 81 320 319 84 399 minecraft:air
fill 240 85 320 319 88 399 minecraft:air
fill 240 89 320 319 92 399 minecraft:air
fill 240 93 320 319 96 399 minecraft:air
fill 240 97 320 319 100 399 minecraft:air
fill 240 101 320 319 104 399 minecraft:air
fill 240 105 320 319 108 399 minecraft:air
fill 240 109 320 319 112 399 minecraft:air
fill 240 113 320 319 116 399 minecraft:air
fill 240 117 320 319 120 399 minecraft:air
fill 240 121 320 319 124 399 minecraft:air
fill 240 70 320 319 73 399 minecraft:stone
fill 240 74 320 319 77 399 minecraft:stone
fill 240 78 320 319 79 399 minecraft:dirt
fill 240 80 320 319 80 399 minecraft:grass_block
kill @e[type=!minecraft:player,x=240,y=70,z=320,dx=79,dy=54,dz=79]
