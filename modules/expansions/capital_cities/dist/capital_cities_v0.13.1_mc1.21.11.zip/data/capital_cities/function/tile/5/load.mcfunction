forceload add 0 80 79 159
scoreboard players set #loading cc_400 1
