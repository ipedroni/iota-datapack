execute if score #state cc_400 matches 1 run function capital_cities:tile/11/build
execute if score #state cc_400 matches 3 run function capital_cities:tile/11/clear
forceload remove 80 160 159 239
scoreboard players set #loading cc_400 0
scoreboard players add #tile cc_400 1
