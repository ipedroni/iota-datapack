fill 80 81 320 159 84 399 minecraft:air
fill 80 85 320 159 88 399 minecraft:air
fill 80 89 320 159 92 399 minecraft:air
fill 80 93 320 159 96 399 minecraft:air
fill 80 97 320 159 100 399 minecraft:air
fill 80 101 320 159 104 399 minecraft:air
fill 80 105 320 159 108 399 minecraft:air
fill 80 109 320 159 112 399 minecraft:air
fill 80 113 320 159 116 399 minecraft:air
fill 80 117 320 159 120 399 minecraft:air
fill 80 121 320 159 124 399 minecraft:air
fill 80 70 320 159 73 399 minecraft:stone
fill 80 74 320 159 77 399 minecraft:stone
fill 80 78 320 159 79 399 minecraft:dirt
fill 80 80 320 159 80 399 minecraft:grass_block
kill @e[type=!minecraft:player,x=80,y=70,z=320,dx=79,dy=54,dz=79]
