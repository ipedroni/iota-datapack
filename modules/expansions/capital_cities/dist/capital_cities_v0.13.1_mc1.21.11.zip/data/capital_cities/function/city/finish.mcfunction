execute if score #state cc_400 matches 1 run return run scoreboard players set #state cc_400 2
scoreboard players set #state cc_400 0
