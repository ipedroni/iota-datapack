execute if score #state cc_400 matches 1 run function capital_cities:tile/20/build
execute if score #state cc_400 matches 3 run function capital_cities:tile/20/clear
forceload remove 0 320 79 399
scoreboard players set #loading cc_400 0
scoreboard players add #tile cc_400 1
