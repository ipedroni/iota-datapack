fill 0 81 160 79 84 239 minecraft:air
fill 0 85 160 79 88 239 minecraft:air
fill 0 89 160 79 92 239 minecraft:air
fill 0 93 160 79 96 239 minecraft:air
fill 0 97 160 79 100 239 minecraft:air
fill 0 101 160 79 104 239 minecraft:air
fill 0 105 160 79 108 239 minecraft:air
fill 0 109 160 79 112 239 minecraft:air
fill 0 113 160 79 116 239 minecraft:air
fill 0 117 160 79 120 239 minecraft:air
fill 0 121 160 79 124 239 minecraft:air
fill 0 70 160 79 73 239 minecraft:stone
fill 0 74 160 79 77 239 minecraft:stone
fill 0 78 160 79 79 239 minecraft:dirt
fill 0 80 160 79 80 239 minecraft:grass_block
kill @e[type=!minecraft:player,x=0,y=70,z=160,dx=79,dy=54,dz=79]
