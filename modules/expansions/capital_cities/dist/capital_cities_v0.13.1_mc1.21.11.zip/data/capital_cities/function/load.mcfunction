scoreboard objectives add cc_400 dummy
