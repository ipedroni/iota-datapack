fill 160 81 80 239 84 159 minecraft:air
fill 160 85 80 239 88 159 minecraft:air
fill 160 89 80 239 92 159 minecraft:air
fill 160 93 80 239 96 159 minecraft:air
fill 160 97 80 239 100 159 minecraft:air
fill 160 101 80 239 104 159 minecraft:air
fill 160 105 80 239 108 159 minecraft:air
fill 160 109 80 239 112 159 minecraft:air
fill 160 113 80 239 116 159 minecraft:air
fill 160 117 80 239 120 159 minecraft:air
fill 160 121 80 239 124 159 minecraft:air
fill 160 70 80 239 73 159 minecraft:stone
fill 160 74 80 239 77 159 minecraft:stone
fill 160 78 80 239 79 159 minecraft:dirt
fill 160 80 80 239 80 159 minecraft:grass_block
kill @e[type=!minecraft:player,x=160,y=70,z=80,dx=79,dy=54,dz=79]
