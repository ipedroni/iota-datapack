fill 80 81 80 159 84 159 minecraft:air
fill 80 85 80 159 88 159 minecraft:air
fill 80 89 80 159 92 159 minecraft:air
fill 80 93 80 159 96 159 minecraft:air
fill 80 97 80 159 100 159 minecraft:air
fill 80 101 80 159 104 159 minecraft:air
fill 80 105 80 159 108 159 minecraft:air
fill 80 109 80 159 112 159 minecraft:air
fill 80 113 80 159 116 159 minecraft:air
fill 80 117 80 159 120 159 minecraft:air
fill 80 121 80 159 124 159 minecraft:air
fill 80 70 80 159 73 159 minecraft:stone
fill 80 74 80 159 77 159 minecraft:stone
fill 80 78 80 159 79 159 minecraft:dirt
fill 80 80 80 159 80 159 minecraft:grass_block
kill @e[type=!minecraft:player,x=80,y=70,z=80,dx=79,dy=54,dz=79]
