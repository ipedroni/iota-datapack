execute if score #state cc_400 matches 1 run return run tellraw @s ["Gerando setores: ",{"score":{"name":"#tile","objective":"cc_400"}},"/25"]
execute if score #state cc_400 matches 3 run return run tellraw @s "Reset em andamento."
execute unless score #state cc_400 matches 2 run return run tellraw @s "Use /function capital_cities:visit para gerar a capital."
tellraw @s ["Capital 0.13.1 | Planta ",{"score":{"name":"#layout","objective":"cc_400"}}]
