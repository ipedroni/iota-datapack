fill 240 81 80 319 84 159 minecraft:air
fill 240 85 80 319 88 159 minecraft:air
fill 240 89 80 319 92 159 minecraft:air
fill 240 93 80 319 96 159 minecraft:air
fill 240 97 80 319 100 159 minecraft:air
fill 240 101 80 319 104 159 minecraft:air
fill 240 105 80 319 108 159 minecraft:air
fill 240 109 80 319 112 159 minecraft:air
fill 240 113 80 319 116 159 minecraft:air
fill 240 117 80 319 120 159 minecraft:air
fill 240 121 80 319 124 159 minecraft:air
fill 240 70 80 319 73 159 minecraft:stone
fill 240 74 80 319 77 159 minecraft:stone
fill 240 78 80 319 79 159 minecraft:dirt
fill 240 80 80 319 80 159 minecraft:grass_block
kill @e[type=!minecraft:player,x=240,y=70,z=80,dx=79,dy=54,dz=79]
