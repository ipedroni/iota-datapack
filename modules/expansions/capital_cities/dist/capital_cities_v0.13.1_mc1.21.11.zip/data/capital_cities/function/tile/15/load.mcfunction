forceload add 0 240 79 319
scoreboard players set #loading cc_400 1
