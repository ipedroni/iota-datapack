forceload add 240 320 319 399
scoreboard players set #loading cc_400 1
