forceload add 320 80 399 159
scoreboard players set #loading cc_400 1
