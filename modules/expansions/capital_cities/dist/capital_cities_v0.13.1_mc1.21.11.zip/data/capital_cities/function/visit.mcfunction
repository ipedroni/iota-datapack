execute if score #state cc_400 matches 3 run return run tellraw @s "Aguarde o reset."
execute if score #state cc_400 matches 2 run return run function capital_cities:city/arrive
tag @s add cc13_visit
execute unless score #state cc_400 matches 1 run function capital_cities:city/start
tellraw @s "Preparando a capital de 400 × 400. Voce sera teleportado ao concluir."
