forceload add 0 0 79 79
scoreboard players set #loading cc_400 1
