execute unless score #layout cc_400 matches 0..3 run return run execute store result score #layout cc_400 run random value 0..3
execute store result score #offset cc_400 run random value 1..3
scoreboard players operation #layout cc_400 += #offset cc_400
execute if score #layout cc_400 matches 4.. run scoreboard players remove #layout cc_400 4
