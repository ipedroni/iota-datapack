fill 160 81 320 239 84 399 minecraft:air
fill 160 85 320 239 88 399 minecraft:air
fill 160 89 320 239 92 399 minecraft:air
fill 160 93 320 239 96 399 minecraft:air
fill 160 97 320 239 100 399 minecraft:air
fill 160 101 320 239 104 399 minecraft:air
fill 160 105 320 239 108 399 minecraft:air
fill 160 109 320 239 112 399 minecraft:air
fill 160 113 320 239 116 399 minecraft:air
fill 160 117 320 239 120 399 minecraft:air
fill 160 121 320 239 124 399 minecraft:air
fill 160 70 320 239 73 399 minecraft:stone
fill 160 74 320 239 77 399 minecraft:stone
fill 160 78 320 239 79 399 minecraft:dirt
fill 160 80 320 239 80 399 minecraft:grass_block
kill @e[type=!minecraft:player,x=160,y=70,z=320,dx=79,dy=54,dz=79]
