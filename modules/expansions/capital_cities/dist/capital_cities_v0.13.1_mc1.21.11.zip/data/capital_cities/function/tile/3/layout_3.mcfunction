fill 240 80 77 243 80 77 minecraft:dirt
fill 240 80 78 244 80 78 minecraft:dirt
fill 245 80 78 246 80 78 minecraft:grass_block
fill 240 80 79 240 80 79 minecraft:coarse_dirt
fill 241 80 79 244 80 79 minecraft:dirt
fill 245 80 79 247 80 79 minecraft:grass_block
fill 248 80 79 248 80 79 minecraft:gravel
fill 249 80 79 249 80 79 minecraft:grass_block
