function capital_cities:city/roll_layout
scoreboard players set #tile cc_400 0
scoreboard players set #loading cc_400 0
scoreboard players set #state cc_400 1
