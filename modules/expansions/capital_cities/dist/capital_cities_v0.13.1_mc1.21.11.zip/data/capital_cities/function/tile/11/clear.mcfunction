fill 80 81 160 159 84 239 minecraft:air
fill 80 85 160 159 88 239 minecraft:air
fill 80 89 160 159 92 239 minecraft:air
fill 80 93 160 159 96 239 minecraft:air
fill 80 97 160 159 100 239 minecraft:air
fill 80 101 160 159 104 239 minecraft:air
fill 80 105 160 159 108 239 minecraft:air
fill 80 109 160 159 112 239 minecraft:air
fill 80 113 160 159 116 239 minecraft:air
fill 80 117 160 159 120 239 minecraft:air
fill 80 121 160 159 124 239 minecraft:air
fill 80 70 160 159 73 239 minecraft:stone
fill 80 74 160 159 77 239 minecraft:stone
fill 80 78 160 159 79 239 minecraft:dirt
fill 80 80 160 159 80 239 minecraft:grass_block
kill @e[type=!minecraft:player,x=80,y=70,z=160,dx=79,dy=54,dz=79]
