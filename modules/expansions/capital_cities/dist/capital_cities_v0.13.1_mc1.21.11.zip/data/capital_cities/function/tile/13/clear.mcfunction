fill 240 81 160 319 84 239 minecraft:air
fill 240 85 160 319 88 239 minecraft:air
fill 240 89 160 319 92 239 minecraft:air
fill 240 93 160 319 96 239 minecraft:air
fill 240 97 160 319 100 239 minecraft:air
fill 240 101 160 319 104 239 minecraft:air
fill 240 105 160 319 108 239 minecraft:air
fill 240 109 160 319 112 239 minecraft:air
fill 240 113 160 319 116 239 minecraft:air
fill 240 117 160 319 120 239 minecraft:air
fill 240 121 160 319 124 239 minecraft:air
fill 240 70 160 319 73 239 minecraft:stone
fill 240 74 160 319 77 239 minecraft:stone
fill 240 78 160 319 79 239 minecraft:dirt
fill 240 80 160 319 80 239 minecraft:grass_block
kill @e[type=!minecraft:player,x=240,y=70,z=160,dx=79,dy=54,dz=79]
