# Toolsmith — working template

Use the [shared Trading rules](trading_design_directions.md). Toolsmith sells Pickaxes, Axes, Shovels and Hoes. Its catalog is under review.

| Stage | Sells | Buys |
| --- | --- | --- |
| Novice | Candidate: two distinct unenchanted Copper/Iron tools | Fixed Flint and one of Coal or Charcoal |
| Apprentice | Candidate: one distinct unenchanted Copper/Iron tool | One draw from the remaining fuel, Copper Ingots and Iron Ingots |
| Journeyman | Tool progression in the shared rules | Candidate: Iron/Gold Ingots or a plain Copper/Iron tool |
| Expert | Tool progression or the [shared smith ingot alternative](trading_design_directions.md#working-price-and-stock-calibration) | Gold Ingots, Diamonds or an Iron/Gold tool under the [shared purchase rules](trading_design_directions.md#enchanted-equipment-purchases) |
| Master | Tool progression. Review former special material alternatives | Repeat Expert's pool, excluding the selected option |

Flint is purchase-only. Apprentice can skip the remaining fuel. Sold Axes use Efficiency, Unbreaking, Fortune, Silk Touch and Mending only. Fortune and Silk Touch are incompatible. Choose family weights, remaining early materials, Master sale alternatives and purchase exclusion granularity during catalog review.

See the [shared stock calibration](trading_design_directions.md#working-price-and-stock-calibration). Prior catalogs, fuel and metal stock estimates, and the time-to-sell calculation are in the [22 November snapshot](../research_index.md#backups-anteriores).
