# Profession catalogs — current working candidates

Minecraft Java 1.21.11. See [shared Trading rules](trading_design_directions.md) and the [Toolsmith template](trading_toolsmith_template.md). These are design choices for the five-level redesign. Candidate rows remain open until reviewed.

See the [shared Expert ingot alternative and stock calibration](trading_design_directions.md#working-price-and-stock-calibration).




## Armorer

| Stage | Sells | Buys |
| --- | --- | --- |
| Novice | Two Copper/Iron pieces for different body slots | Candidate: one of Coal/Charcoal and one of Copper/Iron Ingots |
| Apprentice | Candidate: one distinct Copper/Iron piece | Leather or one material skipped at Novice |
| Journeyman | Review first enchanted armor pool and materials | Candidate: Iron/Gold Ingots or plain Copper/Iron armor |
| Expert | Shared ingot alternative or enchanted armor | Candidate: Gold Ingots, Diamonds or Iron/Gold armor with Basic enchantments up to II |
| Master | Review enchanted armor and former special candidates, including enchanted Iron, Gold or Diamond Horse Armor | Review final purchase pool |

Swift Sneak is Basic and may appear on leggings from Journeyman. Soul Speed is Situational and belongs on boots. The [21 November approval in the archived catalog](../research_index.md#backups-anteriores) starts Soul Speed at Expert. The [shared Journeyman rule](trading_design_directions.md#artisan-equipment-enchantments) permits Situational effects in its tool progression. Confirm whether Armorer keeps its specific Expert threshold when that progression is mapped to armor. Horse Armor requires functional validation before it can enter the pool.




## Weaponsmith

Swords and Spears are the two families. Novice and Apprentice follow the [Toolsmith purchases](trading_toolsmith_template.md). The sale candidate starts with one unenchanted Copper/Iron Sword and one Spear, then adds one distinct unenchanted weapon at Apprentice. Review the shared tool progression for the three enchanted sale stages and use the Expert ingot alternative.

The Journeyman purchase candidate is Iron/Gold Ingots or a plain Copper/Iron Sword or Spear. The proposed Expert pool is Gold Ingots, Diamonds or an Iron/Gold Sword or Spear with Basic enchantments up to II. The proposed Master draw reuses that pool, excluding the previous selection. Review family/material contracts and exclusion granularity.

Preserve native incompatibilities such as Sharpness, Smite and Bane of Arthropods. The Master Sword pool has only one eligible Treasure, Mending. Reduce its inclusion chance, with the percentage pending. Apply the same rule to Fletcher crossbows and roll Treasure inclusion separately from selecting the effect.




## Fletcher

| Stage | Sells | Buys |
| --- | --- | --- |
| Novice | Fixed Arrows plus unenchanted Bow or Crossbow | Open. The old table used Feather and String. Reconcile with later proposals before choosing. |
| Apprentice | Remaining unenchanted weapon, Arrows of Slowness or Arrows of Weakness | Open. The old table proposed Flint or Stick. |
| Journeyman | Proposed redistribution: eligible equipment or Spectral, Slowness or Weakness arrows | Review eligible equipment and ammunition |
| Expert | Proposed redistribution: eligible equipment, Poison, Harming or available earlier arrows | Review eligible equipment and ammunition |
| Master | Proposed redistribution: special ranged equipment | Review final purchase pool |

Spectral, Slowness, Weakness, Poison and Harming are approved alternatives for later purchases and sales. Use regular effect variants without amplification or extended duration. Retain an arrow offer once drawn and exclude it from later draws. Preserve Multishot/Piercing and Infinity/Mending incompatibilities. The reduced Mending chance for crossbows follows Weaponsmith's sword rule.




## Leatherworker

| Stage | Sells | Buys |
| --- | --- | --- |
| Novice | Two distinct unenchanted player leather armor pieces | Two of Rotten Flesh, Leather, String and Rabbit Hide |
| Apprentice | The other two unenchanted leather pieces | Review the remaining material draw |
| Journeyman | Proposed: Leather, Rabbit Hide or Dyes | Unselected initial materials or eligible equipment |
| Expert | Proposed: unenchanted Leather Horse Armor or Wolf Armor, or materials/dyes | Unselected initial materials or eligible equipment |
| Master | Proposed: enchanted Leather Horse Armor or Wolf Armor, subject to functional validation | Unselected initial materials or eligible equipment |

Player leather armor sells unenchanted. Metal Horse Armor belongs to Armorer. Group the dye colors in the draw so their count does not dominate. Prefer Leather and Rabbit Hide over the dye group, with weights pending. Review the exact purchase contracts for each stage.




## Animal armor validation

Enchantment components can be attached to these items. Effects on a horse or wolf wearing the armor are still unverified. Horse Armor has no durability. Exclude Unbreaking and Mending as repair benefits on that item. Protection IV, Thorns III and Feather Falling IV are candidates for functional testing. Test Wolf Armor absorption, durability and each proposed effect on a wolf.




## Other professions — candidates awaiting five-level review

Keep early seed retail and a fixed introductory Wheat Seeds buy for Farmer. Fisherman supplies fish and gear and buys inputs or qualified rods. Fish purchases are excluded. Butcher supplies meat and meals. Shepherd focuses on textiles, including early String, with Beds and Paintings excluded. Librarian has at most two ordinary book sales. Cartographer supplies navigation, Cleric supplies expedition and brewing resources, and Mason supplies bulk construction materials and early Flint.

The tables below preserve the previous candidates as input for redistribution. The Secret rows identify former special offers for review in Master and carry no current unlock or draw weights.




## Farmer

Wheat Seeds fixed introductory buy; basic seed retail only Novice. A second common seed buy at Apprentice; crop outlet at Journeyman. No Sniffer seeds.

| Stage | Sells | Buys |
| --- | --- | --- |
| Novice | Wheat Seeds OR Beetroot Seeds OR Carrot OR Potato; Bread OR Carrot OR Potato | Wheat Seeds; Wheat OR Carrot OR Potato |
| Apprentice | Bread OR Apple | Beetroot Seeds OR Pumpkin Seeds OR Melon Seeds |
| Journeyman | Hay Block OR Pumpkin Pie | Wheat OR Carrot OR Potato OR Beetroot (+2 options; see candidate data) |
| Expert | Golden Carrot | Bread OR Baked Potato |
| Master | Cake OR Honey Bottle | Pumpkin Pie |
| Secret | Golden Apple | No addition |




## Butcher

Supply meat and meals; buy complementary foods, Eggs/Milk first. A Milk Bucket quote explicitly includes the consumed bucket; no invisible container refund.

| Stage | Sells | Buys |
| --- | --- | --- |
| Novice | Cooked Chicken OR Cooked Porkchop; Cooked Chicken OR Cooked Porkchop | Egg OR Milk Bucket; Egg OR Milk Bucket |
| Apprentice | Cooked Beef OR Cooked Mutton | Carrot OR Potato OR Wheat |
| Journeyman | Cooked Cod OR Cooked Salmon | Cod OR Salmon |
| Expert | Cooked Rabbit OR Rabbit Stew | Red Mushroom OR Brown Mushroom OR Beetroot |
| Master | Pumpkin Pie OR Golden Carrot | Mushroom Stew OR Beetroot Soup |
| Secret | Suspicious Stew | No addition |




## Fisherman

Keep the praised fish/equipment identity and no fish purchases. Only Master buys enchanted rods; complement via materials, not an earlier overlapping rod contract.

| Stage | Sells | Buys |
| --- | --- | --- |
| Novice | Cod OR Salmon; Cod OR Salmon | String OR Stick; String OR Stick |
| Apprentice | Cooked Cod OR Fishing Rod | Coal OR Charcoal |
| Journeyman | Bucket OR Cooked Salmon | Fishing Rod |
| Expert | Tropical Fish Bucket OR Pufferfish Bucket | Glass Bottle |
| Master | Fishing Rod [Luck Of The Sea 2] OR Fishing Rod [Lure 2] | Fishing Rod |
| Secret | Fishing Rod [Luck Of The Sea 3] OR Fishing Rod [Lure 3] OR Fishing Rod [Mending 1] | No addition |




## Shepherd

Include String retail early; remove Beds/Paintings from both directions. Textile/dye/banner specialist; decorative Secret remains a documented low-impact exception to resource shortcuts.

| Stage | Sells | Buys |
| --- | --- | --- |
| Novice | White Wool OR String; String OR White Wool | White Wool OR String; String OR White Wool |
| Apprentice | White Carpet OR Red Dye OR Blue Dye OR Yellow Dye | Red Dye OR Blue Dye OR Yellow Dye |
| Journeyman | White Banner OR Shears | Black Wool OR Gray Wool OR Brown Wool |
| Expert | Red Wool OR Blue Wool OR Yellow Wool OR Black Dye OR White Dye | White Carpet OR Red Carpet OR Blue Carpet OR Yellow Carpet |
| Master | Red Carpet OR Blue Carpet OR Yellow Carpet | White Banner |
| Secret | White Banner | No addition |




## Librarian

Maximum two ordinary book sales, with distinct ranks. Echo Shard Secret candidate; Mending only rare Secret here, never ordinary fixed retail. Natural loot remains a separate access route.

| Stage | Sells | Buys |
| --- | --- | --- |
| Novice | Book OR Bookshelf; Bookshelf OR Book | Paper; Ink Sac |
| Apprentice | Lapis Lazuli | Book |
| Journeyman | Enchanted Book [Efficiency 1] OR Enchanted Book [Unbreaking 1] | Bookshelf OR Glass |
| Expert | Clock OR Glass | Amethyst Shard OR Glow Ink Sac |
| Master | Enchanted Book [Efficiency 3] OR Enchanted Book [Unbreaking 3] OR Enchanted Book [Fortune 2] | Enchanted Book [Efficiency 2] OR Enchanted Book [Unbreaking 2] |
| Secret | Echo Shard OR Enchanted Book [Mending 1] OR Enchanted Book [Frost Walker 2] | No addition |




## Cartographer

Retain navigation focus and useful map destinations, one draw per level. Recovery Compass always one unit; chain repriced coherently. Map service still requires real map generation.

| Stage | Sells | Buys |
| --- | --- | --- |
| Novice | Map OR Compass; Map OR Compass | Paper OR Glass Pane; Glass Pane OR Paper |
| Apprentice | Spyglass OR Filled Map -> Village | Ink Sac OR Amethyst Shard |
| Journeyman | Filled Map -> Shipwreck OR Filled Map -> Ruined Portal | Map OR Compass |
| Expert | Filled Map -> Ocean Monument OR Filled Map -> Trial Chambers | Spyglass OR Clock |
| Master | Filled Map -> Woodland Mansion OR Recovery Compass | Recovery Compass |
| Secret | Filled Map -> Ancient City | No addition |




## Cleric

Reagents and brewing services; Secret only selected Wind Charge/Ghast Tear candidates. No implicit Breeze Rod, Heavy Core or Nether Star offer.

| Stage | Sells | Buys |
| --- | --- | --- |
| Novice | Redstone OR Lapis Lazuli; Redstone OR Lapis Lazuli | Rotten Flesh OR Nether Wart; Nether Wart OR Rotten Flesh |
| Apprentice | Glowstone Dust OR Quartz | Glass Bottle OR Red Mushroom OR Brown Mushroom |
| Journeyman | Experience Bottle OR Ender Pearl | Spider Eye OR Blaze Powder |
| Expert | Potion [Fire Resistance] OR Potion [Strong Healing] | Magma Cream OR Phantom Membrane |
| Master | Potion [Slow Falling] OR Potion [Strong Regeneration] | Ghast Tear |
| Secret | Wind Charge OR Ghast Tear | No addition |




## Mason

Retain bulk builder supply and early Flint. One regional complement can supply omitted palettes; do not turn the Stonecutter into a trade-only item.

| Stage | Sells | Buys |
| --- | --- | --- |
| Novice | Flint OR Stone; Stone OR Flint | Cobblestone OR Gravel; Gravel OR Cobblestone |
| Apprentice | Clay Ball OR Brick | Sand OR Clay Ball |
| Journeyman | Terracotta OR Quartz Block | Sandstone OR Glass |
| Expert | Stone Bricks OR Chiseled Stone Bricks | Terracotta OR Stone Bricks |
| Master | Prismarine OR Sea Lantern | Quartz Block |
| Secret | Calcite OR Amethyst Block OR Purpur Block | No addition |




## Decision history

The [22 November snapshot](../research_index.md#backups-anteriores) preserves prior artisan tables and economy references. Generated catalogs and native evidence are in the [20 November execution output](../research/outputs/trading_execution-2026-11-20/).
