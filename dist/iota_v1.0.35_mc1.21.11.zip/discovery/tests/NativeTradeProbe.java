package iota.probe;
import java.nio.file.*;import java.lang.reflect.*;import java.util.Objects;
public class NativeTradeProbe {
 static int checks=0;
 static void check(boolean v,String label){if(!v)throw new AssertionError(label);checks++;System.out.println("PASS "+label);}
 static Class<?> c(String n)throws Exception{return Class.forName(n);}
 public static void main(String[] args)throws Exception{
  c("w").getMethod("a").invoke(null);c("amv").getMethod("a").invoke(null);
  Class<?> stack=c("dlt"),component=c("kh"),predicate=c("kc"),cost=c("dvj"),nbt=c("uz"),custom=c("doe");
  Object tool=stack.getConstructor(c("dwn")).newInstance(c("dlx").getField("qO").get(null));
  Object damage=c("ki").getField("e").get(null),data=c("ki").getField("b").get(null);
  Method set=stack.getMethod("b",component,Object.class),expect=predicate.getMethod("a",component,Object.class),matches=cost.getMethod("a",stack);
  Object holder=stack.getMethod("i").invoke(tool);Constructor<?> makeCost=cost.getConstructor(c("jd"),int.class,predicate);
  set.invoke(tool,damage,0);Object full=makeCost.newInstance(holder,1,expect.invoke(null,damage,0));
  check((boolean)matches.invoke(full,tool),"native ItemCost accepts full durability");
  set.invoke(tool,damage,1);check(!(boolean)matches.invoke(full,tool),"native ItemCost rejects damage1");set.invoke(tool,damage,0);
  Object tag=nbt.getConstructor().newInstance();nbt.getMethod("a",String.class,int.class).invoke(tag,"eligible",1);Object expected=custom.getMethod("a",nbt).invoke(null,tag);
  Object flag=makeCost.newInstance(holder,1,expect.invoke(null,data,expected));set.invoke(tool,data,expected);
  check((boolean)matches.invoke(flag,tool),"native custom_data exact match accepts");
  Object extra=nbt.getMethod("l").invoke(tag);nbt.getMethod("a",String.class,int.class).invoke(extra,"other_pack_keep",42);Object extraData=custom.getMethod("a",nbt).invoke(null,extra);set.invoke(tool,data,extraData);
  check(!(boolean)matches.invoke(flag,tool),"native custom_data subset does NOT match extra metadata");
  check((boolean)matches.invoke(full,tool),"unrequested custom_data survives independent damage requirement");
  set.invoke(tool,damage,2);check(!(boolean)matches.invoke(full,tool),"unrelated metadata cannot bypass full-durability requirement");
  check(Objects.equals(stack.getMethod("a",component).invoke(tool,data),extraData),"probe never strips unrelated custom data");
  Files.writeString(Path.of(args[0]),"{\"passed\":true,\"checks\":"+checks+",\"scope\":\"Direct official1.21.11 ItemCost Java execution; not a GUI/player transaction or OR/minimum-enchantment adapter\",\"customDataSubsetAccepted\":false,\"identityPreserved\":true}\n");
 }
}
