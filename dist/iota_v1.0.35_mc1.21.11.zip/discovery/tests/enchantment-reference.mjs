import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve(import.meta.dirname,'../../..');
const vanilla=path.join(root,'vendor/generated/data/minecraft');
const out=path.join(root,'docs/discovery/research/outputs/enchantment-reference-2026-11-22');
const configFile=path.join(import.meta.dirname,'enchantment-reference.config.json');
const config=JSON.parse(fs.readFileSync(configFile,'utf8'));
function expand(kind,value,seen=new Set()){
 if(Array.isArray(value))return value.flatMap(v=>expand(kind,v,seen));
 if(typeof value==='object')return expand(kind,value.id,seen);
 if(!value.startsWith('#'))return [value];
 assert(!seen.has(value),'Tag cycle '+value);
 const next=new Set(seen);next.add(value);
 const tag=JSON.parse(fs.readFileSync(path.join(vanilla,'tags',kind,value.slice(1).replace('minecraft:','')+'.json'),'utf8'));
 return tag.values.flatMap(v=>expand(kind,v,next));
}
const curses=new Set(expand('enchantment','#minecraft:curse'));
const ench=fs.readdirSync(path.join(vanilla,'enchantment')).filter(f=>f.endsWith('.json')).map(f=>({id:'minecraft:'+f.slice(0,-5),...JSON.parse(fs.readFileSync(path.join(vanilla,'enchantment',f),'utf8'))})).filter(e=>!curses.has(e.id));
const items=new Map();
for(const e of ench){e.ex=new Set(expand('enchantment',e.exclusive_set||[]));for(const item of new Set(expand('item',e.supported_items))){if(!items.has(item))items.set(item,[]);items.get(item).push(e);}}
function maxCompatible(pool){let best=[];function visit(i,chosen){if(chosen.length+pool.length-i<=best.length)return;if(i===pool.length){best=chosen;return;}const e=pool[i];if(chosen.every(x=>!x.ex.has(e.id)&&!e.ex.has(x.id)))visit(i+1,[...chosen,e]);visit(i+1,chosen);}visit(0,[]);return best.map(e=>e.id);}
function stats(values){assert(values.length);const sorted=[...values].sort((a,b)=>a-b),n=sorted.length;const mean=values.reduce((a,b)=>a+b,0)/n,median=n%2?sorted[(n-1)/2]:(sorted[n/2-1]+sorted[n/2])/2;return {count:n,mean,median,meanCap:Math.floor(config.ratio*mean),medianCap:Math.floor(config.ratio*median),sameCap:Math.floor(config.ratio*mean)===Math.floor(config.ratio*median)};}
const all=[...items].map(([item,pool])=>({item,maximum:maxCompatible(pool).length}));
const families=config.families.map(family=>{
 const variants=all.filter(r=>r.item===('minecraft:'+family)||new RegExp('^minecraft:(wooden|stone|copper|iron|golden|diamond|netherite|leather|chainmail)_'+family+'$').test(r.item));
 assert(variants.length,'Missing family '+family);
 const maxima=[...new Set(variants.map(r=>r.maximum))];assert.equal(maxima.length,1,'Material variants differ; review grouping '+family);
 return {family,maximum:maxima[0],variants:variants.map(r=>r.item),example:maxCompatible(items.get(variants[0].item))};
});
assert.equal(new Set(families.flatMap(f=>f.variants)).size,families.flatMap(f=>f.variants).length);
const selected=stats(families.map(f=>f.maximum)),cap=selected.meanCap;
const report={scope:config.scope,ratio:config.ratio,source:'Vanilla Java 1.21.11 supported_items and exclusive_set; curses excluded',method:'Equal weight per explicitly selected family; material variants do not add weight; full compatible reference before profession restrictions',allItemIds:stats(all.map(r=>r.maximum)),catalogFamilies:selected,quantityBands:{poucos:[1,Math.ceil(cap/3)],alguns:[Math.ceil(cap/3),Math.ceil(2*cap/3)],muitos:[Math.ceil(2*cap/3),cap]},families,deferred:config.deferred,notes:['Research calculation only; no trade generator or pack changed.','Global cap cannot exceed available compatible effects on an actual item.','Master quality guarantee and profession restrictions must be checked separately.','Animal armor awaits functional validation; not counted as zero.']};
fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'reference.json'),JSON.stringify(report,null,2)+'\n');
fs.writeFileSync(path.join(out,'reference.md'),'# Referência de quantidade de encantamentos\n\nEscopo: '+config.scope+'\n\nCada família tem peso igual; materiais não multiplicam o peso. Maldições excluídas. Armaduras de animais aguardam validação e não entram como zero.\n\n| Família | Máximo simultâneo |\n|---|---:|\n'+families.map(f=>'| '+f.family+' | '+f.maximum+' |').join('\n')+'\n\nMédia: '+selected.mean.toFixed(4)+'. Mediana: '+selected.median+'.\n\n'+(config.ratio*100)+'% da média, arredondado para baixo: **'+cap+'**. Pela mediana: **'+selected.medianCap+'**.\n\nPoucos: '+report.quantityBands.poucos.join('–')+'; alguns: '+report.quantityBands.alguns.join('–')+'; muitos: '+report.quantityBands.muitos.join('–')+'.\n\nEste cálculo não altera ofertas no jogo. Compatibilidade, restrições da profissão e garantia de Master são verificações separadas. A lista de famílias deve mudar quando o catálogo mudar.\n');
console.log(JSON.stringify({allItemIds:report.allItemIds,catalogFamilies:selected,bands:report.quantityBands}));

