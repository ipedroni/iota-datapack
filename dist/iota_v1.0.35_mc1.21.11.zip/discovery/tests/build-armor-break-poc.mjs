import fs from 'node:fs';import path from 'node:path';
const root=path.resolve(import.meta.dirname,'../../..'),out=path.join(root,'docs/discovery/research/outputs/trading-execution-2026-11-20'),pack=path.join(out,'armor-break-poc'),ns=path.join(pack,'data/iota_armor_poc');
const write=(name,text)=>{fs.mkdirSync(path.dirname(path.join(ns,name)),{recursive:true});fs.writeFileSync(path.join(ns,name),typeof text==='string'?text:JSON.stringify(text,null,2)+'\n');};
fs.mkdirSync(pack,{recursive:true});fs.writeFileSync(path.join(pack,'pack.mcmeta'),JSON.stringify({pack:{description:'Iota armor pre-destruction research POC; isolated tests only',min_format:[94,1],max_format:[94,1]}},null,2));
const items=JSON.parse(fs.readFileSync(path.join(root,'docs/discovery/research/outputs/trading_economy-discovery-2026-11-19/items.json'),'utf8'));
for(const [slot,family]of [['head','helmet'],['chest','chestplate'],['legs','leggings'],['feet','boots']]){
 const ids=items.filter(a=>a.id.endsWith('_'+family)).map(a=>a.id);write('advancement/break_'+slot+'.json',{criteria:{fatal:{trigger:'minecraft:item_durability_changed',conditions:{item:{items:ids},durability:{max:0}}}},rewards:{function:'iota_armor_poc:break_'+slot}});
 write('function/break_'+slot+'.mcfunction',`advancement revoke @s only iota_armor_poc:break_${slot}\ndata remove storage iota_armor_poc:scratch item\nexecute store success score #copied iota_apoc run data modify storage iota_armor_poc:scratch item set from entity @s equipment.${slot}\nexecute unless score #copied iota_apoc matches 1 run return 0\nfunction iota_armor_poc:break_common {slot:"armor.${slot}"}\n`);
}
write('item_modifier/full_damage.json',{function:'minecraft:set_damage',damage:0,add:false});
write('function/load.mcfunction','scoreboard objectives add iota_apoc dummy\n');
write('function/break_common.mcfunction',`# Source slot is fixed by native armor family; no nearest-item or hand guess.
execute store success score #had_data iota_apoc run data get storage iota_armor_poc:scratch item.components."minecraft:custom_data"
execute store success score #had_lore iota_apoc run data get storage iota_armor_poc:scratch item.components."minecraft:lore"
data modify storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc set value {broken:1b,saved:{}}
execute store result storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.had_data byte 1 run scoreboard players get #had_data iota_apoc
execute store result storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.had_lore byte 1 run scoreboard players get #had_lore iota_apoc
`+['equippable','attribute_modifiers'].map(k=>`execute if data storage iota_armor_poc:scratch item.components."minecraft:${k}" run data modify storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."minecraft:${k}" set from storage iota_armor_poc:scratch item.components."minecraft:${k}"
execute if data storage iota_armor_poc:scratch item.components."!minecraft:${k}" run data modify storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."!minecraft:${k}" set value {}
data remove storage iota_armor_poc:scratch item.components."minecraft:${k}"
data modify storage iota_armor_poc:scratch item.components."!minecraft:${k}" set value {}
`).join('')+`execute unless data storage iota_armor_poc:scratch item.components."minecraft:lore" run data modify storage iota_armor_poc:scratch item.components."minecraft:lore" set value []
data modify storage iota_armor_poc:scratch item.components."minecraft:lore" append value {translate:"iota.status.broken",fallback:"Broken",color:"red",italic:0b}
summon minecraft:item ~ ~0.5 ~ {Tags:["iota_armor_buffer"],Invulnerable:1b,NoGravity:1b,PickupDelay:32767s,Item:{id:"minecraft:stone",count:1}}
data modify entity @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] Owner set from entity @s UUID
data modify entity @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] Item set from storage iota_armor_poc:scratch item
item modify entity @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] contents iota_armor_poc:full_damage
execute store success score #ready iota_apoc run data get entity @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] Item.components."minecraft:custom_data".iota_armor_poc
$execute if score #ready iota_apoc matches 1 run item replace entity @s $(slot) with minecraft:air
data merge entity @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] {PickupDelay:0s}
tag @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] add iota_armor_broken_drop
tag @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] remove iota_armor_buffer
`);
const slots=[...Array.from({length:9},(_,i)=>'hotbar.'+i),...Array.from({length:27},(_,i)=>'inventory.'+i),'weapon.offhand','armor.head','armor.chest','armor.legs','armor.feet'];
write('function/tick.mcfunction','execute as @e[type=minecraft:item,tag=iota_armor_broken_drop] run data merge entity @s {Age:0s}\n'+slots.map(slot=>`execute as @a at @s if items entity @s ${slot} *[minecraft:custom_data~{iota_armor_poc:{broken:1b}},minecraft:damage~{durability:{min:1}}] run function iota_armor_poc:restore {slot:"${slot}"}`).join('\n')+'\n');
write('function/restore.mcfunction',`summon minecraft:item ~ ~0.5 ~ {Tags:["iota_armor_restore_buffer"],Invulnerable:1b,NoGravity:1b,PickupDelay:32767s,Item:{id:"minecraft:stone",count:1}}
$item replace entity @e[type=minecraft:item,tag=iota_armor_restore_buffer,limit=1,sort=nearest,distance=..2] contents from entity @s $(slot)
data modify storage iota_armor_poc:scratch item set from entity @e[type=minecraft:item,tag=iota_armor_restore_buffer,limit=1,sort=nearest,distance=..2] Item
`+['equippable','attribute_modifiers'].map(k=>`data remove storage iota_armor_poc:scratch item.components."!minecraft:${k}"
execute if data storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."minecraft:${k}" run data modify storage iota_armor_poc:scratch item.components."minecraft:${k}" set from storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."minecraft:${k}"
execute if data storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."!minecraft:${k}" run data modify storage iota_armor_poc:scratch item.components."!minecraft:${k}" set value {}
`).join('')+`execute store result score #had_data iota_apoc run data get storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.had_data
data remove storage iota_armor_poc:scratch item.components."minecraft:lore"[{translate:"iota.status.broken"}]
execute store result score #lore_size iota_apoc run data get storage iota_armor_poc:scratch item.components."minecraft:lore"
execute if score #lore_size iota_apoc matches 0 if data storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc{had_lore:0b} run data remove storage iota_armor_poc:scratch item.components."minecraft:lore"
data remove storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc
execute store result score #data_size iota_apoc run data get storage iota_armor_poc:scratch item.components."minecraft:custom_data"
execute if score #data_size iota_apoc matches 0 if score #had_data iota_apoc matches 0 run data remove storage iota_armor_poc:scratch item.components."minecraft:custom_data"
data modify entity @e[type=minecraft:item,tag=iota_armor_restore_buffer,limit=1,sort=nearest,distance=..2] Item set from storage iota_armor_poc:scratch item
$item replace entity @s $(slot) from entity @e[type=minecraft:item,tag=iota_armor_restore_buffer,limit=1,sort=nearest,distance=..2] contents
kill @e[type=minecraft:item,tag=iota_armor_restore_buffer,distance=..2]
`);
for(const hook of ['load','tick']){const d=path.join(pack,'data/minecraft/tags/function');fs.mkdirSync(d,{recursive:true});fs.writeFileSync(path.join(d,hook+'.json'),JSON.stringify({values:['iota_armor_poc:'+hook]}));}
console.log(JSON.stringify({pack,scope:'Isolated prototype only; no modules modified',armorFamilies:4,restoreSlots:slots.length}));
