import json, random, re, concurrent.futures, urllib.request
from pathlib import Path
root = Path(__file__).resolve().parents[2]
out=root/'docs/discovery/research/outputs/trading-execution-2026-11-20'
old=root/'docs/discovery/research/outputs/profession-drafts-2026-11-19'
catalog=json.loads((out/'catalogs.json').read_text())['professions']
examples={p['profession']:p['samples'] for p in json.loads((out/'example-plans.json').read_text())}
regions=json.loads((out/'regions.json').read_text())['regions']
regional=json.loads((out/'regional-prices.json').read_text())
stages=['Novice','Apprentice','Journeyman','Expert','Master','Secret']
quotes=[];professions=[]
keys=['id','enchantment','level','quality','stored','potion','stew','destination','banner','dye']
def identity(a):return tuple(str(a.get(k,'')) for k in keys)
def keep(a):return {k:v for k,v in a.items() if k not in ['discountPolicy','valueBasis','farmability','certainty','availability','originRequired']}
for p in catalog:
 slots=[];lookup={}
 for row in p['rows']:
  for direction,field in [('sell','sales'),('buy','purchases')]:
   for s in row[field]:
    ids=[]
    for a in s['candidates']:
     idx=len(quotes);q=keep(a);q.update(stage=row['stage'],direction=direction,layer='ordinary');quotes.append(q);ids.append(idx);lookup[(row['stage'],direction,s['slot'],identity(a))]=idx
    slots.append(dict(stage=row['stage'],direction=direction,candidates=ids))
 samples=[[lookup[(a['stage'],a['direction'],a['slot'],identity(a))] for a in sample] for sample in examples[p['id']]]
 region_data={}
 for region in regions:
  pools={}
  for direction,source in [('sell',regional['sales']),('buy',regional['imports'])]:
   pool=[]
   for a in source:
    if a['profession']!=p['id'] or a['region']!=region:continue
    q=keep(a);q.update(direction=direction,layer='regional',referenceVU=a.get('referenceVU',a['unitEmeralds']),uses=a['stockUnits']//a['lot']);idx=len(quotes);quotes.append(q);pool.append(idx)
   pools[direction]=pool
  if not any(pools.values()):continue
  region_samples=[]
  for i,sample in enumerate(samples):
   rng=random.Random(p['id']+region+str(i));chosen=[]
   for direction in ['sell','buy']:
    ordinary_ids={quotes[n]['id'] for n in sample if quotes[n]['direction']==direction}
    candidates=[n for n in pools[direction] if quotes[n]['id'] not in ordinary_ids]
    rng.shuffle(candidates);count=rng.choice([1,2]) if len(candidates)>=2 else len(candidates)
    for n in candidates[:count]:
     q=dict(quotes[n],stage=rng.choice(stages[:4]));idx=len(quotes);quotes.append(q);chosen.append(idx)
   region_samples.append(chosen)
  region_data[region]={'samples':region_samples,'pools':pools}
 professions.append({'id':p['id'],'samples':samples,'slots':slots,'regional':region_data})
names={a['id'].split(':')[1] for a in quotes}|{'emerald','emerald_block'}
cache=json.loads((old/'preview-data.json').read_text())['icons']
base='https://cdn.jsdelivr.net/gh/InventivetalentDev/minecraft-assets@1.21.11/assets/minecraft/textures/'
special={'compass':'compass_16','recovery_compass':'recovery_compass_16','clock':'clock_00','crossbow':'crossbow_standby'}
block_alias={'cactus':'cactus_side','kelp':'kelp','mud_bricks':'mud_bricks','red_sandstone':'red_sandstone_top','sandstone':'sandstone_top','pale_moss_block':'pale_moss_block','cherry_log':'cherry_log','small_dripleaf':'small_dripleaf_top','sweet_berries':'sweet_berries','blue_egg':'blue_egg','brown_egg':'brown_egg','open_eyeblossom':'open_eyeblossom'}
def icon(n):
 for part in ['item/'+special.get(n,n),'block/'+block_alias.get(n,n),'block/'+n+'_stage0']:
  url=base+part+'.png'
  try:
   with urllib.request.urlopen(urllib.request.Request(url,method='HEAD',headers={'User-Agent':'Iota-preview'}),timeout=12) as response:
    if response.status==200:return n,{'kind':'item' if part.startswith('item/') or n in ['pink_petals','small_dripleaf','open_eyeblossom','pointed_dripstone','lily_pad','azalea','cactus_flower'] else 'block','url':url}
  except Exception:pass
 return n,{'kind':'missing','url':base+'item/barrier.png'}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
 cache.update(dict(ex.map(icon,sorted(names-set(cache)))))
missing=[n for n in names if cache[n]['kind']=='missing']
assert not missing,missing
payload={'professions':professions,'quotes':quotes,'icons':{n:cache[n] for n in names},'regions':list(regions),'status':'Reference-price design preview; no native discounts or transactions implemented'}
(out/'preview-data.json').write_text(json.dumps(payload,separators=(',',':')))
fragment=Path('C:/Users/Ivan/.codex/visualizations/2026/11/16/01a1e661-66fd-7850-8264-8da8e32c1749/iota-villager-trades.html')
s=fragment.read_text()
s=re.sub(r'(<script type="application/json" id="iota-trade-data">).*?(</script>)',lambda m:m[1]+json.dumps(payload,separators=(',',':'))+m[2],s,flags=re.S)
assert '"regions"' in s
if 'id="iota-region"' not in s:s=s.replace('  </div>\n  <div class="window">','    <label>Regional offers<select id="iota-region" aria-label="Regional offers"><option value="none">Ordinary only</option></select></label>\n  </div>\n  <div class="window">',1)
s=s.replace("stage:4,sample:0,selected:null,", "stage:4,sample:0,region:'none',selected:null,")
s=s.replace("{inputs:[{id:a.id,count:1,a},...(a.lot>1?[{id:a.id,count:a.lot-1,a}]:[])]", "{inputs:[{id:a.id,count:a.lot,a}]")
s=s.replace('sample:state.sample,selected:state.selected','sample:state.sample,region:state.region,selected:state.selected')
s=s.replace("$('profession').value=p.id;$('stage').value=state.stage;$('sample').value=state.sample;", "$('profession').value=p.id;$('stage').value=state.stage;$('sample').value=state.sample;$('region').value=state.region;")
s=s.replace("const chosen=p.samples[state.sample].filter(n=>stages.indexOf(data.quotes[n].stage)<=state.stage);", "const extras=p.regional?.[state.region]?.samples[state.sample]||[];const chosen=[...p.samples[state.sample],...extras].filter(n=>stages.indexOf(data.quotes[n].stage)<=state.stage).sort((a,b)=>(data.quotes[a].direction==='sell'?0:1)-(data.quotes[b].direction==='sell'?0:1));")
s=s.replace("${a.price.value} E · ${a.stockUnits} in stock", "${a.price.value} E · ${a.stockUnits} in stock${a.layer==='regional'?' · '+(a.direction==='sell'?'Local':'Import'):''}")
s=s.replace("a.stage==='Secret'?'120 minutes':p.id==='toolsmith'?'60 min · 30 min with eligible sleep':'60 min · 30 min with eligible sleep'", "a.layer==='regional'?'60 min · no sleep credit':a.stage==='Secret'?'120 minutes':'60 min · 30 min with eligible sleep'")
s=s.replace("const selectedSlot=p.slots.find(s=>s.candidates.includes(state.selected));", "const selectedSlot=p.slots.find(s=>s.candidates.includes(state.selected))||(a.layer==='regional'?{candidates:p.regional[state.region].pools[a.direction]}:null);")
s=s.replace("Preview only. Samples are different villagers, not in-game rerolls.", "Reference-price preview; native discount safety is unresolved. Regional offers are additive. Samples illustrate different villagers, not probability estimates or in-game rerolls.")
if "data.regions.map" not in s:s=s.replace("$('inventory').innerHTML=", "$('region').innerHTML='<option value=\"none\">Ordinary only</option>'+data.regions.map(r=>`<option value=\"${r}\">${title(r)}</option>`).join('');\n    $('region').addEventListener('change',e=>{state.region=e.target.value;state.selected=null;render();save();});\n    $('inventory').innerHTML=",1)
assert len(s.encode())<1_000_000
fragment.write_text(s)
(out/'preview-sync-results.json').write_text(json.dumps({'professions':len(professions),'quotes':len(quotes),'missingIcons':missing,'bytes':len(s.encode()),'normalCounts':[4,6,8,10,12,13],'regionalLayer':'Independent draws/unlocks; excluded ordinary duplicates before drawing count'},indent=2))
print(json.dumps({'professions':len(professions),'quotes':len(quotes),'bytes':len(s.encode()),'missing':missing}))

