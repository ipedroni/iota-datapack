import assert from 'node:assert/strict';
import {nearestBlockPayout} from '../outputs/trading_economy-discovery-2026-11-19/market-currency.mjs';

assert.equal(nearestBlockPayout(71).emeralds,72);
assert.equal(nearestBlockPayout(71,71).emeralds,63,'Unsafe upward rounding must be rejected.');
assert.equal(nearestBlockPayout(85.5,100).emeralds,81,'Ties choose the lower payout.');
let checks=0;
for(let cents=6401;cents<=57600;cents++){
 const target=cents/100,cap=target/.95,p=nearestBlockPayout(target,cap);
 assert(p.count>=1&&p.count<=64&&Number.isInteger(p.count));
 assert.equal(p.emeralds,9*p.count);assert(p.emeralds<=cap+1e-8);
 for(const n of [Math.floor(target/9),Math.ceil(target/9)])if(n>=1&&n<=64&&9*n<=cap+1e-8)assert(Math.abs(p.emeralds-target)<=Math.abs(9*n-target)+1e-8);
 checks++;
}
assert.throws(()=>nearestBlockPayout(590));
console.log(`PASS: ${checks} representable payout targets, 71->72 example, unsafe-rounding guard, tie rule and overflow rejection.`);
