"""Independent native-stack and integer-price checks; no gameplay execution."""
import csv
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = root / 'docs/discovery/research/outputs/profession-drafts-2026-11-19'
catalogs = json.loads((out / 'catalogs.json').read_text())['professions']
native = json.loads((root / 'vendor/generated/reports/items.json').read_text())
plans = json.loads((out / 'example-plans.json').read_text())
count = 0
for profession in catalogs:
    assert len(profession['rows']) == 6
    for row in profession['rows']:
        assert len(row['sales']) == (1 if row['stage'] == 'Secret' else 2)
        for side in ('sales', 'purchases'):
            for slot in row[side]:
                for q in slot['candidates']:
                    count += 1
                    assert q['id'] in native
                    assert q['lot'] * q['uses'] == q['stockUnits']
                    assert all(isinstance(q[k], int) and q[k] > 0
                               for k in ('lot', 'uses', 'stockUnits'))
                    assert len(q['inputCosts']) <= 2
                    assert q['inputCosts'][0]['count'] == 1
                    for cost in q['inputCosts']:
                        maximum = native[cost['id']]['components']['minecraft:max_stack_size']
                        assert 1 <= cost['count'] <= maximum
                    payment_value = sum(p['count'] * (9 if p['item'] == 'emerald_block' else 1)
                                        for p in q['price']['payment'])
                    assert payment_value == q['price']['value']
                    if side == 'purchases':
                        assert len(q['price']['payment']) == 1
                        assert all(c['id'] == q['id'] for c in q['inputCosts'])
                        assert sum(c['count'] for c in q['inputCosts']) == q['lot']
                        assert payment_value <= q['referenceVU'] * q['lot'] + 1e-7
                    else:
                        encoded = sum(c['count'] * (9 if c['id'].endswith('emerald_block') else 1)
                                      for c in q['inputCosts'])
                        assert encoded == payment_value
                        assert payment_value >= q['referenceVU'] * q['lot']
                    for p in q['price']['payment']:
                        assert 1 <= p['count'] <= 64

for plan in plans:
    offers = plan['offers']
    assert len(offers) == 20
    for direction in ('sell', 'buy'):
        keys = [x['key'] for x in offers if x['direction'] == direction]
        assert len(keys) == len(set(keys))
    assert [x['direction'] for x in offers] == ['sell'] * 11 + ['buy'] * 9

with (out / 'prices-and-stock.csv').open(newline='', encoding='utf-8') as handle:
    rows = list(csv.DictReader(handle))
assert len(rows) == count
result = {'passed': True, 'candidateQuotes': count, 'professions': len(catalogs),
          'samplePlans': len(plans), 'scope': 'Independent arithmetic/native stack validation, not a game test.'}
(out / 'independent-validation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
