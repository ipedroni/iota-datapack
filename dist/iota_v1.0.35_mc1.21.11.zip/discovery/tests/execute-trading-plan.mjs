import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {nearestBlockPayout} from '../outputs/trading_economy-discovery-2026-11-19/market-currency.mjs';
const root=path.resolve(import.meta.dirname,'../../..'),out=path.join(root,'docs/discovery/research/outputs/trading-execution-2026-11-20');
fs.mkdirSync(out,{recursive:true});
const load=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
const items=new Map(load('docs/discovery/research/outputs/trading_economy-discovery-2026-11-19/items.json').map(a=>[a.id,a]));
const farms=new Map(load('docs/discovery/research/outputs/trading_economy-discovery-2026-11-19/farmability-items.json').map(a=>[a.id,a]));
const prior=load('docs/discovery/research/outputs/trading_profession-drafts-2026-11-19/catalogs.json').professions;
const stages=['Novice','Apprentice','Journeyman','Expert','Master','Secret'];
const x=(id,extra={})=>({id:'minecraft:'+id,...extra});
const pool=(...a)=>a.map(v=>typeof v==='string'?x(v):v);
const ench=(id,e,l)=>x(id,{enchantment:e,level:l});
const gear=(mats,families,quality)=>mats.flatMap(m=>families.map(f=>x(m+'_'+f,quality?{quality}:{})));
const enchanted=(mats,families,levels,es=['efficiency','unbreaking'])=>mats.flatMap(m=>families.flatMap(f=>es.flatMap(e=>levels.filter(l=>l<=JSON.parse(fs.readFileSync(path.join(root,'vendor/generated/data/minecraft/enchantment',e+'.json'),'utf8')).max_level).map(l=>ench(m+'_'+f,e,l)))));
const row=(stage,sales,purchases=[])=>({stage,sales:[{candidates:sales}],purchases:purchases.length?[{candidates:purchases}]:[]});
const old=(id,stage,dir,index)=>prior.find(p=>p.id===id).rows.find(r=>r.stage===stage)[dir][index].candidates.map(a=>{
 const keep=['id','enchantment','level','quality','stored','potion','stew','destination','service','serviceVU','estimateVU','banner','dye','weight'];return Object.fromEntries(keep.filter(k=>a[k]!==undefined).map(k=>[k,a[k]]));
});
const tool=['pickaxe','axe','shovel','hoe'],armor=['helmet','chestplate','leggings','boots'],weapons=['sword','spear'];
const smithSecret=(families,es)=>[
 x('diamond',{weight:45}),x('netherite_scrap',{weight:5}),
 ...['diamond','netherite'].flatMap(m=>{const a=enchanted([m],families,[3,4,5],es);return a.map(v=>({...v,weight:(m==='diamond'?45:5)/a.length}));})
];
const defs=[];
function add(id,rows,decision){defs.push({id,rows,decision});}
add('toolsmith',[
 row('Novice',gear(['copper','iron'],tool).map(a=>({...a,weight:a.id.includes(':copper_')?3:1})),pool('flint')),
 row('Apprentice',gear(['copper','iron'],tool),pool('coal','charcoal','copper_ingot','iron_ingot')),
 row('Journeyman',[...pool('copper_ingot','iron_ingot'),...gear(['iron','golden'],tool)],[...pool('iron_ingot','gold_ingot'),...gear(['copper','iron'],tool,'plain')]),
 row('Expert',[...pool('iron_ingot','gold_ingot'),...enchanted(['golden','diamond'],tool,[1,2])],[...pool('gold_ingot','diamond'),...gear(['iron','golden'],tool,'tool-basic')]),
 row('Master',enchanted(['golden','diamond'],tool,[1,2,3],['efficiency','unbreaking','fortune','silk_touch']),gear(['golden','diamond'],tool,'tool-advanced')),
 row('Secret',smithSecret(tool,['efficiency','unbreaking','fortune','silk_touch']))
],'Keep Flint fixed and Coal/Charcoal draw at Novice. Apprentice draws the other fuel OR Copper/Iron Ingots; Journeyman draws Iron/Gold raw materials OR a plain Copper/Iron tool; Expert draws Gold/Diamond raw materials OR an enchanted Iron/Gold tool. This preserves the selected raw-material staircase; the other fuel is no longer guaranteed on every merchant under the smaller slot budget, a delegated choice for review. Journeyman/Expert retail draw a material OR a tier-appropriate tool. No Flint retail; no Netherite buys.' );
add('armorer',[
 row('Novice',gear(['copper','iron'],armor),pool('coal','charcoal')),
 row('Apprentice',gear(['copper','iron'],armor),pool('copper_ingot','iron_ingot')),
 row('Journeyman',gear(['iron','golden'],armor),[...pool('iron_ingot','gold_ingot'),...gear(['copper','iron'],armor,'plain')]),
 row('Expert',[...pool('iron_ingot','gold_ingot'),...enchanted(['golden','diamond'],armor,[1,2],['protection','unbreaking'])],[...pool('gold_ingot','diamond'),...gear(['iron','golden'],armor,'armor-basic')]),
 row('Master',enchanted(['golden','diamond'],armor,[2,3],['protection','unbreaking']),gear(['golden','diamond'],armor,'armor-advanced')),
 row('Secret',smithSecret(armor,['protection','unbreaking']))
],'Two different Novice armor slots; useful enchanted armor from Expert. Larger metal intake and smaller retail stock than Toolsmith. No armor kit wrapper.' );
add('weaponsmith',[
 row('Novice',gear(['copper','iron'],weapons),pool('coal','charcoal')),
 row('Apprentice',gear(['copper','iron'],weapons),pool('copper_ingot','iron_ingot')),
 row('Journeyman',gear(['iron','golden'],weapons),[...pool('iron_ingot','gold_ingot'),...gear(['copper','iron'],weapons,'plain')]),
 row('Expert',[...pool('iron_ingot','gold_ingot'),...enchanted(['golden','diamond'],weapons,[1,2],['sharpness','unbreaking'])],[...pool('gold_ingot','diamond'),...gear(['iron','golden'],weapons,'weapon-basic')]),
 row('Master',enchanted(['golden','diamond'],weapons,[2,3],['sharpness','unbreaking']),gear(['golden','diamond'],weapons,'weapon-advanced')),
 row('Secret',smithSecret(weapons,['sharpness','unbreaking']))
],'Swords and Spears; no Axes. Different first two families. Smaller metal intake and larger retail stock than Toolsmith. Native enchantment caps apply.' );
add('fletcher',[
 row('Novice',pool('bow','arrow'),pool('feather','string')),
 row('Apprentice',pool('crossbow','spectral_arrow'),pool('flint','stick')),
 row('Journeyman',pool(ench('bow','power',1),ench('crossbow','quick_charge',1)),[...gear([''],[]),...pool(x('bow',{quality:'plain'}),x('crossbow',{quality:'plain'}))]),
 row('Expert',pool(ench('bow','power',2),ench('crossbow','quick_charge',2)),pool(x('bow',{quality:'ranged-basic'}),x('crossbow',{quality:'ranged-basic'}))),
 row('Master',pool(ench('bow','power',3),ench('crossbow','quick_charge',3)),pool(x('bow',{quality:'ranged-advanced'}),x('crossbow',{quality:'ranged-advanced'}))),
 row('Secret',pool(ench('bow','power',5),ench('bow','infinity',1),ench('crossbow','multishot',1)))
],'Ammunition and useful weapons begin early; one slot replaces simultaneous Bow+Arrow offers. No new arrow recipes or kits.' );
add('leatherworker',[
 row('Novice',gear(['leather'],armor),pool('rotten_flesh','leather')),
 row('Apprentice',pool('leather','rabbit_hide'),pool('rabbit_hide','string')),
 row('Journeyman',pool('leather_horse_armor'),gear(['leather'],armor,'plain')),
 row('Expert',enchanted(['leather'],armor,[2],['protection','unbreaking']),gear(['leather'],armor,'armor-basic')),
 row('Master',enchanted(['leather'],armor,[3],['protection','unbreaking']),gear(['leather'],armor,'armor-advanced')),
 row('Secret',pool({...ench('leather_chestplate','protection',4),weight:95},{...ench('leather_chestplate','mending',1),weight:5}))
],'Retain non-slaughter inputs and Hide/Leather supply; later rewards are reusable enchanted leather equipment. Selected Mending is a small earned Secret chance.' );
add('farmer',[
 row('Novice',pool('wheat_seeds','beetroot_seeds','carrot','potato'),pool('wheat_seeds')),
 row('Apprentice',pool('bread','apple'),pool('beetroot_seeds','pumpkin_seeds','melon_seeds')),
 row('Journeyman',pool('hay_block','pumpkin_pie'),pool('wheat','carrot','potato','beetroot','pumpkin','melon')),
 row('Expert',pool('golden_carrot'),pool('bread','baked_potato')),
 row('Master',pool('cake','honey_bottle'),pool('pumpkin_pie')),
 row('Secret',pool('golden_apple'))
],'Wheat Seeds fixed introductory buy; basic seed retail only Novice. A second common seed buy at Apprentice; crop outlet at Journeyman. No Sniffer seeds.' );
add('butcher',[
 row('Novice',pool('cooked_chicken','cooked_porkchop'),pool('egg','milk_bucket')),
 row('Apprentice',pool('cooked_beef','cooked_mutton'),pool('carrot','potato','wheat')),
 row('Journeyman',pool('cooked_cod','cooked_salmon'),pool('cod','salmon')),
 row('Expert',pool('cooked_rabbit','rabbit_stew'),pool('red_mushroom','brown_mushroom','beetroot')),
 row('Master',pool('pumpkin_pie','golden_carrot'),pool('mushroom_stew','beetroot_soup')),
 row('Secret',pool(x('suspicious_stew',{stew:'saturation',estimateVU:10})))
],'Supply meat and meals; buy complementary foods, Eggs/Milk first. A Milk Bucket quote explicitly includes the consumed bucket; no invisible container refund.' );
add('fisherman',[
 row('Novice',pool('cod','salmon'),pool('string','stick')),
 row('Apprentice',pool('cooked_cod','fishing_rod'),pool('coal','charcoal')),
 row('Journeyman',pool('bucket','cooked_salmon'),pool(x('fishing_rod',{quality:'plain'}))),
 row('Expert',pool('tropical_fish_bucket','pufferfish_bucket'),pool('glass_bottle')),
 row('Master',pool(ench('fishing_rod','luck_of_the_sea',2),ench('fishing_rod','lure',2)),pool(x('fishing_rod',{quality:'fishing-advanced'}))),
 row('Secret',old('fisherman','Secret','sales',0))
],'Keep the praised fish/equipment identity and no fish purchases. Only Master buys enchanted rods; complement via materials, not an earlier overlapping rod contract.' );
add('shepherd',[
 row('Novice',pool('white_wool','string'),pool('white_wool','string')),
 row('Apprentice',pool('white_carpet','red_dye','blue_dye','yellow_dye'),pool('red_dye','blue_dye','yellow_dye')),
 row('Journeyman',pool('white_banner','shears'),pool('black_wool','gray_wool','brown_wool')),
 row('Expert',pool('red_wool','blue_wool','yellow_wool','black_dye','white_dye'),pool('white_carpet','red_carpet','blue_carpet','yellow_carpet')),
 row('Master',pool('red_carpet','blue_carpet','yellow_carpet'),pool('white_banner')),
 row('Secret',old('shepherd','Secret','sales',0))
],'Include String retail early; remove Beds/Paintings from both directions. Textile/dye/banner specialist; decorative Secret remains a documented low-impact exception to resource shortcuts.' );
add('librarian',[
 row('Novice',pool('book','bookshelf'),pool('paper')),
 row('Apprentice',pool('lapis_lazuli'),pool('ink_sac','book')),
 row('Journeyman',pool(x('enchanted_book',{stored:true,enchantment:'efficiency',level:1}),x('enchanted_book',{stored:true,enchantment:'unbreaking',level:1})),pool('bookshelf','glass')),
 row('Expert',pool('clock','glass'),pool('amethyst_shard','glow_ink_sac')),
 row('Master',pool(x('enchanted_book',{stored:true,enchantment:'efficiency',level:3}),x('enchanted_book',{stored:true,enchantment:'unbreaking',level:3}),x('enchanted_book',{stored:true,enchantment:'fortune',level:2})),pool(x('enchanted_book',{stored:true,enchantment:'efficiency',level:2}),x('enchanted_book',{stored:true,enchantment:'unbreaking',level:2}))),
 row('Secret',pool(x('echo_shard',{weight:60}),x('enchanted_book',{stored:true,enchantment:'mending',level:1,weight:20}),x('enchanted_book',{stored:true,enchantment:'frost_walker',level:2,weight:20})))
],'Maximum two ordinary book sales, with distinct ranks. Echo Shard Secret candidate; Mending only rare Secret here, never ordinary fixed retail. Natural loot remains a separate access route.' );
add('cartographer',[
 row('Novice',pool('map','compass'),pool('paper','glass_pane')),
 row('Apprentice',[...pool('spyglass'),...old('cartographer','Apprentice','sales',1)],pool('ink_sac','amethyst_shard')),
 row('Journeyman',[...old('cartographer','Journeyman','sales',0),...old('cartographer','Journeyman','sales',1)],pool('map','compass')),
 row('Expert',[...old('cartographer','Expert','sales',0),...old('cartographer','Expert','sales',1)],pool('spyglass','clock')),
 row('Master',[...old('cartographer','Master','sales',0),...pool('recovery_compass')],pool('recovery_compass')),
 row('Secret',old('cartographer','Secret','sales',0))
],'Retain navigation focus and useful map destinations, one draw per level. Recovery Compass always one unit; chain repriced coherently. Map service still requires real map generation.' );
add('cleric',[
 row('Novice',pool('redstone','lapis_lazuli'),pool('rotten_flesh','nether_wart')),
 row('Apprentice',pool('glowstone_dust','quartz'),pool('glass_bottle','red_mushroom','brown_mushroom')),
 row('Journeyman',pool('experience_bottle','ender_pearl'),pool('spider_eye','blaze_powder')),
 row('Expert',[...old('cleric','Expert','sales',0),...old('cleric','Expert','sales',1)],pool('magma_cream','phantom_membrane')),
 row('Master',[...old('cleric','Master','sales',0),...old('cleric','Master','sales',1)],pool('ghast_tear')),
 row('Secret',pool(x('wind_charge',{weight:75}),x('ghast_tear',{weight:25})))
],'Reagents and brewing services; Secret only selected Wind Charge/Ghast Tear candidates. No implicit Breeze Rod, Heavy Core or Nether Star offer.' );
add('mason',[
 row('Novice',pool('flint','stone'),pool('cobblestone','gravel')),
 row('Apprentice',pool('clay_ball','brick'),pool('sand','clay_ball')),
 row('Journeyman',pool('terracotta','quartz_block'),pool('sandstone','glass')),
 row('Expert',pool('stone_bricks','chiseled_stone_bricks'),pool('terracotta','stone_bricks')),
 row('Master',pool('prismarine','sea_lantern'),pool('quartz_block')),
 row('Secret',pool('calcite','amethyst_block','purpur_block'))
],'Retain bulk builder supply and early Flint. One regional complement can supply omitted palettes; do not turn the Stonecutter into a trade-only item.' );
// Latest user instruction: Novice has two sales and two buys; later ordinary levels add one each.
defs.find(p=>p.id==='armorer').rows[1].purchases[0].candidates=pool('leather');
defs.find(p=>p.id==='weaponsmith').rows[1].purchases[0].candidates=pool('flint');
defs.find(p=>p.id==='librarian').rows[1].purchases[0].candidates=pool('book');
const noviceExtraBuys={toolsmith:pool('coal','charcoal'),armorer:pool('copper_ingot','iron_ingot'),weaponsmith:pool('copper_ingot','iron_ingot'),fletcher:pool('string','feather'),leatherworker:pool('string','rabbit_hide'),farmer:pool('wheat','carrot','potato'),butcher:pool('egg','milk_bucket'),fisherman:pool('string','stick'),shepherd:pool('string','white_wool'),librarian:pool('ink_sac'),cartographer:pool('glass_pane','paper'),cleric:pool('nether_wart','rotten_flesh'),mason:pool('gravel','cobblestone')};
const noviceExtraSales={farmer:pool('bread','carrot','potato'),shepherd:pool('string','white_wool'),librarian:pool('bookshelf','book'),mason:pool('stone','flint')};
for(const p of defs){const r=p.rows[0];r.sales.push({candidates:noviceExtraSales[p.id]??r.sales[0].candidates.map(a=>({...a}))});r.purchases.push({candidates:noviceExtraBuys[p.id]});}
// Explicit candidate-market revaluation, never edits the independent research matrix.
const valueOverrides={ 'minecraft:echo_shard':4 };
valueOverrides['minecraft:recovery_compass']=8*valueOverrides['minecraft:echo_shard']+items.get('minecraft:compass').value_vu+.053333;
const premiums={plain:0,'tool-basic':8,'tool-advanced':16,'armor-basic':8,'armor-advanced':16,'weapon-basic':8,'weapon-advanced':16,'ranged-basic':8,'ranged-advanced':16,'fishing-advanced':16};
const premium=(e,l)=>e==='mending'?64:e==='silk_touch'?32:e==='fortune'?32+8*(l-1):8*l;
function valuation(a){
 let v=a.estimateVU??valueOverrides[a.id]??items.get(a.id)?.value_vu;
 if(a.service==='exploration_map')v=items.get('minecraft:map').value_vu+a.serviceVU;
 if(a.stored)v=items.get('minecraft:book').value_vu;
 if(a.enchantment)v+=premium(a.enchantment,a.level);
 if(a.quality)v+=premiums[a.quality];if(a.banner)v+=a.serviceVU??8;
 assert(Number.isFinite(v)&&v>0,'Missing price '+a.id);return v;
}
function currency(n,buying,cap){
 if(buying){if(n<=64){const z=Math.max(1,Math.floor(n));return {value:z,payment:[{item:'emerald',count:z}]};}const p=nearestBlockPayout(n,cap);return {value:p.emeralds,payment:[{item:'emerald_block',count:p.count}]};}
 const z=Math.max(1,Math.ceil(n));if(z<=64)return {value:z,payment:[{item:'emerald',count:z}]};
 const b=Math.min(64,Math.floor(z/9)),e=z-9*b;assert(e<=64,'Retail exceeds UI');return {value:z,payment:[...(e?[{item:'emerald',count:e}]:[]),{item:'emerald_block',count:b}]};
}
const smithStock={armorer:{buy:128,sell:16},toolsmith:{buy:64,sell:32},weaponsmith:{buy:32,sell:64}};
function quote(a,dir,profession,stage){
 const item=items.get(a.id);assert(item,'Unknown item '+a.id);const v=valuation(a),name=a.id.slice(10),f=farms.get(a.id);
 const unit=item.stack===1||a.service||['recovery_compass','compass','spyglass','clock','echo_shard','netherite_scrap','enchanted_book'].includes(name);
 let cap=unit?2:64;if(['farmer','butcher','fisherman'].includes(profession)&&!unit)cap=128;
 if(profession==='mason'&&!unit)cap=dir==='sell'?256:128;
 if(smithStock[profession]&&name.endsWith('_ingot'))cap=smithStock[profession][dir];
 if(['coal','charcoal'].includes(name)&&dir==='buy')cap=128;
 if(name==='diamond')cap=dir==='buy'?4:2;
 if(stage==='Secret')cap=profession==='mason'?64:1;
 const quantities=unit||stage==='Secret'&&profession!=='mason'?[1]:[1,2,4,8,16,32,64].filter(q=>q<=Math.min(item.stack,cap));
 const options=[];
 for(const lot of quantities){if(.95*v*lot<1||1.05*v*lot>640)continue;const bid=currency(.95*v*lot,true,v*lot),ask=currency(Math.max(1.05*v*lot,bid.value+1),false);options.push({lot,bid,ask,error:Math.max(Math.abs(bid.value/(.95*v*lot)-1),ask.value/(1.05*v*lot)-1)});}
 assert(options.length,'Unencodable '+a.id);options.sort((a,b)=>a.error-b.error||a.lot-b.lot);const z=options[0],price=dir==='buy'?z.bid:z.ask;
 const inputCosts=dir==='buy'?[{id:a.id,count:z.lot}]:price.payment.map(p=>({id:'minecraft:'+p.item,count:p.count}));
 assert(cap%z.lot===0);assert(z.bid.value<z.ask.value);for(const p of inputCosts)assert(p.count>0&&p.count<=items.get(p.id).stack);
 return {...a,direction:dir,lot:z.lot,price,inputCosts,unitEmeralds:price.value/z.lot,stockUnits:cap,uses:cap/z.lot,referenceVU:v,valueBasis:valueOverrides[a.id]?'Agent-selected market override; independent matrix unchanged':'Provisional matrix plus explicit service/enchantment premium',roundingError:z.error,farmability:{status:f?.status??'unknown',pressure:f?.pressure??null},discountPolicy:'Reference quote only; native Hero remains a runtime release gate'};
}
const key=a=>JSON.stringify([a.id,a.enchantment??null,a.level??null,a.quality??null,a.potion??null,a.stew??null,a.destination??null,a.banner??null,a.dye??null]);
function compatible(old,a){
 if(old.id!==a.id)return false;
 if(old.quality&&a.quality){if(old.quality==='plain'||a.quality==='plain')return false;return true;}
 return key(old)===key(a);
}
function plan(p,seed=0,forced){
 const slots=p.rows.flatMap(r=>[...r.sales.map(s=>({...s,stage:r.stage,direction:'sell'})),...r.purchases.map(s=>({...s,stage:r.stage,direction:'buy'}))]);
 const seen={sell:[],buy:[]},early=new Set(),chosen=[];
 function solve(i){if(i===slots.length)return true;const s=slots[i],arr=[...s.candidates];if(seed)arr.sort((a,b)=>hash(key(a)+seed+s.slot)-hash(key(b)+seed+s.slot));
  for(const a of arr){if(forced?.slot===s.slot&&key(a)!==forced.key)continue;if(seen[s.direction].some(v=>compatible(v,a)))continue;
   const family=['toolsmith','armorer','weaponsmith'].includes(p.id)&&s.direction==='sell'&&(s.stage==='Novice'||p.id!=='weaponsmith'&&s.stage==='Apprentice')?a.id.split('_').at(-1):null;
   if(family&&early.has(family))continue;seen[s.direction].push(a);if(family)early.add(family);chosen.push({...a,stage:s.stage,slot:s.slot});
   if(solve(i+1))return true;chosen.pop();seen[s.direction].pop();if(family)early.delete(family);
  }return false;
 }
 assert(solve(0),'No complete plan '+p.id);return chosen.sort((a,b)=>(a.direction==='sell'?0:1)-(b.direction==='sell'?0:1));
}
function hash(s){let a=2166136261;for(const c of s)a=Math.imul(a^c.charCodeAt(0),16777619);return a>>>0;}
const catalogs=defs.map(p=>{let n=0;return {...p,rows:p.rows.map(r=>({...r,sales:r.sales.map(s=>({slot:++n,candidates:s.candidates.map(a=>quote(a,'sell',p.id,r.stage))})),purchases:r.purchases.map(s=>({slot:++n,candidates:s.candidates.map(a=>quote(a,'buy',p.id,r.stage))}))}))};});
let count=0;for(const p of catalogs){for(const r of p.rows){assert.equal(r.sales.length,r.stage==='Novice'?2:1);assert.equal(r.purchases.length,r.stage==='Novice'?2:r.stage==='Secret'?0:1);for(const s of [...r.sales,...r.purchases])for(const a of s.candidates){plan(p,0,{slot:s.slot,key:key(a)});count++;}}}
const examples=catalogs.map(p=>({profession:p.id,samples:Array.from({length:4},(_,i)=>plan(p,i+1))}));
for(const p of examples)for(const s of p.samples){assert.equal(s.length,13);assert.equal(s.filter(a=>a.stage==='Secret').length,1);}
const quotes=catalogs.flatMap(p=>p.rows.flatMap(r=>[...r.sales,...r.purchases].flatMap(s=>s.candidates.map(a=>({...a,profession:p.id,stage:r.stage,slot:s.slot})))));
assert(quotes.filter(a=>a.direction==='buy').every(a=>a.inputCosts.length===1));
assert(!quotes.some(a=>a.profession==='toolsmith'&&a.direction==='sell'&&a.id==='minecraft:flint'));
assert(!quotes.some(a=>a.profession==='shepherd'&&/(bed|painting)$/.test(a.id)));
assert(!quotes.some(a=>a.profession==='fisherman'&&a.direction==='buy'&&/(cod|salmon|fish)$/.test(a.id)));
function accepts(b,a){
 if(b.id!==a.id)return false;if(b.enchantment)return a.enchantment===b.enchantment&&a.level===b.level;
 if(b.potion)return b.potion===a.potion;if(!b.quality)return true;if(b.quality==='plain')return !a.enchantment;
 const adv=b.quality.endsWith('advanced'),l=a.level??0,e=a.enchantment;if(adv&&e==='mending')return true;if(e==='unbreaking'&&l>=(adv?2:1))return true;
 const eByPrefix={tool:['efficiency',...(adv?['fortune']:[])],armor:['protection'],weapon:['sharpness'],ranged:['power','quick_charge'],fishing:['luck_of_the_sea','lure']};
 return (eByPrefix[b.quality.split('-')[0]]??[]).includes(e)&&l>=(e==='fortune'?1:adv?2:1);
}
let pairs=0;const discounted=[];
for(const b of quotes.filter(a=>a.direction==='buy'))for(const a of quotes.filter(a=>a.direction==='sell'&&accepts(b,a))){assert(b.unitEmeralds<a.unitEmeralds,'Reference resale loop '+a.id);pairs++;const aCount=a.inputCosts[0].count,bCount=b.lot;
 const heroA=Math.max(1,aCount-Math.max(1,Math.floor(.55*aCount))),heroB=Math.max(1,bCount-Math.max(1,Math.floor(.55*bCount)));
 const retailDiscount=a.price.payment[0].item==='emerald'?a.price.value-aCount+heroA:a.price.value-9*(aCount-heroA);
 const discountedBid=b.price.value/heroB,discountedAsk=retailDiscount/a.lot;
 if(discountedBid>=discountedAsk)discounted.push({id:a.id,seller:a.profession,buyer:b.profession,heroTier:5,ask:discountedAsk,bid:discountedBid,note:'Conservative stress, no gossip; native implementation still needs player validation'});
}
const result={status:'Agent-selected candidate under user delegation; no Trades runtime installed',ordinaryRule:'Novice two sales/two buys; later ordinary levels one of each; Secret one sale',denomination:'1 hypothetical VU per emerald',valueOverrides,smithStock,discountStatus:'Unresolved native runtime gate; reference prices are not discount-safe',professions:catalogs};
fs.writeFileSync(path.join(out,'catalogs.json'),JSON.stringify(result,null,2)+'\n');
fs.writeFileSync(path.join(out,'example-plans.json'),JSON.stringify(examples,null,2)+'\n');
const csv=v=>'"'+String(v??'').replaceAll('"','""')+'"';
const columns=['profession','stage','direction','slot','id','enchantment','level','quality','lot','stockUnits','uses','referenceVU','unitEmeralds','roundingError'];
fs.writeFileSync(path.join(out,'prices-and-stock.csv'),columns.join(',')+'\n'+quotes.map(a=>columns.map(k=>csv(a[k])).join(',')).join('\n')+'\n');
const decisions=defs.map((p,i)=>({id:'P'+String(i+1).padStart(2,'0'),state:'Done',kind:'Delegated design choice, not gameplay implementation',decision:p.decision,evidence:'catalogs.json; unique 13-offer examples; reference-price validation'}));
// Task numbering follows the planning workbook, not the profession array order.
const idByProfession={toolsmith:'P01',armorer:'P02',weaponsmith:'P03',fletcher:'P04',leatherworker:'P05',farmer:'P06',shepherd:'P07',librarian:'P08',butcher:'P09',fisherman:'P10',cartographer:'P11',cleric:'P12',mason:'P13'};
for(let i=0;i<decisions.length;i++)decisions[i].id=idByProfession[defs[i].id];
decisions.push({id:'S01',state:'Done',decision:'Use one persistent Secret sale. Smith weights 45% Diamond/45% enchanted Diamond gear/5% Scrap/5% enchanted Netherite gear. Librarian 60% Echo Shard/20% Mending/20% Frost Walker. Cleric 75% Wind Charges/25% Ghast Tear. Other pools retained as explicit bounded design exceptions, subject to playtest.',evidence:'catalogs.json'},
{id:'S03',state:'Done',decision:'Mending never becomes a guaranteed ordinary merchant offer. Retain natural discovery and rare earned Secret book/leather/fishing supply. Toolsmith does not sell Mending. Existing items and vanilla exploration access remain valid.',evidence:'catalogs.json'},
{id:'E01',state:'Done',decision:'Metal units per refill: Armorer buys128/sells16; Toolsmith64/32; Weaponsmith32/64. Separate lot size from capacity; same timer. Gear ordinary stock2, Secret1.',evidence:'smithStock in catalogs.json'},
{id:'E02',state:'Done',decision:'Candidate market Echo Shard4 VU; Recovery Compass =8 shards + Compass + same 0.053333 craft allowance. One Recovery Compass per transaction, both bid/ask use the new reference. Independent research matrix unchanged.',evidence:'valueOverrides; prices-and-stock.csv'},
{id:'T01',state:'To research',decision:'Honor single-stack inputs. Reference quotes generated; native Hero stress exposes resale loops. priceMultiplier=0 is insufficient. Do not ship a global Hero-removal workaround or claim prices are discount-safe.',evidence:'validation.json heroStressFailures'},
{id:'E03',state:'To validate',decision:'Ordinary target bid95%/ask105%, actual integer quote and nearest safe block payout. Bulk lots chosen to reduce rounding. Hero safety and full craft-network cycles remain release gates.',evidence:'prices-and-stock.csv; validation.json'},
{id:'C02',state:'To do',decision:'Compact catalog data and 4 complete examples per profession regenerated; visual preview synchronization remains pending.',evidence:'catalogs.json; example-plans.json'});
const previousDecisions=fs.existsSync(path.join(out,'decisions.json'))?JSON.parse(fs.readFileSync(path.join(out,'decisions.json'),'utf8')):[];
fs.writeFileSync(path.join(out,'decisions.json'),JSON.stringify([...previousDecisions.filter(d=>!decisions.some(a=>a.id===d.id)),...decisions],null,2)+'\n');
const validation={passed:true,scope:'Candidate design and undiscounted arithmetic only; no player or native transactions',professions:catalogs.length,baseOffersPerMerchant:13,candidatesProvenExtendable:count,examples:examples.length*4,referencePairs:pairs,singleStackPurchaseInputs:true,heroStressFailures:discounted,highRoundingQuotes:quotes.filter(a=>a.roundingError>.1).length,unknownFarmability:quotes.filter(a=>a.farmability.status==='unknown').length,notProven:['Native Hero-safe prices','Native minimum/OR purchase matching','Whole recipe/smelting/loot conversion network','Actual map generation','Replenishment/Secret runtime','Measured player income']};
function tagItems(id,seen=new Set()){if(!id.startsWith('#'))return[id];if(seen.has(id))return[];seen.add(id);const f=path.join(root,'vendor/generated/data/minecraft/tags/item',id.split(':')[1]+'.json');return JSON.parse(fs.readFileSync(f)).values.flatMap(v=>tagItems(typeof v==='string'?v:v.id,new Set(seen)));}
let nativeSupport=0;for(const a of quotes.filter(v=>v.enchantment)){const d=JSON.parse(fs.readFileSync(path.join(root,'vendor/generated/data/minecraft/enchantment',a.enchantment+'.json')));assert(a.level<=d.max_level);if(a.stored)continue;assert((Array.isArray(d.supported_items)?d.supported_items:[d.supported_items]).flatMap(v=>tagItems(v)).includes(a.id),'Incompatible enchant '+a.id+' '+a.enchantment);nativeSupport++;}validation.nativeEnchantmentSupportChecks=nativeSupport;
fs.writeFileSync(path.join(out,'validation.json'),JSON.stringify(validation,null,2)+'\n');
console.log(JSON.stringify({...validation,heroStressFailures:discounted.length},null,2));
