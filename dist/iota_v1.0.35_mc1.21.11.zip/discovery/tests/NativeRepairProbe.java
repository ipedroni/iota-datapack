package iota.probe;
import java.nio.file.*;import java.lang.reflect.*;import java.util.*;
public class NativeRepairProbe {
 static Class<?> c(String n)throws Exception{return Class.forName(n);}static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] args)throws Exception{
  c("w").getMethod("a").invoke(null);c("amv").getMethod("a").invoke(null);
  Class<?> stack=c("dlt"),component=c("kh"),patch=c("kg"),result=c("drv"),ingredient=c("dqo"),recipe=c("drp"),input=c("dro"),itemlike=c("dwn");
  Object damage=c("ki").getField("e").get(null),repair=c("ki").getField("u").get(null),data=c("ki").getField("b").get(null);
  Method set=stack.getMethod("b",component,Object.class);Object builder=patch.getMethod("a").invoke(null);builder.getClass().getMethod("a",component,Object.class).invoke(builder,damage,0);builder.getClass().getMethod("a",component,Object.class).invoke(builder,repair,0);Object changes=builder.getClass().getMethod("a").invoke(builder);
  Object diamond=c("dlx").getField("qa").get(null),addition=stack.getConstructor(itemlike).newInstance(diamond),additionIngredient=ingredient.getMethod("a",itemlike).invoke(null,diamond),empty=stack.getField("l").get(null);
  ArrayList<String> checked=new ArrayList<>();
  for(String line:Files.readAllLines(Path.of(args[0]))){String[] cells=line.split("\\t");if(cells.length<2)continue;Object item=c("dlx").getField(cells[1]).get(null),base=stack.getConstructor(itemlike).newInstance(item);int max=(int)stack.getMethod("p").invoke(base);if(max<2)continue;
   int oldDamage=max-1;set.invoke(base,damage,oldDamage);set.invoke(base,repair,31);Object tag=c("uz").getConstructor().newInstance();c("uz").getMethod("a",String.class,int.class).invoke(tag,"other_pack_keep",42);c("uz").getMethod("a",String.class,int.class).invoke(tag,"mastery_xp",1599);Object custom=c("doe").getMethod("a",c("uz")).invoke(null,tag);set.invoke(base,data,custom);
   Object holder=stack.getMethod("i").invoke(base),transmute=result.getConstructor(c("jd"),int.class,patch).newInstance(holder,1,changes),baseIngredient=ingredient.getMethod("a",itemlike).invoke(null,item),smithing=recipe.getConstructor(Optional.class,ingredient,Optional.class,result).newInstance(Optional.empty(),baseIngredient,Optional.of(additionIngredient),transmute),inputs=input.getConstructor(stack,stack,stack).newInstance(empty,base,addition);
   check((boolean)c("drn").getMethod("a",input,c("dwo")).invoke(smithing,inputs,null),"empty-template matching "+cells[0]);
   Object output=recipe.getMethod("a",input,c("jf$a")).invoke(smithing,inputs,null);check((int)stack.getMethod("o").invoke(output)==0,"full repair "+cells[0]);check((int)stack.getMethod("o").invoke(base)==oldDamage,"input not mutated "+cells[0]);check(output!=base,"distinct result "+cells[0]);
   Object expected=stack.getMethod("v").invoke(base);set.invoke(expected,damage,0);set.invoke(expected,repair,0);check(Objects.equals(stack.getMethod("a").invoke(output),stack.getMethod("a").invoke(expected)),"all other components retained "+cells[0]);check(!(boolean)result.getMethod("b",stack).invoke(transmute,base),"damaged result available "+cells[0]);check((boolean)result.getMethod("b",stack).invoke(transmute,expected),"healthy unchanged result suppressed "+cells[0]);
   checked.add(cells[0]);
  }
  check(checked.size()>40,"coverage");String names=checked.stream().map(s->"\""+s+"\"").reduce((a,b)->a+","+b).orElse("");Files.writeString(Path.of(args[1]),"{\"passed\":true,\"families\":"+checked.size()+",\"items\":["+names+"],\"scope\":\"Official SmithingTransformRecipe matching and assemble, empty template, output component preservation. No GUI result-take, material consumption, nonempty enchantment fixture or native Anvil replacement test.\"}\n");System.out.println("PASS native full-repair transform for "+checked.size()+" items; matching and component-copy checks passed");
 }
}
