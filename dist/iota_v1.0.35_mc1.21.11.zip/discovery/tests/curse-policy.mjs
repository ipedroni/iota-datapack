import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {Rcon} from './iron-farm/rcon.mjs';
const root=path.resolve(import.meta.dirname,'../../..');
const r=new Rcon(),commands=[];
await r.connect();
const run=async command=>{const result=await r.send(command);commands.push({command,result});return result;};
try{
 const enabled=await run('datapack list enabled');assert(enabled.includes('curse-check-tools'));assert(enabled.includes('curse-check-mastery'));
 await run('kill @e[tag=iota_curse_check]');
 await run('summon armor_stand 3 40 3 {Tags:["iota_curse_check"],NoGravity:1b,Invulnerable:1b}');
 await run('item replace entity @e[tag=iota_curse_check,limit=1] weapon.mainhand with minecraft:diamond_pickaxe[minecraft:enchantments={"minecraft:binding_curse":1,"minecraft:vanishing_curse":1,"minecraft:efficiency":3},minecraft:custom_data={other_pack:{keep_me:42}},minecraft:damage=37]');
 await run('item modify entity @e[tag=iota_curse_check,limit=1] weapon.mainhand iota_tools:remove_curses');
 const tool=await run('data get entity @e[tag=iota_curse_check,limit=1] equipment.mainhand');
 assert(!tool.includes('curse'));assert(tool.includes('efficiency'));assert(tool.includes('37'));assert(tool.includes('keep_me: 42'));
 await run('item replace entity @e[tag=iota_curse_check,limit=1] weapon.offhand with minecraft:enchanted_book[minecraft:stored_enchantments={"minecraft:binding_curse":1,"minecraft:vanishing_curse":1,"minecraft:mending":1},minecraft:custom_data={other_pack:{keep_me:42}}]');
 await run('item modify entity @e[tag=iota_curse_check,limit=1] weapon.offhand iota_tools:remove_curses');
 const book=await run('data get entity @e[tag=iota_curse_check,limit=1] equipment.offhand');
 assert(!book.includes('curse'));assert(book.includes('mending'));assert(book.includes('keep_me: 42'));
 await run('kill @e[tag=iota_currency_check]');
 await run('summon villager 4 40 3 {Tags:["iota_currency_check"],NoAI:1b,Invulnerable:1b,VillagerData:{profession:"minecraft:toolsmith",type:"minecraft:plains",level:5},Offers:{Recipes:[{buy:{id:"minecraft:iron_ingot",count:1},buyB:{id:"minecraft:iron_ingot",count:15},sell:{id:"minecraft:emerald",count:31},maxUses:4,priceMultiplier:0.0f},{buy:{id:"minecraft:emerald",count:1},buyB:{id:"minecraft:emerald",count:34},sell:{id:"minecraft:iron_ingot",count:16},maxUses:2,priceMultiplier:0.0f}]}}');
 const offers=await run('data get entity @e[tag=iota_currency_check,limit=1] Offers');
 assert(offers.includes('buyB'));assert(offers.includes('count: 34'));assert(offers.includes('count: 15'));
 // The native codec omits default-valued priceMultiplier=0 when saving.
 assert(!offers.includes('priceMultiplier:') || offers.includes('priceMultiplier: 0'));
 for(const curse of ['binding_curse','vanishing_curse'])assert.deepEqual(JSON.parse(fs.readFileSync(path.join(root,`modules/tools/data/minecraft/enchantment/${curse}.json`))).effects,{});
 for(const tag of ['on_random_loot','tradeable','treasure']){
  const t=fs.readFileSync(path.join(root,`modules/tools/data/minecraft/tags/enchantment/${tag}.json`),'utf8');assert(!t.includes('_curse'));
 }
 fs.writeFileSync(path.join(import.meta.dirname,'curse-policy-results.json'),JSON.stringify({passed:true,scope:'Native parser, direct modifier on tool/book, two-input offer codec. Not actual player trading, Hero simulation or full inventory tick test.',commands},null,2)+'\n');
 console.log('PASS: native curse cleanup preserves Efficiency/Mending, damage and unrelated custom data; two same-item offer inputs decode and persist. Player interaction and discounts remain manual checks.');
}finally{await run('kill @e[tag=iota_curse_check]');await run('kill @e[tag=iota_currency_check]');r.close();}
