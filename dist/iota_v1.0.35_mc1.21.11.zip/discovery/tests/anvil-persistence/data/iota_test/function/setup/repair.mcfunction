execute unless entity @s[type=minecraft:player] run return fail
execute if items entity @s weapon.mainhand * run tellraw @s {"text":"Empty both hands before preparing this test.","color":"red"}
execute if items entity @s weapon.mainhand * run return fail
execute if items entity @s weapon.offhand * run tellraw @s {"text":"Empty both hands before preparing this test.","color":"red"}
execute if items entity @s weapon.offhand * run return fail
experience add @s 30 levels
tellraw @s {"text":"Added 30 experience levels for the anvil test.","color":"green"}
item replace entity @s weapon.mainhand with minecraft:iron_pickaxe[minecraft:custom_data={anvil_poc:{test:1b,xp:3000},iota_test:{serial:101,processed:3},other_pack:{keep_me:1b,serial:42}},minecraft:damage=180,minecraft:custom_name={text:"Anvil Test 101",italic:false},minecraft:lore=[{text:"Preserve this test lore",italic:false}],minecraft:enchantments={"minecraft:efficiency":2}]
item replace entity @s weapon.offhand with minecraft:iron_ingot
tellraw @s {"text":"Place pickaxe 101 on the LEFT and the iron ingot on the RIGHT. Take the repaired result.","color":"yellow"}
tellraw @s {"text":"Hold the result and run /function iota_test:verify/repair","color":"yellow"}
