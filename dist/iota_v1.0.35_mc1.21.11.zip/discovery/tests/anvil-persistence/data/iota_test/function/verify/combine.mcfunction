execute unless entity @s[type=minecraft:player] run return fail
execute unless items entity @s weapon.mainhand minecraft:iron_pickaxe[minecraft:custom_data~{anvil_poc:{test:1b,xp:3000},iota_test:{serial:101,processed:3},other_pack:{keep_me:1b,serial:42}}] run tellraw @s {"text":"[FAIL] Expected left-item identity 101, 3000 XP and preserved custom data.","color":"red"}
execute unless items entity @s weapon.mainhand minecraft:iron_pickaxe[minecraft:custom_data~{anvil_poc:{test:1b,xp:3000},iota_test:{serial:101,processed:3},other_pack:{keep_me:1b,serial:42}}] run return fail
tellraw @s {"text":"[PASS] Left-item identity 101, 3000 XP, milestone marker and unrelated custom data survived.","color":"green"}
tellraw @s {"text":"Also confirm the actual repair/merge/rename happened. An untouched input can pass this data check.","color":"yellow"}
data get entity @s SelectedItem.components
return 1
