tellraw @s {"text":"Iota - vanilla anvil persistence tests","color":"gold"}
tellraw @s {"text":"Use Survival and an anvil. Empty both hands. Each setup grants 30 experience levels and disposable test items.","color":"yellow"}
tellraw @s {"text":"/function iota_test:setup/repair","color":"yellow"}
tellraw @s {"text":"/function iota_test:setup/combine","color":"yellow"}
tellraw @s {"text":"/function iota_test:setup/reverse","color":"yellow"}
tellraw @s {"text":"/function iota_test:setup/rename","color":"yellow"}
tellraw @s {"text":"Operate the vanilla anvil, take the output, hold it, then run the matching verify function.","color":"yellow"}
tellraw @s {"text":"Afterward, move the result into a chest and back, reload, and verify again.","color":"yellow"}
