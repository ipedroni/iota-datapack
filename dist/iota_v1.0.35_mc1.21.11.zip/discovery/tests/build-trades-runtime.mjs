import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
const root=path.resolve(import.meta.dirname,'../../..'),out=path.join(root,'docs/discovery/research/outputs/trading-execution-2026-11-20'),pack=path.join(root,'modules/experimental/trades'),ns=path.join(pack,'data/iota_trades'),load=n=>JSON.parse(fs.readFileSync(path.join(out,n),'utf8'));
const w=(rel,v)=>{const p=path.join(ns,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');},stage={Novice:1,Apprentice:2,Journeyman:3,Expert:4,Master:5,Secret:6},xp={1:1,2:5,3:10,4:15,5:20,6:0};
const examples=load('example-plans.json'),regionData=load('regions.json'),prices=load('regional-prices.json'),payment=load('qualification-policy.json').payments;
// Embed the proven qualifier in the standalone experimental module.
const qsrc=path.join(out,'qualification-poc/data/iota_qual_poc'),qdst=path.join(pack,'data/iota_trades_qual');function copy(dir,rel=''){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const p=path.join(dir,e.name),r=path.join(rel,e.name);if(e.isDirectory())copy(p,r);else{const dest=path.join(qdst,r);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,fs.readFileSync(p,'utf8').replaceAll('iota_qual_poc:','iota_trades_qual:').replaceAll('iota_qual_poc_merchant','iota_trades_catalog'));}}}copy(qsrc);
const native=(a)=>{let result,buy,buyB;const components={};if(a.enchantment)components[a.stored?'minecraft:stored_enchantments':'minecraft:enchantments']={['minecraft:'+a.enchantment]:a.level};if(a.direction==='sell'){result={id:a.id,count:a.lot,...(Object.keys(components).length?{components}:{})};const costs=a.inputCosts??a.price.payment.map(p=>({id:'minecraft:'+p.item,count:p.count}));buy={id:costs[0].id,count:costs[0].count};if(costs[1])buyB={id:costs[1].id,count:costs[1].count};}else{buy={id:a.id,count:a.lot};if(a.quality){buy.components={'minecraft:damage':0};if(a.quality==='plain')buy.components['minecraft:note_block_sound']='iota_trades_qual:plain';else if(a.quality.endsWith('advanced'))buy.components['minecraft:map_color']=1091329;else buy.components['minecraft:note_block_sound']='iota_trades_qual:basic';}const p=a.price.payment[0];assert(a.price.payment.length===1);result={id:'minecraft:'+p.item,count:p.count};if(a.quality&&a.quality!=='plain')result.components={'minecraft:custom_name':payment['tools_'+(a.quality.endsWith('advanced')?'advanced':'basic')]};}return{buy,...(buyB?{buyB}:{}),sell:result,uses:0,maxUses:a.uses??Math.max(1,a.stockUnits/a.lot),xp:0,rewardExp:true,priceMultiplier:0.0};};
let templates='';const regions=Object.keys(regionData.regions);for(let i=0;i<regions.length;i++)w('tags/worldgen/biome/regions/'+regions[i]+'.json',{values:regionData.regions[regions[i]].biomes.map(x=>'minecraft:'+x)});
for(const prof of ['toolsmith','mason'])for(const reg of ['none',...regions])for(let seed=0;seed<4;seed++){const base=examples.find(x=>x.profession===prof).samples[seed],rows=base.map(a=>({...a,kind:a.stage==='Secret'?1:0})),seen={sell:new Set(rows.filter(a=>a.direction==='sell').map(a=>a.id)),buy:new Set(rows.filter(a=>a.direction==='buy').map(a=>a.id))};if(prof==='mason'&&reg!=='none'){for(const dir of ['sell','buy']){const options=(dir==='sell'?prices.sales:prices.imports).filter(x=>x.profession===prof&&x.region===reg&&!seen[dir].has(x.id)),count=Math.min(options.length,1+((seed+(dir==='buy'?1:0))%2));for(let j=0;j<count;j++){const a=options[(seed+j)%options.length];if(seen[dir].has(a.id))continue;seen[dir].add(a.id);rows.push({...a,direction:dir,stage:['Novice','Apprentice','Journeyman','Expert'][(seed+j+(dir==='buy'?1:0))%4],slot:14+rows.length-base.length,kind:2});}}}
 assert(rows.length<=17);const rolled={},order=[];for(const a of rows.sort((a,b)=>(a.direction==='sell'?0:1)-(b.direction==='sell'?0:1))){assert(!rolled['o'+a.slot]);rolled['o'+a.slot]={level:stage[a.stage],kind:a.kind,xp:xp[stage[a.stage]],direction:a.direction,item:a.id,native:native(a)};order.push(a.slot);}templates+='data modify storage iota_trades:templates '+prof+'_'+reg+'.p'+seed+' set value '+JSON.stringify({rolled,order})+'\n';}
w('function/catalog/templates.mcfunction',templates);
w('function/catalog/init.mcfunction','execute store result storage iota_trades:scratch init.id int 1 run scoreboard players get @s it_identity\ndata modify storage iota_trades:scratch init.profession set string entity @s VillagerData.profession 10\ndata remove storage iota_trades:scratch init.job\ndata modify storage iota_trades:scratch init.job set from entity @s Brain.memories."minecraft:job_site".value\nexecute unless data storage iota_trades:scratch init.job.pos run return 0\ndata modify storage iota_trades:scratch init.region set value "none"\nfunction iota_trades:catalog/classify with storage iota_trades:scratch init.job\nexecute store result storage iota_trades:scratch init.draw int 1 run random value 0..3\nfunction iota_trades:catalog/init_apply with storage iota_trades:scratch init\n');
w('function/catalog/classify.mcfunction',regions.map(reg=>`$execute in $(dimension) positioned $(pos[0]) $(pos[1]) $(pos[2]) if biome ~ ~ ~ #iota_trades:regions/${reg} run data modify storage iota_trades:scratch init.region set value "${reg}"`).join('\n')+'\n');
// Function macros bind named fields, not array-expression placeholders. Flatten the job position first.
w('function/catalog/classify.mcfunction','data modify storage iota_trades:scratch coords.dimension set from storage iota_trades:scratch init.job.dimension\ndata modify storage iota_trades:scratch coords.x set from storage iota_trades:scratch init.job.pos[0]\ndata modify storage iota_trades:scratch coords.y set from storage iota_trades:scratch init.job.pos[1]\ndata modify storage iota_trades:scratch coords.z set from storage iota_trades:scratch init.job.pos[2]\nfunction iota_trades:catalog/classify_at with storage iota_trades:scratch coords\n');
w('function/catalog/classify_at.mcfunction',regions.map(reg=>`$execute in $(dimension) positioned $(x) $(y) $(z) if biome ~ ~ ~ #iota_trades:regions/${reg} run data modify storage iota_trades:scratch init.region set value "${reg}"`).join('\n')+'\n');
const macroGuard=(cmd)=>`$execute if data storage iota_trades:residents r$(id) run ${cmd}`;
w('function/catalog/init_apply.mcfunction',`$execute unless data storage iota_trades:templates $(profession)_$(region).p$(draw) run return 0
$data modify storage iota_trades:residents r$(id).rolled set from storage iota_trades:templates $(profession)_$(region).p$(draw).rolled
$data modify storage iota_trades:residents r$(id).order set from storage iota_trades:templates $(profession)_$(region).p$(draw).order
$data modify storage iota_trades:residents r$(id).region set value "$(region)"
$data modify storage iota_trades:residents r$(id).anchor set from storage iota_trades:scratch init.job
$data modify storage iota_trades:residents r$(id).original_offers set from entity @s Offers
execute store result score #start_xp it_identity_tmp run data get entity @s Xp
$execute store result score #bootstrap it_identity_tmp run data get storage iota_trades:residents r$(id).bootstrap
scoreboard players operation #start_xp it_identity_tmp -= #bootstrap it_identity_tmp
execute if score #start_xp it_identity_tmp matches ..-1 run scoreboard players set #start_xp it_identity_tmp 0
$execute store result storage iota_trades:residents r$(id).commercial_xp int 1 run scoreboard players get #start_xp it_identity_tmp
$data modify storage iota_trades:residents r$(id).clock set value {ordinary:0,secret:0,regional:0,sleep_used:0}
$data modify storage iota_trades:residents r$(id).catalog set value 1b
$data modify storage iota_trades:residents r$(id).dirty set value 1b
$data modify storage iota_trades:residents r$(id).published set value 0b
$data modify storage iota_trades:residents r$(id).secret_unlocked set value 0b
tag @s add iota_trades_catalog
`);
w('function/catalog/frame.mcfunction',`execute if entity @a[distance=..12] run scoreboard players set @s it_far 0
execute unless entity @a[distance=..12] run scoreboard players add @s it_far 1
execute store result storage iota_trades:scratch frame.id int 1 run scoreboard players get @s it_identity
function iota_trades:clock/frame with storage iota_trades:scratch frame
execute if score @s it_far matches 60.. run function iota_trades:catalog/publish_if_dirty with storage iota_trades:scratch frame
`);
w('function/catalog/publish_if_dirty.mcfunction','$execute if data storage iota_trades:residents r$(id){dirty:1b} run function iota_trades:catalog/publish {id:$(id)}\n');
let publish=`$data modify storage iota_trades:scratch publish.order set from storage iota_trades:residents r$(id).order
$data modify storage iota_trades:scratch publish.id set value $(id)
$execute if data storage iota_trades:residents r$(id) run data modify storage iota_trades:scratch publish.recipes set value []
$execute if data storage iota_trades:residents r$(id) run data modify storage iota_trades:residents r$(id).active_slots set value []
$execute store result score #xp it_identity_tmp run data get storage iota_trades:residents r$(id).commercial_xp
$execute if data storage iota_trades:residents r$(id) run scoreboard players set #level it_identity_tmp 1
$execute if data storage iota_trades:residents r$(id) if score #xp it_identity_tmp matches 10.. run scoreboard players set #level it_identity_tmp 2
$execute if data storage iota_trades:residents r$(id) if score #xp it_identity_tmp matches 70.. run scoreboard players set #level it_identity_tmp 3
$execute if data storage iota_trades:residents r$(id) if score #xp it_identity_tmp matches 150.. run scoreboard players set #level it_identity_tmp 4
$execute if data storage iota_trades:residents r$(id) if score #xp it_identity_tmp matches 250.. run scoreboard players set #level it_identity_tmp 5
$execute if data storage iota_trades:residents r$(id) run execute store result storage iota_trades:scratch publish.level int 1 run scoreboard players get #level it_identity_tmp
$execute if data storage iota_trades:residents r$(id) run function iota_trades:catalog/build_active
$execute if data storage iota_trades:residents r$(id) run data modify entity @s Offers.Recipes set from storage iota_trades:scratch publish.recipes
$execute if data storage iota_trades:residents r$(id) run execute store result entity @s VillagerData.level int 1 run scoreboard players get #level it_identity_tmp
$execute if data storage iota_trades:residents r$(id) if score #xp it_identity_tmp matches ..0 run scoreboard players set #xp it_identity_tmp 1
$execute if data storage iota_trades:residents r$(id) run execute store result entity @s Xp int 1 run scoreboard players get #xp it_identity_tmp
$data modify storage iota_trades:residents r$(id).dirty set value 0b
$data modify storage iota_trades:residents r$(id).published set value 1b
`;
w('function/catalog/publish.mcfunction',publish);w('function/catalog/build_active.mcfunction','execute unless data storage iota_trades:scratch publish.order[0] run return 0\ndata modify storage iota_trades:scratch publish.slot set from storage iota_trades:scratch publish.order[0]\nfunction iota_trades:catalog/add_active with storage iota_trades:scratch publish\ndata remove storage iota_trades:scratch publish.order[0]\nfunction iota_trades:catalog/build_active\n');
w('function/catalog/add_active.mcfunction',`$execute store result score #offer_level it_identity_tmp run data get storage iota_trades:residents r$(id).rolled.o$(slot).level
$execute if score #offer_level it_identity_tmp matches 6 if data storage iota_trades:residents r$(id){secret_unlocked:1b} run scoreboard players set #offer_level it_identity_tmp 5
execute if score #offer_level it_identity_tmp > #level it_identity_tmp run return 0
$data modify storage iota_trades:scratch publish.recipes append from storage iota_trades:residents r$(id).rolled.o$(slot).native
$data modify storage iota_trades:residents r$(id).active_slots append value $(slot)
`);
// Exact events read the live offer before any entity mutation. All publication occurs after60far ticks.
w('function/catalog/trade.mcfunction',Array.from({length:17},(_,i)=>`function iota_trades:catalog/trade_index {id:$(id),index:${i}}`).map(s=>'$'+s).join('\n')+'\n');
w('function/catalog/trade_index.mcfunction',`$execute unless data storage iota_trades:residents r$(id).active_slots[$(index)] run return 0
$data modify storage iota_trades:scratch trade set value {id:$(id)}
$data modify storage iota_trades:scratch trade.slot set from storage iota_trades:residents r$(id).active_slots[$(index)]
$data modify storage iota_trades:scratch trade.native set from entity @e[type=villager,tag=iota_trades_id.$(id),limit=1] Offers.Recipes[$(index)]
data modify storage iota_trades:scratch trade.uuid set from entity @s UUID
function iota_trades:catalog/trade_slot with storage iota_trades:scratch trade
`);
w('function/catalog/trade_slot.mcfunction',`scoreboard players set #current it_identity_tmp 0
scoreboard players set #old it_identity_tmp 0
execute store result score #current it_identity_tmp run data get storage iota_trades:scratch trade.native.uses
$execute store result score #old it_identity_tmp run data get storage iota_trades:residents r$(id).rolled.o$(slot).native.uses
scoreboard players operation #delta it_identity_tmp = #current it_identity_tmp
scoreboard players operation #delta it_identity_tmp -= #old it_identity_tmp
execute unless score #delta it_identity_tmp matches 1.. run return 0
$execute store result score #reward it_identity_tmp run data get storage iota_trades:residents r$(id).rolled.o$(slot).xp
scoreboard players operation #reward it_identity_tmp *= #delta it_identity_tmp
$data modify storage iota_trades:residents r$(id).rolled.o$(slot).native set from storage iota_trades:scratch trade.native
$data modify storage iota_trades:residents r$(id).rolled.o$(slot).native.specialPrice set value 0
$execute store result score #total it_identity_tmp run data get storage iota_trades:residents r$(id).commercial_xp
scoreboard players operation #total it_identity_tmp += #reward it_identity_tmp
$execute store result storage iota_trades:residents r$(id).commercial_xp int 1 run scoreboard players get #total it_identity_tmp
$execute unless data storage iota_trades:residents r$(id).players[{uuid:$(uuid)}] run data modify storage iota_trades:residents r$(id).players append value {uuid:$(uuid),xp:0}
$execute store result score #personal it_identity_tmp run data get storage iota_trades:residents r$(id).players[{uuid:$(uuid)}].xp
scoreboard players operation #personal it_identity_tmp += #reward it_identity_tmp
$execute store result storage iota_trades:residents r$(id).players[{uuid:$(uuid)}].xp int 1 run scoreboard players get #personal it_identity_tmp
$data modify storage iota_trades:residents r$(id).dirty set value 1b
`);
// Restore only usage counters on opening; this happens before input selection and never reorders the just-opened list.
w('function/catalog/open.mcfunction',Array.from({length:17},(_,i)=>`$function iota_trades:catalog/open_index {id:$(id),index:${i}}`).join('\n')+'\n');
w('function/catalog/open_index.mcfunction',`$execute unless data storage iota_trades:residents r$(id).active_slots[$(index)] run return 0
$data modify storage iota_trades:scratch open set value {id:$(id),index:$(index)}
$data modify storage iota_trades:scratch open.slot set from storage iota_trades:residents r$(id).active_slots[$(index)]
function iota_trades:catalog/open_slot with storage iota_trades:scratch open
`);
w('function/catalog/open_slot.mcfunction',`$execute store result entity @e[type=villager,tag=iota_trades_id.$(id),limit=1] Offers.Recipes[$(index)].uses int 1 run data get storage iota_trades:residents r$(id).rolled.o$(slot).native.uses
`);
// Loaded tick clocks; actual publication/refill also requires accessible work and the far barrier.
w('function/clock/frame.mcfunction',`$execute store result score #clock it_identity_tmp run data get storage iota_trades:residents r$(id).clock.ordinary
execute if score #clock it_identity_tmp matches ..71999 run scoreboard players add #clock it_identity_tmp 1
$execute store result storage iota_trades:residents r$(id).clock.ordinary int 1 run scoreboard players get #clock it_identity_tmp
$execute store result score #sleep it_identity_tmp run data get storage iota_trades:residents r$(id).clock.sleep_used
scoreboard players set #credit it_identity_tmp 36000
scoreboard players operation #credit it_identity_tmp *= #sleep it_identity_tmp
scoreboard players operation #credit it_identity_tmp += #clock it_identity_tmp
$execute if score @s it_far matches 60.. if score #clock it_identity_tmp matches 36000.. if score #credit it_identity_tmp matches 72000.. run function iota_trades:clock/check_work {id:$(id)}
`);
w('function/clock/check_work.mcfunction',`data remove storage iota_trades:scratch work.job
data modify storage iota_trades:scratch work.job set from entity @s Brain.memories."minecraft:job_site".value
execute unless data storage iota_trades:scratch work.job.pos run return 0
$data modify storage iota_trades:scratch work.id set value $(id)
data modify storage iota_trades:scratch work.dimension set from storage iota_trades:scratch work.job.dimension
data modify storage iota_trades:scratch work.x set from storage iota_trades:scratch work.job.pos[0]
data modify storage iota_trades:scratch work.y set from storage iota_trades:scratch work.job.pos[1]
data modify storage iota_trades:scratch work.z set from storage iota_trades:scratch work.job.pos[2]
function iota_trades:clock/work_at with storage iota_trades:scratch work
`);
w('function/clock/work_at.mcfunction',`$execute unless dimension $(dimension) run return 0
$execute positioned $(x) $(y) $(z) unless entity @s[distance=..3] run return 0
$execute positioned $(x) $(y) $(z) unless block ~ ~ ~ #iota_trades:job_sites run return 0
$function iota_trades:clock/refill {id:$(id)}
`);w('tags/block/job_sites.json',{values:['minecraft:smithing_table','minecraft:stonecutter']});
w('function/clock/refill.mcfunction',Array.from({length:17},(_,j)=>`$execute if data storage iota_trades:residents r$(id).rolled.o${j+1}{kind:0} run data modify storage iota_trades:residents r$(id).rolled.o${j+1}.native.uses set value 0`).join('\n')+'\n$data modify storage iota_trades:residents r$(id).clock.ordinary set value 0\n$data modify storage iota_trades:residents r$(id).clock.sleep_used set value 0\n$data modify storage iota_trades:residents r$(id).dirty set value 1b\n');
w('function/clock/sleep.mcfunction','execute as @e[type=villager,tag=iota_trades_catalog,distance=..64] run function iota_trades:clock/sleep_resident\n');w('function/clock/sleep_resident.mcfunction','execute store result storage iota_trades:scratch sleep.id int 1 run scoreboard players get @s it_identity\nfunction iota_trades:clock/sleep_apply with storage iota_trades:scratch sleep\n');w('function/clock/sleep_apply.mcfunction','$execute store result score #clock it_identity_tmp run data get storage iota_trades:residents r$(id).clock.ordinary\n$execute if score #clock it_identity_tmp matches 18000.. if data storage iota_trades:residents r$(id).clock{sleep_used:0} run data modify storage iota_trades:residents r$(id).clock.sleep_used set value 1\n');w('function/clock/sleep_detect.mcfunction','execute store result score #bed it_identity_tmp run data get entity @s SleepTimer\nexecute if score #bed it_identity_tmp matches 99..100 unless score @s it_bed_seen matches 1 run function iota_trades:clock/sleep\nexecute if score #bed it_identity_tmp matches 99..100 run scoreboard players set @s it_bed_seen 1\nexecute if score #bed it_identity_tmp matches 0 run scoreboard players set @s it_bed_seen 0\n');
// Additions are idempotent; identity logic remains active for other vanilla professionals.
const append=(file,line)=>{const p=path.join(ns,'function',file+'.mcfunction');let s=fs.readFileSync(p,'utf8');if(!s.includes(line))s+='\n'+line+'\n';fs.writeFileSync(p,s);};append('load','scoreboard objectives add it_far dummy\nscoreboard objectives add it_bed_seen dummy\nfunction iota_trades:catalog/templates\nfunction iota_trades_qual:load');append('tick','execute as @a at @s run function iota_trades:clock/sleep_detect\nfunction iota_trades_qual:tick\nexecute in minecraft:overworld as @e[type=villager,tag=iota_trades_catalog_probe,scores={it_identity=1..64}] at @s run function iota_trades:catalog/watch');w('function/catalog/watch.mcfunction','execute store result storage iota_trades:scratch frame.id int 1 run scoreboard players get @s it_identity\nfunction iota_trades:catalog/watch_id with storage iota_trades:scratch frame\n');w('function/catalog/watch_id.mcfunction','$execute unless data storage iota_trades:residents r$(id){catalog:1b} run function iota_trades:catalog/init\n$execute if data storage iota_trades:residents r$(id){catalog:1b} run function iota_trades:catalog/frame\n');
const events=path.join(ns,'function/events/record.mcfunction');let e=fs.readFileSync(events,'utf8');const branch=`$execute if data storage iota_trades:events last{kind:"trade"} if data storage iota_trades:residents r$(id){catalog:1b} run return run function iota_trades:catalog/trade {id:$(id)}
$execute if data storage iota_trades:events last{kind:"interact"} if data storage iota_trades:residents r$(id){catalog:1b} run function iota_trades:catalog/open {id:$(id)}
`;if(!e.includes('catalog/trade'))e=e.replace('$execute if data storage iota_trades:events last{kind:"interact"}',branch+'$execute if data storage iota_trades:events last{kind:"interact"}');fs.writeFileSync(events,e);
// Naming writes also wait until the menu is certainly closed.
const snapshot=path.join(ns,'function/identity/snapshot.mcfunction');let ss=fs.readFileSync(snapshot,'utf8');ss=ss.replace('execute if score #level it_identity_tmp matches 2.. unless data entity @s CustomName','execute unless entity @a[distance=..12] if score #level it_identity_tmp matches 2.. unless data entity @s CustomName');fs.writeFileSync(snapshot,ss);
fs.writeFileSync(path.join(out,'trades-prototype-policy.json'),JSON.stringify({roles:['toolsmith','mason'],planDraws:4,maxExactEventIds:64,publicationBarrier:'60loaded ticks with every player outside12blocks; assumes normal vanilla interaction range. Updates never reorder an active native menu.',stock:'Ordinary60loaded minutes; one30minute sleep credit after15minutes, never before30real loaded minutes. Accessible workstation within3blocks required. Secret/regional stock timers still to add.',limits:['Experimental opt-in iota_trades_catalog_probe tag; not the final plug-and-play Trades release','Prototype UI progress, new offers and refills publish after stepping away for3seconds','Hero arbitrage is an explicit candidate exception','Region identity, Secret and raid history are the next slice'],status:'Implementation under native validation'},null,2)+'\n');console.log(JSON.stringify({roles:2,templates:2*(regions.length+1)*4,publication:'Safe far barrier',scope:'Experimental; excluded from base'}));
