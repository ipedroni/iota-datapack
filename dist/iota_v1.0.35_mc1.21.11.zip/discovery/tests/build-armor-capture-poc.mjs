import fs from 'node:fs';import path from 'node:path';
const root=path.resolve(import.meta.dirname,'../../..'),out=path.join(root,'docs/discovery/research/outputs/trading-execution-2026-11-20'),old=path.join(out,'armor-break-poc'),pack=path.join(out,'armor-break-capture-poc'),ns=path.join(pack,'data/iota_armor_poc');fs.cpSync(old,pack,{recursive:true});const w=(rel,v)=>{const p=path.join(ns,rel);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');};
for(const [name,family] of [['head','helmet'],['chest','chestplate'],['legs','leggings'],['feet','boots']]){
 const advPath=path.join(ns,'advancement/break_'+name+'.json'),a=JSON.parse(fs.readFileSync(advPath,'utf8'));a.rewards.loot=['iota_armor_poc:capture/'+name];w('advancement/break_'+name+'.json',a);
 w('loot_table/capture/'+name+'.json',{type:'minecraft:advancement_reward',pools:[{rolls:1,entries:[{type:'minecraft:item',name:'minecraft:structure_void',functions:[{function:'minecraft:set_custom_data',tag:'{iota_armor_capture:{slot:"'+name+'"}}'},{function:'minecraft:copy_custom_data',source:'this',ops:[{source:'equipment.'+name,target:'iota_armor_capture.original',op:'replace'},{source:'UUID',target:'iota_armor_capture.owner',op:'replace'}]}]}]}]});
 w('function/break_'+name+'.mcfunction','advancement revoke @s only iota_armor_poc:break_'+name+'\ndata modify storage iota_armor_poc:scratch capture set value {name:"'+name+'",slot:"armor.'+name+'",source:"equipment.'+name+'"}\ndata modify storage iota_armor_poc:scratch capture.owner set from entity @s UUID\nfunction iota_armor_poc:capture/process with storage iota_armor_poc:scratch capture\n');
}
w('function/capture/process.mcfunction',`data remove storage iota_armor_poc:scratch item
$data modify storage iota_armor_poc:scratch item set from entity @s Inventory[{id:"minecraft:structure_void",components:{"minecraft:custom_data":{iota_armor_capture:{slot:"$(name)",owner:$(owner)}}}}].components."minecraft:custom_data".iota_armor_capture.original
$execute unless data storage iota_armor_poc:scratch item.id run data modify storage iota_armor_poc:scratch item set from entity @e[type=minecraft:item,nbt={Item:{id:"minecraft:structure_void",components:{"minecraft:custom_data":{iota_armor_capture:{slot:"$(name)",owner:$(owner)}}}}},limit=1] Item.components."minecraft:custom_data".iota_armor_capture.original
execute unless data storage iota_armor_poc:scratch item.id run return 0
# Only remove the live source if it is the exact item captured in this event.
data remove storage iota_armor_poc:scratch current
$execute store success score #live iota_apoc run data modify storage iota_armor_poc:scratch current set from entity @s $(source)
scoreboard players set #different iota_apoc 1
execute if score #live iota_apoc matches 1 store success score #different iota_apoc run data modify storage iota_armor_poc:scratch current set from storage iota_armor_poc:scratch item
scoreboard players set #ready iota_apoc 0
function iota_armor_poc:break_common with storage iota_armor_poc:scratch capture
$execute if score #ready iota_apoc matches 1 run clear @s minecraft:structure_void[minecraft:custom_data~{iota_armor_capture:{slot:"$(name)",owner:$(owner)}}] 1
$execute if score #ready iota_apoc matches 1 run kill @e[type=minecraft:item,nbt={Item:{id:"minecraft:structure_void",components:{"minecraft:custom_data":{iota_armor_capture:{slot:"$(name)",owner:$(owner)}}}}},limit=1]
`);
let common=fs.readFileSync(path.join(ns,'function/break_common.mcfunction'),'utf8');common=common.replace('$execute if score #ready iota_apoc matches 1 run item replace entity @s $(slot) with minecraft:air','$execute if score #ready iota_apoc matches 1 if score #live iota_apoc matches 1 if score #different iota_apoc matches 0 run item replace entity @s $(slot) with minecraft:air');w('function/break_common.mcfunction',common);
console.log(JSON.stringify({pack,method:'Fresh synchronous reward loot capture; no tick snapshots or permanent enchantment on healthy armor'}));
