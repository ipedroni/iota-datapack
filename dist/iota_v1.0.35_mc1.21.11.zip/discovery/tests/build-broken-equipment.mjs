import fs from 'node:fs';import path from 'node:path';
const root=path.resolve(import.meta.dirname,'../../..'),out=path.join(root,'docs/discovery/research/outputs/trading-execution-2026-11-20'),pack=path.join(out,'broken-equipment-poc'),base=path.join(pack,'data/iota_exp_tool_mastery'),prefix='broken_equipment/',id=s=>'iota_exp_tool_mastery:'+prefix+s;
const write=(type,name,v)=>{const p=path.join(base,type,prefix+name+(type==='function'?'.mcfunction':'.json'));fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,typeof v==='string'?v:JSON.stringify(v,null,2)+'\n');};
fs.mkdirSync(pack,{recursive:true});fs.writeFileSync(path.join(pack,'pack.mcmeta'),JSON.stringify({pack:{description:'Fresh-capture Broken equipment POC; isolated validation',min_format:[94,1],max_format:[94,1]}}));
const native=JSON.parse(fs.readFileSync(path.join(root,'vendor/generated/reports/items.json'),'utf8')),armor={head:[],chest:[],legs:[],feet:[]},hands=[];for(const k of Object.keys(native)){const n=k.slice(10);if(!native[k].components['minecraft:max_damage'])continue;let slot=null;for(const [s,suffix]of [['head','helmet'],['chest','chestplate'],['legs','leggings'],['feet','boots']])if(n.endsWith('_'+suffix))slot=s;if(slot)armor[slot].push(k);else if(/_(pickaxe|axe|shovel|hoe|sword|spear)$/.test(n)||['mace','bow','crossbow','trident','shield'].includes(n))hands.push(k);}
const managed=[...Object.values(armor).flat(),...hands];write('tags/item','managed',{values:managed});
write('enchantment','guard',{description:{text:'Broken',color:'red'},supported_items:'#'+id('managed'),weight:1,max_level:1,min_cost:{base:1,per_level_above_first:0},max_cost:{base:1,per_level_above_first:0},anvil_cost:0,slots:['any'],effects:{'minecraft:item_damage':[{effect:{type:'minecraft:set',value:0},requirements:{condition:'minecraft:match_tool',predicate:{predicates:{'minecraft:custom_data':{iota_broken_equipment:{broken:true}}}}}}],'minecraft:projectile_count':[{effect:{type:'minecraft:set',value:0},requirements:{condition:'minecraft:match_tool',predicate:{predicates:{'minecraft:custom_data':{iota_broken_equipment:{broken:true}}}}}}]}});
const guardPath=path.join(base,'enchantment',prefix+'guard.json');const guardDefinition=JSON.parse(fs.readFileSync(guardPath,'utf8'));guardDefinition.effects['minecraft:projectile_count'][0].requirements={condition:'minecraft:any_of',terms:['mainhand','offhand'].map(hand=>({condition:'minecraft:entity_properties',entity:'this',predicate:{equipment:{[hand]:{predicates:{'minecraft:custom_data':{iota_broken_equipment:{broken:true}}}}}}}))};fs.writeFileSync(guardPath,JSON.stringify(guardDefinition,null,2)+'\n');
write('item_modifier','remove_guard',{function:'minecraft:set_enchantments',enchantments:{[id('guard')]:0},add:false});
write('item_modifier','full_damage',{function:'minecraft:set_damage',damage:0,add:false});write('item_modifier','guard',{function:'minecraft:set_enchantments',enchantments:{[id('guard')]:1},add:false});write('item_modifier','repair_test',{function:'minecraft:set_damage',damage:1,add:false});
function entry(item,slot,source,name,conditions=[]){return{type:'minecraft:item',name:'minecraft:structure_void',conditions,functions:[{function:'minecraft:set_custom_data',tag:`{iota_break_capture:{item:"${item}",name:"${name}",slot:"${slot}",source:"${source}"}}`},{function:'minecraft:copy_custom_data',source:'this',ops:[{source,target:'iota_break_capture.original',op:'replace'},{source:'UUID',target:'iota_break_capture.owner',op:'replace'}]}]};}
for(const item of managed){const n=item.slice(10),aSlot=Object.entries(armor).find(([,ids])=>ids.includes(item))?.[0],entries=aSlot?[entry(item,'armor.'+aSlot,'equipment.'+aSlot,n)]:[{type:'minecraft:alternatives',children:[entry(item,'weapon.mainhand','SelectedItem',n,[{condition:'minecraft:entity_properties',entity:'this',predicate:{equipment:{mainhand:{items:[item]}}}}]),entry(item,'weapon.offhand','equipment.offhand',n,[{condition:'minecraft:entity_properties',entity:'this',predicate:{equipment:{offhand:{items:[item]}}}}])]}];write('loot_table','capture/'+n,{type:'minecraft:advancement_reward',pools:[{rolls:1,entries}]});write('advancement','capture/'+n,{criteria:{fatal:{trigger:'minecraft:item_durability_changed',conditions:{item:{items:[item]},durability:{max:0}}}},rewards:{loot:[id('capture/'+n)],function:id('capture/'+n)}});write('function','capture/'+n,`advancement revoke @s only ${id('capture/'+n)}\ndata modify storage iota_broken:scratch find set value {item:"${item}",default_max:${native[item].components["minecraft:max_damage"]}}\ndata modify storage iota_broken:scratch find.owner set from entity @s UUID\nfunction ${id('capture/find')} with storage iota_broken:scratch find\n`);}
write('function','capture/find',`data remove storage iota_broken:scratch capture
$data modify storage iota_broken:scratch capture set from entity @s Inventory[{id:"minecraft:structure_void",components:{"minecraft:custom_data":{iota_break_capture:{item:"$(item)",owner:$(owner)}}}}].components."minecraft:custom_data".iota_break_capture
$execute unless data storage iota_broken:scratch capture.original.id run data modify storage iota_broken:scratch capture set from entity @e[type=item,nbt={Item:{id:"minecraft:structure_void",components:{"minecraft:custom_data":{iota_break_capture:{item:"$(item)",owner:$(owner)}}}}},limit=1] Item.components."minecraft:custom_data".iota_break_capture
execute unless data storage iota_broken:scratch capture.original.id run return 0
$execute unless data storage iota_broken:scratch capture.original{id:"$(item)"} run return 0
data modify storage iota_broken:scratch capture.default_max set from storage iota_broken:scratch find.default_max
data modify storage iota_broken:scratch item set from storage iota_broken:scratch capture.original
function ${id('capture/process')} with storage iota_broken:scratch capture
`);
write('function','capture/process',`data remove storage iota_broken:scratch current
$execute store success score #live im_broken run data modify storage iota_broken:scratch current set from entity @s $(source)
scoreboard players set #different im_broken 1
execute if score #live im_broken matches 1 store success score #different im_broken run data modify storage iota_broken:scratch current set from storage iota_broken:scratch item
scoreboard players set #ready im_broken 0
function ${id('mark')} with storage iota_broken:scratch capture
$execute if score #ready im_broken matches 1 run clear @s minecraft:structure_void[minecraft:custom_data~{iota_break_capture:{item:"$(item)",owner:$(owner)}}] 1
$execute if score #ready im_broken matches 1 run kill @e[type=item,nbt={Item:{id:"minecraft:structure_void",components:{"minecraft:custom_data":{iota_break_capture:{item:"$(item)",owner:$(owner)}}}}},limit=1]
`);
const fields=['equippable','attribute_modifiers','tool','weapon','kinetic_weapon','piercing_weapon','blocks_attacks','glider','charged_projectiles','enchantment_glint_override','minimum_attack_charge','tooltip_display'];
let mark=`execute store success score #had_data im_broken run data get storage iota_broken:scratch item.components."minecraft:custom_data"
execute store success score #had_ench im_broken run data get storage iota_broken:scratch item.components."minecraft:enchantments"
data modify storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment set value {broken:1b,saved:{}}
execute store result storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment.had_data byte 1 run scoreboard players get #had_data im_broken
execute store result storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment.had_ench byte 1 run scoreboard players get #had_ench im_broken
`;
for(const f of fields)mark+=`execute if data storage iota_broken:scratch item.components."minecraft:${f}" run data modify storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment.saved."minecraft:${f}" set from storage iota_broken:scratch item.components."minecraft:${f}"
execute if data storage iota_broken:scratch item.components."!minecraft:${f}" run data modify storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment.saved."!minecraft:${f}" set value {}
data remove storage iota_broken:scratch item.components."minecraft:${f}"
data modify storage iota_broken:scratch item.components."!minecraft:${f}" set value {}
`;
mark+=`data remove storage iota_broken:scratch item.components."!minecraft:attribute_modifiers"
data modify storage iota_broken:scratch item.components."minecraft:attribute_modifiers" set value [{type:"minecraft:attack_speed",id:"iota:broken_speed",amount:-1024.0d,operation:"add_value",slot:"mainhand"},{type:"minecraft:attack_damage",id:"iota:broken_damage",amount:-1024.0d,operation:"add_value",slot:"mainhand"}]
data remove storage iota_broken:scratch item.components."!minecraft:minimum_attack_charge"
data modify storage iota_broken:scratch item.components."minecraft:minimum_attack_charge" set value 1.0f
data remove storage iota_broken:scratch item.components."!minecraft:tooltip_display"
data modify storage iota_broken:scratch item.components."minecraft:tooltip_display" set value {hidden_components:[]}
execute if data storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment.saved."minecraft:tooltip_display" run data modify storage iota_broken:scratch item.components."minecraft:tooltip_display" set from storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment.saved."minecraft:tooltip_display"
execute unless data storage iota_broken:scratch item.components."minecraft:tooltip_display".hidden_components run data modify storage iota_broken:scratch item.components."minecraft:tooltip_display".hidden_components set value []
execute unless data storage iota_broken:scratch item.components."minecraft:tooltip_display"{hidden_components:["minecraft:attribute_modifiers"]} run data modify storage iota_broken:scratch item.components."minecraft:tooltip_display".hidden_components append value "minecraft:attribute_modifiers"
data remove storage iota_broken:scratch item.components."!minecraft:tool"
data modify storage iota_broken:scratch item.components."minecraft:tool" set value {rules:[],default_mining_speed:0.0f,damage_per_block:0}
data remove storage iota_broken:scratch item.components."!minecraft:weapon"
data modify storage iota_broken:scratch item.components."minecraft:weapon" set value {item_damage_per_attack:0}
execute if data storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment.saved."minecraft:enchantment_glint_override" run data modify storage iota_broken:scratch item.components."minecraft:enchantment_glint_override" set from storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment.saved."minecraft:enchantment_glint_override"
scoreboard players set #ench im_broken 0
execute store result score #ench im_broken run data get storage iota_broken:scratch item.components."minecraft:enchantments"
execute if score #ench im_broken matches 0 unless data storage iota_broken:scratch item.components."minecraft:enchantment_glint_override" run data modify storage iota_broken:scratch item.components."minecraft:enchantment_glint_override" set value 0b
execute if data storage iota_broken:scratch item.components."minecraft:enchantment_glint_override" run data remove storage iota_broken:scratch item.components."!minecraft:enchantment_glint_override"
execute store result score #max im_broken run data get storage iota_broken:scratch capture.default_max
execute if data storage iota_broken:scratch item.components."minecraft:max_damage" store result score #max im_broken run data get storage iota_broken:scratch item.components."minecraft:max_damage"
scoreboard players remove #max im_broken 1
execute store result storage iota_broken:scratch item.components."minecraft:damage" int 1 run scoreboard players get #max im_broken
summon item ~ ~0.5 ~ {Tags:["iota_broken_buffer"],Invulnerable:1b,NoGravity:1b,PickupDelay:32767s,Item:{id:"minecraft:stone",count:1}}
data modify entity @e[type=item,tag=iota_broken_buffer,limit=1,sort=nearest,distance=..2] Owner set from entity @s UUID
data modify entity @e[type=item,tag=iota_broken_buffer,limit=1,sort=nearest,distance=..2] Item set from storage iota_broken:scratch item
item modify entity @e[type=item,tag=iota_broken_buffer,limit=1,sort=nearest,distance=..2] contents ${id('guard')}
execute store success score #ready im_broken run data get entity @e[type=item,tag=iota_broken_buffer,limit=1,sort=nearest,distance=..2] Item.components."minecraft:custom_data".iota_broken_equipment
$execute if score #ready im_broken matches 1 if score #live im_broken matches 1 if score #different im_broken matches 0 run item replace entity @s $(slot) with air
data merge entity @e[type=item,tag=iota_broken_buffer,limit=1,sort=nearest,distance=..2] {PickupDelay:2s}
tag @e[type=item,tag=iota_broken_buffer,limit=1,sort=nearest,distance=..2] add iota_broken_equipment_drop
tag @e[type=item,tag=iota_broken_buffer,limit=1,sort=nearest,distance=..2] remove iota_broken_buffer
`;
write('function','mark',mark);
const slots=[...Array.from({length:9},(_,i)=>'hotbar.'+i),...Array.from({length:27},(_,i)=>'inventory.'+i),'weapon.offhand','armor.head','armor.chest','armor.legs','armor.feet'];write('function','load','scoreboard objectives add im_broken dummy\n');
write('function','tick',['overworld','the_nether','the_end'].map(dim=>`execute in minecraft:${dim} as @e[type=item,tag=iota_broken_equipment_drop] run data merge entity @s {Age:0s}`).join('\n')+'\n'+slots.map(slot=>`execute as @a at @s if items entity @s ${slot} *[minecraft:custom_data~{iota_broken_equipment:{broken:1b}},minecraft:damage~{durability:{min:2}}] run function ${id('restore')} {slot:"${slot}"}
execute as @a if items entity @s ${slot} *[minecraft:custom_data~{iota_broken_equipment:{broken:1b}}] unless items entity @s ${slot} *[minecraft:enchantments~[{enchantments:"${id('guard')}",levels:{min:1}}]] run item modify entity @s ${slot} ${id('guard')}`).join('\n')+'\n');
write('function','cleanup_guard',slots.map(slot=>`execute as @a if items entity @s ${slot} *[minecraft:enchantments~[{enchantments:"${id('guard')}",levels:{min:1}}]] unless items entity @s ${slot} *[minecraft:custom_data~{iota_broken_equipment:{broken:1b}}] run item modify entity @s ${slot} ${id('remove_guard')}`).join('\n')+'\n');
fs.appendFileSync(path.join(base,'function',prefix+'tick.mcfunction'),'function '+id('cleanup_guard')+'\n');
let restore=`summon item ~ ~0.5 ~ {Tags:["iota_broken_restore"],Invulnerable:1b,NoGravity:1b,PickupDelay:32767s,Item:{id:"minecraft:stone",count:1}}
$item replace entity @e[type=item,tag=iota_broken_restore,limit=1,sort=nearest,distance=..2] contents from entity @s $(slot)
data modify storage iota_broken:scratch item set from entity @e[type=item,tag=iota_broken_restore,limit=1,sort=nearest,distance=..2] Item
`;
for(const f of fields)restore+=`data remove storage iota_broken:scratch item.components."minecraft:${f}"
data remove storage iota_broken:scratch item.components."!minecraft:${f}"
execute if data storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment.saved."minecraft:${f}" run data modify storage iota_broken:scratch item.components."minecraft:${f}" set from storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment.saved."minecraft:${f}"
execute if data storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment.saved."!minecraft:${f}" run data modify storage iota_broken:scratch item.components."!minecraft:${f}" set value {}
`;
restore+=`data remove storage iota_broken:scratch item.components."minecraft:enchantments"."${id('guard')}"
execute store result score #had_data im_broken run data get storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment.had_data
execute store result score #had_ench im_broken run data get storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment.had_ench
execute store result score #ench im_broken run data get storage iota_broken:scratch item.components."minecraft:enchantments"
execute if score #had_ench im_broken matches 0 if score #ench im_broken matches 0 run data remove storage iota_broken:scratch item.components."minecraft:enchantments"
data remove storage iota_broken:scratch item.components."minecraft:custom_data".iota_broken_equipment
execute store result score #size im_broken run data get storage iota_broken:scratch item.components."minecraft:custom_data"
execute if score #had_data im_broken matches 0 if score #size im_broken matches 0 run data remove storage iota_broken:scratch item.components."minecraft:custom_data"
data modify entity @e[type=item,tag=iota_broken_restore,limit=1,sort=nearest,distance=..2] Item set from storage iota_broken:scratch item
$item replace entity @s $(slot) from entity @e[type=item,tag=iota_broken_restore,limit=1,sort=nearest,distance=..2] contents
kill @e[type=item,tag=iota_broken_restore,distance=..2]
`;
write('function','restore',restore);
for(const hook of ['load','tick']){const p=path.join(pack,'data/minecraft/tags/function',hook+'.json');fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify({values:[id(hook)]}));}
fs.writeFileSync(path.join(out,'broken-equipment-scope.json'),JSON.stringify({managed,armor,hands,excluded:Object.keys(native).filter(k=>native[k].components['minecraft:max_damage']&&!managed.includes(k)),mechanism:'Fresh synchronous loot capture before native destruction; healthy items keep their normal enchantment map. Broken-only guard suppresses subsequent wear and bow/crossbow projectile count.',limits:['Armor uses its normal equipped slot; vanilla held-item actions prefer the matching main hand','Non-equipment utilities, Elytra and Wolf Armor are outside this76-item rollout','Arbitrary modded uses and forced offhand packets with identical items require further review'],productionReady:false},null,2)+'\n');console.log(JSON.stringify({pack,managed:managed.length,armor:Object.values(armor).flat().length,hands:hands.length}));
