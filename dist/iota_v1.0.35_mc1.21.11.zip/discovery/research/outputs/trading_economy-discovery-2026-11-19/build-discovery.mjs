import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const project=path.resolve(import.meta.dirname,'../../../../..');
const work=import.meta.dirname;
const read=p=>JSON.parse(fs.readFileSync(path.join(project,p),'utf8'));
const walk=d=>fs.existsSync(d)?fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]):[];
const write=(name,data)=>fs.writeFileSync(path.join(work,name),JSON.stringify(data,null,2)+'\n');
const items=read('vendor/generated/reports/items.json');
const rawRecipes=read('docs/discovery/research/outputs/trading_economy-discovery-2026-11-19/effective-recipes-raw.json');
const settings={date:'2026-11-19',target:'Minecraft Java 1.21.11 + Iota base 1.0.34',valueUnit:'VU',vuPerEmerald:1,targetActiveVUPerHour:480,retailStressMultiplier:1.15,tradeSpreadIsSelected:false,sourceRatesMeasured:false,craftSecondsPerBatch:0.4,nonstackableCraftSeconds:6,cutSecondsPerBatch:0.15,smeltActiveSecondsPerItem:0.2,smithSecondsPerItem:10,smeltFuelVUPerItem:0.025,transformationProportionalMarkup:0,enchantApplicationServiceVU:8,xpPointReferenceVU:0.01};
write('assumptions.json',settings);
const hash=f=>crypto.createHash('sha256').update(fs.readFileSync(path.join(project,f))).digest('hex');
const modules=['hands_off','tools','recipes','drops','world','hearts'];
const tags=new Map();
function tagRead(file,ns,rel){const j=JSON.parse(fs.readFileSync(file));const id=ns+':'+rel.slice(0,-5);tags.set(id,j.replace?j.values:[...(tags.get(id)||[]),...j.values]);}
for(const f of walk(path.join(project,'vendor/generated/data/minecraft/tags/item')))tagRead(f,'minecraft',path.relative(path.join(project,'vendor/generated/data/minecraft/tags/item'),f).replaceAll('\\','/'));
for(const m of modules)for(const f of walk(path.join(project,'modules',m,'data'))){const rel=path.relative(path.join(project,'modules',m,'data'),f).replaceAll('\\','/');const x=rel.match(/^([^/]+)\/tags\/item\/(.+\.json)$/);if(x)tagRead(f,x[1],x[2]);}
const tagCache=new Map(),unresolvedTags=new Set();
function expand(x,stack=[]){
 if(Array.isArray(x))return [...new Set(x.flatMap(a=>expand(a,stack)))];
 if(x&&typeof x==='object')return expand(x.item||x.tag&&'#'+x.tag||x.id,stack);
 if(typeof x!=='string')return [];
 if(!x.startsWith('#'))return items[x]?[x]:[];
 const id=x.slice(1);if(tagCache.has(id))return tagCache.get(id);if(stack.includes(id))throw Error('Tag cycle '+id);
 if(!tags.has(id)){unresolvedTags.add(id);return [];}
 const out=[...new Set(tags.get(id).flatMap(v=>expand(typeof v==='string'?v:v.id,[...stack,id])))];tagCache.set(id,out);return out;
}
const excludedNames=new Set(['air','barrier','bedrock','budding_amethyst','command_block','chain_command_block','repeating_command_block','command_block_minecart','debug_stick','jigsaw','knowledge_book','light','structure_block','structure_void','spawner','trial_spawner','vault','end_portal_frame','reinforced_deepslate','farmland','dirt_path','frogspawn','suspicious_sand','suspicious_gravel','petrified_oak_slab','test_block','test_instance_block','player_head']);
const excluded=id=>{const n=id.split(':')[1];return n.endsWith('_spawn_egg')||excludedNames.has(n)||n.startsWith('infested_');};
const seed=new Map();
function add(names,value,group,renewability='renewable',reason='Initial design anchor; not an observed price or measured output rate',confidence='Low'){
 for(const n of names.split(/\s+/).filter(Boolean)){const id=n.includes(':')?n:'minecraft:'+n;if(items[id]&&!excluded(id))seed.set(id,{value,group,renewability,reason,confidence});}
}
add('emerald',1,'Currency','mixed','Currency reference: one VU per emerald is a discovery scale, not an implemented trade', 'Definition');
add('cobblestone stone andesite granite diorite gravel sand red_sand dirt coarse_dirt root_ed_dirt',0.03125,'Common terrain','renewable');
add('cobbled_deepslate deepslate tuff blackstone basalt smooth_basalt netherrack',0.04,'Stone and Nether terrain','mixed');
add('end_stone calcite grass_block podzol mycelium mud clay snow_block ice',0.125,'Special terrain','mixed');
add('obsidian',1,'Hard terrain','renewable');add('crying_obsidian',2,'Hard terrain','renewable');
add('coal',0.5,'Fuel','renewable');add('flint',0.25,'Tool inputs','renewable','Iota adds renewable stone and grass sources; benchmark must include them');
add('raw_copper',0.5,'Metals','finite');add('raw_iron',2,'Metals','mixed');add('raw_gold',4,'Metals','mixed');
add('diamond',16,'Gems','finite');add('lapis_lazuli redstone',0.125,'Minerals','renewable');add('quartz',0.5,'Minerals','renewable');
add('ancient_debris',64,'Nether progression','finite');add('amethyst_shard',0.125,'Minerals','renewable');
add('oak_log spruce_log birch_log jungle_log acacia_log dark_oak_log mangrove_log cherry_log pale_oak_log',0.25,'Timber','renewable');
add('crimson_stem warped_stem',0.375,'Timber','renewable');add('bamboo',0.00625,'Fast crops','renewable');add('sugar_cane',0.0625,'Crops','renewable');
add('nether_wart_block warped_wart_block',0.125,'Nether crops','renewable','Giant-fungus harvesting reference; no conversion back into Nether Wart is assumed');
add('wheat beetroot cocoa_beans',0.125,'Crops','renewable');add('carrot potato sweet_berries glow_berries cactus kelp',0.0625,'Crops','renewable');
add('pumpkin',0.25,'Crops','renewable');add('melon_slice',0.03125,'Crops','renewable');
add('wheat_seeds beetroot_seeds',0.03125,'Seeds','renewable');add('torchflower_seeds pitcher_pod',8,'Exploration seeds','discovery-gated renewable','Discovery/archaeology seed acquisition is scarce; farmed flowers do not reproduce the seed');
add('brown_mushroom red_mushroom',0.125,'Fungi','renewable');add('nether_wart',0.25,'Brewing crops','renewable');
add('apple',0.5,'Food','renewable');add('egg',0.125,'Food','renewable');add('beef porkchop mutton chicken rabbit',1,'Animal food','renewable');
add('cod salmon',0.75,'Fish','renewable');add('tropical_fish pufferfish',2,'Fish','renewable');
add('rotten_flesh bone gunpowder string arrow',0.25,'Mob products','renewable');add('spider_eye slime_ball honeycomb',0.5,'Mob products','renewable');
add('feather',0.125,'Animal products','renewable');add('leather',1,'Animal products','renewable');add('white_wool',0.5,'Textiles','renewable');
add('ink_sac glow_ink_sac',0.75,'Dyes and inks','renewable');add('blaze_rod ender_pearl',4,'Adventure mob products','renewable');
add('ghast_tear phantom_membrane magma_cream shulker_shell',8,'Adventure mob products','renewable');
add('rabbit_foot',4,'Animal products','renewable');add('turtle_scute',8,'Animal products','renewable');add('armadillo_scute',0.5,'Animal products','renewable');
add('prismarine_shard',0.25,'Marine products','renewable');add('prismarine_crystals',0.5,'Marine products','renewable');
add('nautilus_shell',8,'Marine treasures','renewable');add('heart_of_the_sea',64,'Marine treasures','finite');
add('sponge',8.1,'Marine treasures','finite');add('wet_sponge',8,'Marine treasures','finite');
add('wither_skeleton_skull',64,'Mob trophies','renewable');add('nether_star',224.5,'Boss products','renewable','Three skull reference values plus summon materials and boss-work allowance; farming rates remain unmeasured');add('dragon_egg',512,'Unique trophies','unique');
add('dragon_head',64,'Exploration treasures','finite');add('elytra',384,'Exploration treasures','finite');add('trident',96,'Adventure equipment','renewable');
add('totem_of_undying',64,'Adventure equipment','renewable');add('heavy_core',256,'Trial treasures','finite per-player vault access');add('breeze_rod',8,'Trial products','renewable');
add('echo_shard',32,'Exploration treasures','finite');add('disc_fragment_5',8,'Exploration treasures','finite');
add('trial_key',16,'Trial treasures','renewable');add('ominous_trial_key',32,'Trial treasures','renewable');
add('resin_clump',0.25,'Mob-linked materials','renewable');add('popped_chorus_fruit chorus_fruit',0.5,'End crops','renewable');
add('chorus_flower',2,'End crops','renewable');add('glowstone_dust',0.25,'Nether materials','renewable');
add('dried_ghast',32,'Nether treasures','renewable');add('dragon_breath',8,'Brewing treasures','renewable');
add('soul_sand soul_soil crimson_nylium warped_nylium',0.125,'Nether terrain','mixed');
add('crimson_fungus warped_fungus crimson_roots warped_roots nether_sprouts twisting_vines weeping_vines mangrove_roots rooted_dirt pale_hanging_moss cactus_flower',0.125,'Vegetation','renewable');
add('blue_egg brown_egg',0.125,'Food','renewable');add('shroomlight',0.5,'Nether crops','renewable');
add('amethyst_cluster',0.5,'Mineral growth','renewable');add('small_amethyst_bud medium_amethyst_bud large_amethyst_bud',0.25,'Mineral growth','renewable');
add('bee_nest',4,'Animal habitat','renewable');add('bell',16,'Village utility','mixed');
add('goat_horn',8,'Animal products','renewable');add('name_tag',8,'Adventure utility','renewable');
add('sniffer_egg',64,'Archaeology progression','discovery-gated');add('turtle_egg',2,'Animal products','renewable');
add('chorus_plant',0.5,'End crops','renewable');add('poisonous_potato',0.0625,'Crop byproducts','renewable');
add('gilded_blackstone',2,'Structure materials','finite');add('firework_star',1,'Component-sensitive fireworks','renewable','One unadorned star only; colors, shapes and effects require component pricing');
add('flow_banner_pattern guster_banner_pattern piglin_banner_pattern',16,'Exploration patterns','mixed');add('globe_banner_pattern',8,'Decoration patterns','mixed');
add('iron_horse_armor iron_nautilus_armor chainmail_chestplate',16,'Found equipment','mixed');
add('chainmail_helmet chainmail_leggings',12,'Found equipment','mixed');add('chainmail_boots',8,'Found equipment','mixed');
add('golden_horse_armor golden_nautilus_armor',24,'Found equipment','mixed');
add('copper_horse_armor copper_nautilus_armor',8,'Found equipment','mixed');
add('diamond_horse_armor diamond_nautilus_armor',96,'Found equipment','mixed');
add('copper_golem_statue',6,'Oxidation products','renewable','Statue outcome is component/state dependent; base material reference only');
add('experience_bottle',4,'XP consumables','renewable','Item includes variable XP; do not count XP value twice');
add('honey_bottle',0.75,'Food and utility','renewable');
add('snowball',0.015625,'Common terrain','renewable');add('clay_ball',0.0625,'Minerals','renewable');
add('sea_pickle seagrass vine glow_lichen moss_block pale_moss_block azalea flowering_azalea hanging_roots leaf_litter',0.125,'Vegetation','renewable');
add('small_dripleaf big_dripleaf',0.5,'Vegetation','renewable');add('spore_blossom',8,'Exploration vegetation','finite');
add('lily_pad',0.25,'Vegetation','renewable');add('lily_of_the_valley',0.25,'Flowers','renewable');
add('pink_petals wildflowers firefly_bush bush short_dry_grass tall_dry_grass',0.125,'Vegetation','renewable');
add('short_grass tall_grass fern large_fern dead_bush',0.0625,'Vegetation','mixed');
add('red_mushroom_block brown_mushroom_block mushroom_stem',0.125,'Fungi','renewable');
add('cobweb',0.5,'Structure materials','finite');add('pointed_dripstone',0.25,'Renewable minerals','renewable');add('dripstone_block',0.125,'Renewable minerals','mixed');
add('sculk sculk_vein sculk_sensor',0.5,'Sculk','renewable');add('sculk_catalyst',8,'Sculk','renewable');add('sculk_shrieker calibrated_sculk_sensor',4,'Sculk','mixed');
add('ochre_froglight verdant_froglight pearlescent_froglight',1,'Mob-linked materials','renewable');
add('bone_block',2,'Mob products','renewable');
add('book',0.75,'Books and knowledge','renewable');add('enchanted_book',0.75,'Books and knowledge','mixed','Base book only; mandatory enchantment component premium is separate');
add('potion splash_potion lingering_potion tipped_arrow',0.25,'Brewing components','mixed','Base item placeholder only; mandatory potion/effect variant pricing is separate');
add('suspicious_stew',1,'Food variants','renewable','Effect variant not included in generic item valuation');
add('ominous_bottle',16,'Adventure variants','renewable','Ominous level changes gameplay; generic reference is a placeholder');
add('filled_map written_book enchanted_golden_apple',32,'Component-sensitive treasures','mixed','Value depends on map destination, authored contents or source; low-confidence base reference');
add('enchanted_golden_apple',256,'Exploration treasures','finite','Rare structure reward reference, separate from ordinary Golden Apple; scarcity is unmeasured');
for(const id of Object.keys(items)){
 const n=id.split(':')[1];if(seed.has(id)||excluded(id))continue;
 if(/(?:_leaves|_sapling|mangrove_propagule)$/.test(n))add(n,0.125,'Tree products','renewable');
 else if(/(?:^stripped_.*(?:log|wood|stem|hyphae)$|(?:_wood|_hyphae)$)/.test(n)){}
 else if(n.endsWith('_coral')||n.endsWith('_coral_fan'))add(n,n.startsWith('dead_')?0.25:0.5,'Corals','mixed');
 else if(n.endsWith('_coral_block'))add(n,n.startsWith('dead_')?0.5:1,'Corals','mixed');
 else if(n.endsWith('_pottery_sherd'))add(n,8,'Archaeology','finite');
 else if(n.endsWith('_armor_trim_smithing_template')||n==='netherite_upgrade_smithing_template')add(n,128,'Smithing templates','mixed','Initial exploration-copy reference; cloning recipes can establish a cheaper replacement route');
 else if(n.startsWith('music_disc_'))add(n,32,'Collectibles','mixed');
 else if(n.endsWith('_skull')||['creeper_head','zombie_head','piglin_head'].includes(n))add(n,32,'Mob trophies','renewable');
 else if(/^(dandelion|poppy|blue_orchid|allium|azure_bluet|red_tulip|orange_tulip|white_tulip|pink_tulip|oxeye_daisy|cornflower|sunflower|lilac|rose_bush|peony|wither_rose|open_eyeblossom|closed_eyeblossom|torchflower|pitcher_plant)$/.test(n))add(n,n==='wither_rose'?2:0.25,'Flowers',n==='torchflower'||n==='pitcher_plant'?'discovery-gated':'renewable');
}
// Ore values are source references, not complete Fortune/Silk-Touch valuations.
const oreSeeds={coal_ore:1.1,iron_ore:4.4,copper_ore:3.85,gold_ore:8.8,redstone_ore:0.75,lapis_ore:1.7875,diamond_ore:35.2,emerald_ore:16,nether_gold_ore:4,nether_quartz_ore:1.1};
for(const [ore,value]of Object.entries(oreSeeds))add(ore+' deepslate_'+ore,value,'Ore blocks','finite','Silk-Touch block reference; Fortune conversion is audited separately');
const recipeRows=[];
function normalize(id,r){
 let slots=[],kind='other',note='';
 const type=r.type.replace('minecraft:','');
 if(type==='crafting_shaped'){for(const c of r.pattern.join(''))if(c!==' ')slots.push(expand(r.key[c]));kind='craft';}
 else if(type==='crafting_shapeless'){slots=r.ingredients.map(x=>expand(x));kind='craft';}
 else if(type==='stonecutting'){slots=[expand(r.ingredient)];kind='cut';}
 else if(['smelting','blasting','smoking','campfire_cooking'].includes(type)){slots=[expand(r.ingredient)];kind='smelt';}
 else if(type==='smithing_transform'){slots=[expand(r.template),expand(r.base),expand(r.addition)];kind='smith';note='Input components can be retained; base item only';}
 else if(type==='crafting_transmute'){slots=[expand(r.input),expand(r.material)];kind='transmute';note='Component retention requires variant audit';}
 else note='Dynamic/component recipe; no fixed material-output valuation inferred';
 const output=r.result?.id||null,count=r.result?.count||1;
 const [ns,resource]=id.split(':');
 const normalized={id,type,kind,output,count,slots,componentSensitive:!!r.result?.components||kind==='smith'||kind==='transmute'||!output,note,processingSeconds:kind==='cut'?settings.cutSecondsPerBatch:kind==='smelt'?settings.smeltActiveSecondsPerItem:kind==='smith'?settings.smithSecondsPerItem:items[output]?.components['minecraft:max_stack_size']===1?settings.nonstackableCraftSeconds:settings.craftSecondsPerBatch,cookingSeconds:r.cookingtime?r.cookingtime/20:null,experience:r.experience??null,origin:id.startsWith('iota_')?'Iota addition':fs.existsSync(path.join(project,'modules/recipes/data',ns,'recipe',resource+'.json'))?'Iota override':'Vanilla'};
 if(!output||!slots.length||slots.some(x=>!x.length))normalized.status='manual/dynamic';else normalized.status='fixed';
 return normalized;
}
for(const [id,r]of Object.entries(rawRecipes))recipeRows.push(normalize(id,r));
// Reversible one-material cycles carry no manufacture premium or processing fee.
const edges=new Map();for(const r of recipeRows){if(r.status!=='fixed')continue;const keys=r.slots.map(x=>JSON.stringify(x));if(new Set(keys).size===1)for(const from of r.slots[0]){if(!edges.has(from))edges.set(from,[]);edges.get(from).push(r.output);}}
let index=0,component=0;const st=[],on=new Set(),idx=new Map(),low=new Map(),scc=new Map();
function visit(v){idx.set(v,index);low.set(v,index++);st.push(v);on.add(v);for(const n of edges.get(v)||[]){if(!idx.has(n)){visit(n);low.set(v,Math.min(low.get(v),low.get(n)));}else if(on.has(n))low.set(v,Math.min(low.get(v),idx.get(n)));}if(low.get(v)===idx.get(v)){let w;do{w=st.pop();on.delete(w);scc.set(w,component);}while(w!==v);component++;}}
for(const id of Object.keys(items))if(!idx.has(id))visit(id);
for(const r of recipeRows)r.reversible=r.status==='fixed'&&(r.id.endsWith(':wool_to_string')||r.slots.every(opts=>opts.every(id=>scc.get(id)===scc.get(r.output))));
const commodity=new Map(Object.entries(items).map(([id,raw])=>[id,{id,raw,value:seed.get(id)?.value??Infinity,resourceCost:seed.get(id)?.value??Infinity,route:seed.has(id)?'anchor':null,anchor:seed.get(id)||null}]));
function best(options,field){let result=null;for(const id of options){const x=commodity.get(id);if(x&&!excluded(id)&&Number.isFinite(x[field])&&(!result||x[field]<result[field]))result=x;}return result;}
const resolved=[];
const manualWorld=[];
const remainders={milk_bucket:'bucket',water_bucket:'bucket',lava_bucket:'bucket',honey_bottle:'glass_bottle',dragon_breath:'glass_bottle'};
function netInput(x,field){const remaining=remainders[x.id.slice(10)];const refund=remaining?commodity.get('minecraft:'+remaining)?.[field]:0;return x[field]-(Number.isFinite(refund)?refund:0);}
function solve(){let passes=0,changed=true;while(changed&&passes<140){changed=false;passes++;for(const r of recipeRows){if(r.status!=='fixed'||excluded(r.output))continue;const selected=r.slots.map(opts=>best(opts,'value'));if(selected.some(x=>!x))continue;const base=selected.reduce((s,x)=>s+netInput(x,'value'),0);const resource=r.slots.map(opts=>best(opts,'resourceCost'));const resourceSum=resource.reduce((s,x)=>s+(x?netInput(x,'resourceCost'):Infinity),0);const process=r.reversible?0:r.processingSeconds*settings.targetActiveVUPerHour/3600;const fuel=r.kind==='smelt'&&r.type!=='campfire_cooking'?settings.smeltFuelVUPerItem:0;const v=(base+process+fuel)/r.count,rc=(resourceSum+fuel)/r.count;const x=commodity.get(r.output);if(v<x.value-1e-9){x.value=v;x.route=r.id;changed=true;}if(rc<x.resourceCost-1e-9){x.resourceCost=rc;changed=true;}}
 for(const w of manualWorld){const a=commodity.get('minecraft:'+w.input),b=commodity.get('minecraft:'+w.output);if(!a||!b||!Number.isFinite(a.value))continue;const v=(a.value+w.labour)/w.count,rc=a.resourceCost/w.count;if(v<b.value-1e-9){b.value=v;b.route='world:'+w.input+'->'+w.output;changed=true;}if(rc<b.resourceCost-1e-9){b.resourceCost=rc;changed=true;}}
 }return passes;}
const passes1=solve();
// Explicit world transformations missing from the recipe registry.
function world(input,output,count=1,labour=0,note=''){manualWorld.push({input,output,count,labour,note});}
for(const species of ['oak','spruce','birch','jungle','acacia','dark_oak','mangrove','cherry','pale_oak']){world(species+'_log','stripped_'+species+'_log',1,0.02,'Axe stripping; tool wear excluded');world(species+'_wood','stripped_'+species+'_wood',1,0.02,'Axe stripping');}
for(const species of ['crimson','warped']){world(species+'_stem','stripped_'+species+'_stem',1,0.02,'Axe stripping');world(species+'_hyphae','stripped_'+species+'_hyphae',1,0.02,'Axe stripping');}
for(const [filled,fee]of [['water_bucket',0.25],['lava_bucket',0.5],['milk_bucket',0.5],['powder_snow_bucket',0.5]])world('bucket',filled,1,fee,'Container value plus filling service; crafting remainders are credited');
for(const [filled,fee]of [['axolotl_bucket',8],['cod_bucket',1],['salmon_bucket',1],['pufferfish_bucket',3],['tropical_fish_bucket',3],['tadpole_bucket',2]])world('bucket',filled,1,fee,'Live capture reference; variants and capture time are unmeasured');
world('anvil','chipped_anvil',1,0,'Used capital item; reference later discounted by condition');
world('anvil','damaged_anvil',1,0,'Used capital item; reference later discounted by condition');
world('bamboo_block','stripped_bamboo_block',1,0.02,'Axe stripping');
world('pumpkin','carved_pumpkin',1,0.02,'Shearing; seed byproduct is handled separately, not credited twice');
for(const id of Object.keys(items)){
 const n=id.slice(10);
 if(n.endsWith('_concrete'))world(n+'_powder',n,1,0.02,'Water hardening; placement/breaking service is an unmeasured assumption');
 for(const prefix of ['exposed_','weathered_','oxidized_'])if(n.startsWith(prefix)&&n.includes('copper')||n===prefix+'lightning_rod'){const raw=n.slice(prefix.length);world(raw==='copper'?'copper_block':raw,n,1,0,'Passive oxidation; no scarcity premium selected');}
}
world('wet_sponge','sponge',1,0.1,'Drying service; recipe also exists');
let passes2=solve();
function groupOf(id,x){const n=id.split(':')[1],c=x.raw.components;
 if(excluded(id))return 'Excluded technical/unobtainable';if(x.anchor?.group)return x.anchor.group;
 if(/_(pickaxe|axe|shovel|hoe)$/.test(n))return 'Productive tools';
 if(/_(sword|spear)$/.test(n)||['bow','crossbow','mace','shield'].includes(n))return 'Weapons and shields';
 if(/_(helmet|chestplate|leggings|boots|horse_armor)$/.test(n))return 'Armor';
 if(n.includes('copper')||n.includes('iron')||n.includes('gold')||n.includes('netherite'))return 'Metal products';
 if(/_(slab|stairs|wall)$/.test(n))return 'Building shapes';
 if(/_(wool|carpet|bed|banner)$/.test(n))return 'Textiles';
 if(n.endsWith('_dye'))return 'Dyes and inks';
 if(/_(planks|log|wood|stem|hyphae|fence|fence_gate|door|trapdoor|boat|raft|sign|hanging_sign|button|pressure_plate)$/.test(n))return 'Wood products';
 if(n.includes('glass')||n.includes('terracotta')||n.includes('concrete'))return 'Building materials';
 if(c['minecraft:food'])return 'Food';
 if(/redstone|repeater|comparator|piston|observer|dispenser|dropper|hopper|rail|lever|target|daylight|crafter|sculk/.test(n))return 'Automation';
 if(/bundle|shulker_box|chest|barrel|bucket/.test(n))return 'Storage and containers';
 if(/potion|brewing|blaze|fermented|glistering/.test(n))return 'Brewing';
 return 'Crafted utility and decoration';
}
// Unresolved records remain visible rather than receiving fabricated exact prices.
const initialUnresolved=[...commodity.values()].filter(x=>!excluded(x.id)&&!Number.isFinite(x.value)).map(x=>x.id);
write('unresolved-first-pass.json',initialUnresolved);
const overridesPath=path.join(work,'reviewed-overrides.json');
if(fs.existsSync(overridesPath))for(const [id,s]of Object.entries(JSON.parse(fs.readFileSync(overridesPath)))){const x=commodity.get(id.includes(':')?id:'minecraft:'+id);if(x&&!excluded(x.id)){x.value=s.value;x.resourceCost=s.value;x.anchor={...s,confidence:'Low',reason:s.reason||'Reviewed provisional acquisition anchor; no in-game measurement'};x.route='reviewed-anchor';}}
solve();
const values=[];
for(const [id,x]of commodity){const n=id.slice(10),c=x.raw.components;const maxDamage=/^(wooden|stone|copper|iron|golden|diamond|netherite)_(pickaxe|axe|shovel|hoe|sword)$/.exec(n);let damage=c['minecraft:max_damage']??null;if(maxDamage){const m=read('modules/tools/data/iota_tools/item_modifier/'+maxDamage[1]+'.json');damage=m.components['minecraft:max_damage']??damage;}
 const r=recipeRows.find(r=>r.id===x.route);const renewable=x.anchor?.renewability||'depends on inputs';
 const isExcluded=excluded(id),hasValue=Number.isFinite(x.value)&&!isExcluded;
 const sensitive=!!c['minecraft:potion_contents']||['enchanted_book','potion','splash_potion','lingering_potion','tipped_arrow','filled_map','written_book','ominous_bottle','firework_rocket','firework_star','suspicious_stew','bundle'].includes(n)||n.endsWith('_bundle')||n.endsWith('shulker_box');
 const material=/^(wooden|stone|copper|iron|golden|diamond|netherite)_(pickaxe|axe|shovel|hoe|sword|spear)$/.exec(n)?.[1];
 const repairItem=material?({wooden:'stick',stone:'flint',copper:'copper_ingot',iron:'iron_ingot',golden:'gold_ingot',diamond:'diamond',netherite:'netherite_scrap'})[material]:null;
 const repairValue=repairItem?commodity.get('minecraft:'+repairItem)?.value:null;
 values.push({id,name:n.split('_').map(w=>w[0]?.toUpperCase()+w.slice(1)).join(' '),group:groupOf(id,x),status:isExcluded?'excluded':hasValue?sensitive?'component-sensitive base':'provisional':'unpriced - review required',value_vu:hasValue?Number(x.value.toFixed(6)):null,resource_cost_vu:hasValue?Number(x.resourceCost.toFixed(6)):null,emerald_reference:hasValue?Number((x.value/settings.vuPerEmerald).toFixed(6)):null,stack:c['minecraft:max_stack_size']??64,iota_max_durability:damage,replacement_vu_per_durability:hasValue&&damage?x.value/damage:null,repair_ingredient:repairItem?'minecraft:'+repairItem:null,repair_vu_per_durability:repairValue&&damage?repairValue/Math.floor(damage/4):null,source_route:hasValue?x.route:null,anchor_vu:x.anchor?.value??null,renewability:renewable,confidence:hasValue?x.anchor?.confidence||'Derived from provisional inputs':'Not priced',component_sensitive:sensitive,note:isExcluded?'No ordinary Survival inventory acquisition or item is a technical/owner-specific placeholder; not a proposed market item':x.anchor?.reason||r?.note||'Cheapest resolved recipe route; candidate inputs and processing assumptions require audit'});
}
for(const r of recipeRows){
 const chosen=r.slots.map(opts=>best(opts,'value'));const resolvedAll=r.status==='fixed'&&chosen.every(Boolean);
 const inputValue=resolvedAll?chosen.reduce((s,x)=>s+netInput(x,'value'),0):null;const outputValue=r.output?commodity.get(r.output)?.value:null;const out=Number.isFinite(outputValue)?outputValue*r.count:null;
 Object.assign(r,{chosen_inputs:chosen.map(x=>x?.id||null),input_value_vu:inputValue,output_value_vu:out,processing_value_vu:r.reversible?0:r.processingSeconds*settings.targetActiveVUPerHour/3600,fuel_value_vu:r.kind==='smelt'&&r.type!=='campfire_cooking'?settings.smeltFuelVUPerItem:0,net_transform_vu:inputValue!==null&&out!==null?out-inputValue:null,retail_input_stress_vu:inputValue!==null?inputValue*settings.retailStressMultiplier:null});
}
const enchants=[];const treasure=new Set(JSON.parse(fs.readFileSync(path.join(project,'vendor/generated/data/minecraft/tags/enchantment/treasure.json'))).values.map(x=>typeof x==='string'?x:x.id));
for(const file of fs.readdirSync(path.join(project,'vendor/generated/data/minecraft/enchantment'))){const e=read('vendor/generated/data/minecraft/enchantment/'+file);const name=file.slice(0,-5),isCurse=name.includes('curse'),base={efficiency:8,unbreaking:8,fortune:24,silk_touch:64,mending:128,wind_burst:128,swift_sneak:32,soul_speed:24,frost_walker:24}[name]??8;for(let l=1;l<=e.max_level;l++)enchants.push({id:'minecraft:'+name,level:l,treasure:treasure.has('minecraft:'+name),curse:isCurse,base_book_vu:commodity.get('minecraft:book').value,premium_vu:isCurse?0:base*2**(l-1),book_total_vu:commodity.get('minecraft:book').value+(isCurse?0:base*2**(l-1)),confidence:'Low - acquisition route dependent',note:isCurse?'No positive standard-market curse premium; collector demand is not selected':'Provisional component premium; not an Enchanting Table probability or measured acquisition cost'});}
const summary={...settings,itemCount:values.length,pricedItemCount:values.filter(x=>x.value_vu!==null).length,excludedItemCount:values.filter(x=>x.status==='excluded').length,unpriced:values.filter(x=>x.status==='unpriced - review required').map(x=>x.id),recipeCount:recipeRows.length,fixedRecipeCount:recipeRows.filter(x=>x.status==='fixed').length,dynamicOrUnresolvedRecipeCount:recipeRows.filter(x=>x.status!=='fixed').length,reversibleRecipes:recipeRows.filter(x=>x.reversible).length,unresolvedTags:[...unresolvedTags],passes:[passes1,passes2],enchantmentVariants:enchants.length,sourceHashes:{items:hash('vendor/generated/reports/items.json'),recipes:hash('docs/discovery/research/outputs/trading_economy-discovery-2026-11-19/effective-recipes-raw.json')},groups:[...new Set(values.map(x=>x.group))].map(group=>({group,count:values.filter(x=>x.group===group).length,priced:values.filter(x=>x.group===group&&x.value_vu!==null).length}))};
write('items.json',values);write('recipes.json',recipeRows);write('enchantments.json',enchants);write('world-transformations.json',manualWorld);write('summary.json',summary);
function csv(file,rows,columns=Object.keys(rows[0]||{})){const q=v=>{if(v===null||v===undefined)return '';const s=typeof v==='object'?JSON.stringify(v):String(v);return '"'+s.replaceAll('"','""')+'"';};fs.writeFileSync(path.join(work,file),columns.join(',')+'\n'+rows.map(r=>columns.map(c=>q(r[c])).join(',')).join('\n')+'\n');}
csv('item-values.csv',values);csv('recipe-paths.csv',recipeRows);csv('enchantment-values.csv',enchants);
console.log(JSON.stringify(summary,null,2));
