import fs from 'node:fs';
import path from 'node:path';
const work=import.meta.dirname;
const load=n=>JSON.parse(fs.readFileSync(path.join(work,n),'utf8'));
const items=load('items.json'),recipes=load('recipes.json'),activities=load('activities.json'),summary=load('summary.json'),analysis=load('analysis-summary.json'),denom=load('denomination-audit.json'),barter=load('barter-reference.json');
const fmt=(v,n=3)=>Number.isFinite(v)?v.toLocaleString('en-US',{maximumFractionDigits:n}):'—';
const row=(...cells)=>'| '+cells.join(' | ')+' |';
const selected='cobblestone sand oak_log oak_planks stick bamboo sugar_cane wheat carrot potato coal charcoal flint raw_copper copper_ingot raw_iron iron_ingot raw_gold gold_ingot diamond ancient_debris netherite_scrap netherite_ingot leather rabbit_hide rotten_flesh white_wool string paper book glass glass_bottle chest hopper repeater comparator dispenser observer redstone_lamp iron_pickaxe golden_pickaxe diamond_pickaxe netherite_pickaxe copper_spear iron_spear diamond_spear shield iron_chestplate diamond_chestplate netherite_chestplate ice packed_ice blue_ice elytra trident mace enchanted_golden_apple shulker_shell bundle'.split(' ');
const itemTable=selected.map(n=>items.find(i=>i.id==='minecraft:'+n)).filter(Boolean).map(i=>row(i.name,fmt(i.value_vu),i.source_route==='anchor'?'Proposed acquisition anchor':i.source_route.replace('minecraft:',''),i.component_sensitive?'Base item only':'Base / full durability')).join('\n');
const activityTable=activities.map(a=>row(a.name,a.stage,fmt(a.active_minutes_per_world_hour,0),fmt(a.net_vu_per_world_hour,1),fmt(a.net_vu_per_active_hour,1),fmt(a.relative_active_to_stage_target,2)+'×')).join('\n');
const groupTable=summary.groups.map(g=>{const a=items.filter(i=>i.group===g.group&&i.value_vu!==null);return row(g.group,g.count,g.priced,a.length?fmt(Math.min(...a.map(i=>i.value_vu))):'—',a.length?fmt(Math.max(...a.map(i=>i.value_vu))):'—');}).join('\n');
const chains=['repeater','comparator','dispenser','leather','bundle','diamond_pickaxe','netherite_pickaxe'].map(n=>{const i=items.find(i=>i.id==='minecraft:'+n),r=recipes.find(r=>r.id===i.source_route);if(!r)return `- **${i.name}:** ${fmt(i.value_vu)} VU; ${i.source_route}.`;const counts=new Map();for(const x of r.chosen_inputs||[])counts.set(x,(counts.get(x)||0)+1);return `- **${i.name}:** ${[...counts].map(([k,q])=>q+' '+k.replace('minecraft:','')).join(' + ')} → ${r.count} item(s). Batch input ${fmt(r.input_value_vu)} VU + active-work allowance ${fmt(r.processing_value_vu)} VU + fuel ${fmt(r.fuel_value_vu)} VU. Selected unit reference **${fmt(i.value_vu)} VU**. Route: \`${r.id}\`.`;}).join('\n');
const loot=load('loot-source-summary.json');
const text=`# Economy discovery — Iota Java 1.21.11

Status: **initial research; no approved trade prices or profession changes**. Prepared 2026-11-19 against the current Iota base 1.0.34 source. Tool Mastery and Magical Discovery remain frozen optional expansions, outside the base recipe graph. This document is intentionally separate from Trading Design Directions and Design Directions.

## Read this first

The deliverable is an auditable starting matrix, not a claim that every playstyle is already balanced. It covers **${items.length} item IDs**, proposes **${analysis.priced} base values**, explicitly excludes **${analysis.technicalExcluded} technical/unobtainable or special-identity IDs**, and traces **${recipes.length} effective recipe definitions**. There are **${analysis.variants} additional component variants**, **${activities.length} illustrative activity scenarios**, and **351 mechanical sensitivity cases**.

Recipe definitions, stack limits, enchantment caps and native components come from source data. **All monetary anchors, production rates, capital estimates, labour allowances and enchantment premiums are research hypotheses. No production rate was measured in Minecraft.** The comparable incomes in some scenarios partly result from deliberately calibrated assumptions; they are not independent evidence of balance.

The central result is structural: a single unlimited unit-price list cannot give equal income to both hand gathering and arbitrarily scaled automation. A useful next audit must compare investment, active effort, elapsed time, risk and market absorption together. Renewable does not automatically mean cheap to obtain; nonrenewable does not automatically mean difficult to collect in bulk.

## Files and workbook

- The Excel workbook contains Overview, Items, Activities, Parameters, Baskets, Recipes, Variants, Sensitivity, Quotes, PricePressure, Acquisition, Audit and Sources.
- \`item-values.csv\`: every registry ID, proposed value, group, acquisition/recipe basis, confidence, stack size, component flag, durability and repair reference.
- \`recipe-paths.csv\` / \`recipes.json\`: every effective definition, ingredient alternatives, selected inputs, yield, processing allowance and reversible-route flag.
- \`component-variants.csv\`: 128 enchantment-level book variants, potion forms/effects, and seven example enchanted tools. This does not enumerate infinitely many possible item component combinations.
- \`activities.csv\` and \`activity-baskets.csv\`: throughput, inputs, outputs, capital, wear, XP opportunity cost and both income measures.
- \`sensitivity.csv\` and \`sensitivity-summary.csv\`: explicit stress scenarios; not confidence intervals.
- \`activity-price-pressure.csv\`: the primary-output value that would meet the active-income target if every other price, cost and rate stayed fixed. This is a linked-price audit starting point, not a set of independent prices ready to adopt.
- \`integer-quotes.csv\` and \`denomination-audit.json\`: denomination/stack diagnostics, not a configured trade catalog.
- \`audit-findings.csv\`: route losses, dynamic recipes, activity gaps and currency rounding issues.
- \`item-source-coverage.csv\` and \`loot-source-occurrences.csv\`: a structural acquisition index spanning ${loot.effectiveLootTables} effective loot tables, ${loot.occurrences} item occurrences and ${loot.itemsWithLootOccurrence} item IDs with at least one indexed occurrence. The other ${loot.itemsWithoutDirectLootOccurrence} IDs are not thereby unobtainable: recipes, growing, interactions, native trades and implicit drop paths are separate. Conditions and local pool weights are retained, not flattened into false unconditional probabilities.
- \`validation.json\`, \`workbook-validation.json\` in the workbook output directory, and \`runtime-source-manifest.json\`: scope checks, formula tests and reproducibility references.

In Excel, yellow cells are proposed editable inputs. Activity baskets and income calculations respond to item/variant values. Recipe selection, derived item values and the Audit sheet are a **frozen snapshot**: changing an input does not rerun the recipe optimizer or rebuild audit flags. Rebuild the research to propagate alternative recipe choices. Sensitivity changes hold activity time and capital fixed; a doubled throughput may be physically impossible.

## Units and comparison targets

**VU** means research value unit. The workbook starts with 1 VU per Emerald solely as an illustrative denomination. **This is not a recommendation that 480 Emeralds per hour should be the intended income.** Changing the exchange scale changes nominal Emerald prices; it does not solve relative-value problems. The Emerald item follows that definition in the workbook. Rebuilding the recipe graph is needed to propagate currency changes into any recipe involving Emeralds.

The comparison target is 480 VU per active hour for an established setup, with explicit stage factors: Early 0.5×, Established 1×, Advanced 2×, Industrial 4×. These factors represent a hypothesis that investment should have a return; they are not approved progression gates or a required playstyle. The review band 0.67–1.5× is only a way to find mismatches, not a selected final tolerance.

Two measures are necessary:

1. **Net/world-hour:** revenue minus input opportunity value, wear, capital allowance and XP cost in one real elapsed hour of operation.
2. **Net/active-hour:** that net divided by the fraction of the hour spent actively operating, collecting or maintaining the setup.

An automated farm requiring ten active minutes is not six times faster in world time merely because its active-hour return is multiplied by six. Idle waiting, loaded chunks, server capacity and the possibility of running several farms concurrently remain separate constraints. Capital is charged as an explicit allowance over an assumed number of operating hours; it is not a measured depreciation law. Resale value, construction labour and location scarcity are not fully priced.

## How base values were derived

1. Read the official 1.21.11 item registry and all vanilla recipes. Apply current base-module resource filters and recipe overrides, then include Iota additions.
2. Resolve item-tag alternatives using official tags and current base overlays. The captured graph has zero unresolved ingredient tags. A validator independently reconstructs the effective recipe set and compares every definition.
3. Propose low-confidence acquisition anchors for items obtained through the world, entities, exploration or special systems. These anchors are explicit design inputs, not market observations.
4. Relax recipe routes toward the cheapest resolved input combination, plus stated active handling and fuel allowances. A more expensive alternative route does not raise the reference when a cheaper route exists.
5. Detect strongly connected single-input transformation groups and suppress intrinsic work premiums on reversible commodity conversions. Validate important Iota slab/stair, wool/string, leather/hide and ice round trips.
6. Supplement ordinary recipes with manual world transformations such as stripping, concrete hardening, bucket filling/capture and copper oxidation. Passive oxidation receives no automatic time premium. These transformations are incomplete and flagged as manual assumptions.

The graph contains 1,634 fixed-output routes and 30 dynamic/manual definitions. Dynamic crafting, copying, trimming and component-sensitive operations require separate rules. The single-input connectivity analysis and bounded recipe checks are **not a mathematical proof against every possible multi-input, loot or world-mechanic arbitrage cycle**.

Active-work allowances are 0.4 seconds per bulk crafting operation, six seconds per nonstackable craft, 0.15 seconds per stonecutting operation, 0.2 active seconds per smelted item, and ten seconds per smithing operation. Fuel allowance is 0.025 VU per smelt. These are deliberately exposed assumptions. Parallel furnace time is not charged as though the player personally works through every furnace tick. Recipe-grid steps alone do not earn a proportional markup.

Returned containers are credited where represented: bucket remainders for consumed milk/water/lava buckets, and glass bottles for consumed honey/dragon-breath containers. Filled containers, captured creatures, bees, map destinations, written contents and storage inventories need identity-aware rules. Their empty base ID is not a sufficient quote.

## Representative base references

Values below are rounded for reading; the workbook keeps more precision for arithmetic. Extra decimals do not imply measured certainty. Full equipment durability is assumed. Component premiums are additional.

| Item | Proposed VU | Selected basis / route | Scope |
|---|---:|---|---|
${itemTable}

The explicit original anchor and selected route are both retained. Leather begins with an acquisition anchor of 1 VU, but Iota's Rotten Flesh route lowers its selected reference to approximately 0.302 VU. String similarly drops from a 0.25 VU acquisition anchor to 0.125 VU through wool recovery. Ignoring those alternatives would overpay the same commodity depending on how it was produced.

## Representative crafting paths

${chains}

The selected ingredient alternative is a snapshot, not a requirement that a player must use that material. Raw input opportunity cost is charged even when the player collected it themselves. Otherwise gathering plus crafting would be credited twice and crafting would appear artificially profitable.

## Equipment, repairs and components

Equipment values include materials and proposed handling. Wear uses current Iota handheld durability where applicable; native durability is kept elsewhere. The activity model uses the cheaper provisional replacement/material-repair cost per durability point, **excluding repair XP, repair handling and partial-repair waste**. It is therefore an optimistic operating-cost estimate, not the final cost of maintaining a named enchanted tool.

Tools changes relevant here include wooden/stone recipe inputs, Stick/Flint repair ingredients, Netherite Scrap repair for managed Netherite tools, clearing prior-work penalties for the managed scope, and the reduced enchantment application costs. **A repair unit still restores the vanilla quarter-durability amount**, not a full repair. Armor, bows and other items must not silently inherit the managed-tool repair rules. Netherite remains a useful maintenance sensitivity case; Mending or reusable enchantment retention changes lifetime economics without changing the base crafting bill.

For an arbitrary enchanted item, start from the appropriate base equipment, then examine supported enchantments, actual levels, exclusivity and source costs. The sample book schedule doubles premiums per level as an initial hypothesis; it is not validated acquisition economics. Mending has a proposed 128 VU premium, Silk Touch 64 VU, and Efficiency/Unbreaking start at 8 VU. Curse premiums are zero in this first pass; no collector market is assumed. Seven equipment examples add an 8 VU application allowance. Multiple enchantments must not automatically add every premium if a cheaper combined-book or table route exists. Incompatible or unobtainable combinations are not valid ordinary market stock.

Potions use a manually reconstructed three-bottle brewing model, Blaze Powder fuel allocation, reagent cost and proposed handling. Luck variants remain unpriced. Potion effects, duration, strength, splash/lingering form and tipped-arrow output require component-aware matching. This supplement needs an in-game route audit; it is not extracted from the ordinary recipe registry.

Other required future valuation rules include contents of bundles/shulkers, written books, exploration maps, firework effects, trims, dyed items, banners, Ominous Bottle levels, bee contents, captured mobs and damaged equipment. Tool Mastery XP, history and player sentimental value are not fungible commodity premiums in this discovery. Free mastery rewards and the availability of discovered enchantments would need a separate optional-expansion scenario before applying these premiums to a world using those expansions.

## Activity comparisons

Every rate below is a **synthetic scenario**, including exceptionally high industrial throughput. These figures describe what the assumptions imply, not what was observed in a world. They assume all output finds a buyer at reference value. Actual market demand and available working capital can sharply reduce realizable income.

| Activity | Stage | Active min / world h | Net VU / world h | Net VU / active h | Active target ratio |
|---|---|---:|---:|---:|---:|
${activityTable}

### What these scenarios suggest

- Manual timber, mixed caving, established crops, shearing and tool assembly can be placed in the same broad range under the chosen assumptions. This is a promising calibration direction, not proof of comparable effort.
- Stone extraction has substantial wear under the iron-tool assumption. A player using Unbreaking, a different material or a more efficient mining pattern changes the comparison. Sand, foraging, ordinary fishing and archaeology need better yield/risk inputs before adjusting their prices.
- For example, at the conservative unmeasured scenarios of 3,000 Stone blocks/h and 4,500 Sand/h, the current 0.03125 VU terrain reference underpays gathering. Holding other terms fixed, the pressure calculation suggests roughly ${fmt(load('activity-price-pressure.json').find(x=>x.activity==='stone').unit_vu_for_active_target_holding_other_terms_fixed)} VU per Cobblestone and ${fmt(load('activity-price-pressure.json').find(x=>x.activity==='sand').unit_vu_for_active_target_holding_other_terms_fixed)} VU per Sand to meet the established target. Those are candidate revisions for audit, not changes silently propagated into building costs. Better equipment and different yields would change both candidates.
- Exploration has uneven and finite jackpots. Average income alone hides long empty stretches, travel time and the shrinking local supply of unopened structures. Map knowledge and rare discovery rewards may have value beyond resale; no probability distribution is established here.
- Simple smelting and redstone assembly have small margins per elapsed hour when material input is already valued. Reclassifying waiting time as active labour creates a misleading comparison; measure batch loading, collection and transport separately. High input-markup stress can wipe out these margins.
- Producing 600 Diamond Pickaxes per hour implies 1,800 Diamonds of hourly input and 600 buyers. This is an arithmetic capacity scenario, not a plausible baseline supply or demand claim. Nonstackable storage and selling time are material bottlenecks.
- Reversible building shapes cannot receive a guaranteed positive intrinsic markup in both directions. Preparing stairs may be useful work, but the same block cannot become more valuable on every cut/recovery loop. Any later service compensation would be a separate mechanism, not an approval in this matrix.
- Large iron/gold farms dominate both elapsed and active income under unlimited purchasing. Capital allowances alone do not remove this scaling advantage. Limiting how much one buyer absorbs may help, but adding more buyers can recreate scale; that policy belongs in a later market audit, not in this profession-free matrix.
- Regional scarcity and transport may support a logistics playstyle, but biome premiums without actual transport constraints can collapse under cheap teleportation. No distance premium or regional price system is selected here.

## Currency, conversion and arbitrage diagnostics

The first-pass whole-Emerald illustration finds **${denom.whole_emerald_rounding_poor_fit} base references** with more than 20% rounding distortion at the simple one-Emerald/one-item heuristic. Enumerating every valid item lot with a payment of at most 64 Emeralds reduces the unresolved rounding cases to **${denom.rounding_poor_after_all_valid_lots} references**. Separately, **${denom.single_emerald_stack_exceeded} references** cost more than a single 64-Emerald payment stack. The optimized lot columns are a frozen snapshot, whereas the simple quote formulas recalculate in Excel. This does not mean every reference should become a trade, or that a one-stack failure is impossible with multiple payment slots or another denomination. Cheap nonstackables and high-priced treasures need deliberate lot/denomination handling. Two item-payment slots do not provide arbitrary fractional change.

The +15% input-price stress is a diagnostic, **not an approved trading spread**. A market would eventually need separate purchase and sale prices; otherwise any two-way commodity conversion can become free credit or an exploit after integer rounding. Test both directions and all cross-market loops after actual offers exist.

Important checked relationships:

- 1 Blue Ice = 9 Packed Ice = 81 Ice, with equal recoverable material reference value.
- 2 matching slabs or stairs recover their parent block without increasing reference value.
- Wool/String and Leather/Rabbit Hide conversions do not gain value on a round trip.
- The selected route for every priced fixed-output recipe is bounded by selected inputs plus the stated processing/fuel allowance. The audit currently has zero such arithmetic inconsistencies.

Piglin barter is also a source of multiple commodities. The official captured weighted table produces a model expected basket of **${fmt(barter.expected_vu)} VU** per Gold Ingot valued at **${fmt(barter.gold_input_vu)} VU**. The book/boot enchantment-level premium mixture is assumed uniform and has not been independently verified. Travel, safety, equipment and market absorption are omitted. This is an expected-value diagnostic, **not a confirmed profitable guaranteed loop**. Its sensitivity to enchantment premiums shows why isolated commodity prices are insufficient.

Further loops still require explicit testing: Fortune/Silk Touch block conversion; breaking crafted ore/mineral blocks; composting and bone-meal plant growth; mob loot with Looting; fuel selection and Lava Buckets; furnace XP; fishing treasure; villager discounts/cure/reputation; renewable shulker shells; raid output; duplication/copying special recipes; book combining; grindstone XP; enchantment-table outcomes; trial/vault restrictions and optional expansions. Renewable labels are coarse source notes, not a rigorously proven classification of every renewable path. For example, global accessibility through wandering trades is not the same thing as convenient local bulk production.

## World and Hearts interactions

World changes the sky clock, with one real hour each for day and night. **Do not multiply all crop or furnace rates by six:** random ticks and furnace ticks are separate from the visible day cycle. Villager work schedules, daily restock caps and daylight-dependent operations can be affected differently. The interaction between the prolonged cycle and trading restocking remains an explicit in-game measurement requirement.

Sleep skips clock time and clears weather; it does not mean the skipped hours automatically produce crops or items. Hearts' 25% XP death escrow is not a guaranteed permanent 25% loss on every expedition: recoverable XP remains recoverable until forfeited under its actual rules. Expected XP loss, detours and reduced maximum health are separate risk costs. None is silently included as a flat commodity surcharge.

## Next audit sequence

1. **Confirm scope and scale.** Audit the technical exclusions, component categories, VU denomination and the intended meaning of comparable income. Keep profession offers unchanged during this step.
2. **Measure five contrasting baselines.** Timber, mixed mining, crops, simple manufacturing and a modest automated farm; then add exploration and a large farm. Use the same real-time basis and record equipment, enchantments, Fortune/Silk, difficulty, seed/biome and loaded-chunk conditions.
3. **Separate setup and operation.** Record build/travel time, capital consumed, reusable capital, active operation, waiting, tool wear, food, fuel, XP and net output. Record unsold output rather than pretending everything was purchased.
4. **Repeat, then revise.** At least three sessions per benchmark, retaining all raw observations and median/range rather than only the best run. No fixed precision or confidence interval should be claimed before those observations exist.
5. **Audit transformations.** Expand world/loot/brewing/component routes, then run integer buy/sell-cycle checks with candidate spreads and demand. Re-audit optional-expansion scenarios separately.
6. **Only then map to professions.** Keep thematic eligible bands separate from individual RNG outcomes. This economic discovery does not override the approved Toolsmith design or its tier-coherence rule.

Recommended measurement record: session ID, real start/end, active seconds, game ticks/TPS, module set, location/route, equipment/components, start/end XP points, inputs consumed, outputs obtained, items unsold, durability spent, setup costs, travel, failures/deaths and observations. See \`benchmark-session-template.csv\`.

## Reproduction and checks

From the project root, use the existing Node runtime; no installation is required:

\`node docs/discovery/research/outputs/trading_economy-discovery-2026-11-19/build-discovery.mjs\`

\`node docs/discovery/research/outputs/trading_economy-discovery-2026-11-19/analyse-discovery.mjs\`

\`node docs/discovery/research/outputs/trading_economy-discovery-2026-11-19/validate-and-stress.mjs\`

\`node docs/discovery/research/outputs/trading_economy-discovery-2026-11-19/index-loot-sources.mjs\`

\`node docs/discovery/research/outputs/trading_economy-discovery-2026-11-19/write-report.mjs\`

The source capture \`effective-recipes-raw.json\` is frozen. The validator independently compares it against current source resources and will fail if they differ; refresh the capture before applying this model to a later Iota version. Rebuilding the workbook additionally requires the bundled spreadsheet runtime used in this session; no package installation was performed. Its local dependency junction is an environment detail, not included in the portable data package.

Automated checks cover exact item/recipe reconciliation, positive finite proposed prices, explicit null exclusions, ingredient tags, recipe cost bounds, activity accounting, key recovery loops and denomination checks. The workbook is recalculated; a test changes Iron Ingot value by 1 VU and checks the resulting 2,400 VU shift in the 2,400-ingot processing scenario, then restores it. Formula-error scanning and visual previews cover every sheet. A separate standard-library XLSX validator checks every exported item price/stack, activity net/ratio, sensitivity case, price-pressure result and simple/optimized quote against the model, and scans all sheets for cached Excel errors. These checks do not replace in-game measurements or prove final economy balance. No Minecraft loading test was run for this research.

## Sources

Primary data is the official generated 1.21.11 registry, recipes, item tags, enchantment definitions and Piglin barter loot table already available in the project, overlaid with current Iota base source. Hashes are recorded in \`summary.json\` and \`runtime-source-manifest.json\`. These define source contents, not empirical profitability.

- [Official Java 1.21.11 release notes](https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21-11): version boundary and technical context.
- [Official Java 1.21 release notes](https://www.minecraft.net/en-us/article/minecraft-java-edition-1-21): data-driven enchantment availability/exclusivity and component-aware source context.
- [Official 1.20.2 pre-release experiment notes](https://www.minecraft.net/en-us/article/minecraft-1-20-2-pre-release-1): experimental trading/loot alternatives are opt-in context, not assumed active in the captured base recipe graph.

No web source is used as evidence for the hypothetical item prices or hourly output rates.

## Group coverage appendix

These are descriptive buckets for sorting research, not approved modules or villager professions. Min/max values include only priced base IDs; specialized components are separate. Coarse groups and renewable labels need manual cleanup as the model matures.

| Group | Registry IDs | Priced IDs | Minimum VU | Maximum VU |
|---|---:|---:|---:|---:|
${groupTable}
`;
fs.writeFileSync(path.join(work,'trading_readme.md'),text);
fs.writeFileSync(path.join(work,'benchmark-session-template.csv'),'session_id,activity_id,modules,equipment_and_enchantments,biome_seed_route,start_time,end_time,elapsed_seconds,active_seconds,tps,setup_seconds,setup_material_vu,input_items,output_items,unsold_items,durability_spent,xp_points_spent,food_fuel,travel_seconds,deaths_failures,notes\n');
console.log('Wrote research README and benchmark template');
