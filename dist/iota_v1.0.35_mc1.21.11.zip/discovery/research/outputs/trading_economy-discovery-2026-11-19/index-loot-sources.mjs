import fs from 'node:fs';
import path from 'node:path';
const work=import.meta.dirname,root=path.resolve(work,'../../../../..');
const walk=d=>fs.existsSync(d)?fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]):[];
const read=n=>JSON.parse(fs.readFileSync(path.join(work,n),'utf8'));
const save=(n,x)=>fs.writeFileSync(path.join(work,n),JSON.stringify(x,null,2)+'\n');
const csv=(n,rows)=>{const keys=Object.keys(rows[0]);const q=x=>'"'+String(x??'').replaceAll('"','""')+'"';fs.writeFileSync(path.join(work,n),keys.join(',')+'\n'+rows.map(r=>keys.map(k=>q(r[k])).join(',')).join('\n')+'\n');};
const tables=new Map();
for(const base of ['vendor/generated','modules/hands_off','modules/tools','modules/recipes','modules/drops','modules/world','modules/hearts'])for(const f of walk(path.join(root,base,'data'))){
 const rel=path.relative(path.join(root,base,'data'),f).replaceAll('\\','/'),m=rel.match(/^([^/]+)\/loot_table\/(.+)\.json$/);if(m)tables.set(m[1]+':'+m[2],{data:JSON.parse(fs.readFileSync(f)),source:base,relative:rel});
}
const exposures=[];
function category(id){const p=id.split(':')[1];if(p.startsWith('blocks/'))return 'block drops';if(p.startsWith('entities/'))return 'entity drops';if(p.startsWith('chests/'))return 'structure/chest loot';if(p.startsWith('archaeology/'))return 'archaeology';if(p.includes('fishing'))return 'fishing';if(p.includes('barter'))return 'bartering';if(p.includes('equipment/'))return 'equipment presets';if(p.includes('spawner'))return 'trial/spawner rewards';return 'other gameplay';}
function explore(node,context,seen=new Set()){
 if(!node||typeof node!=='object')return;
 const conditions=[...context.conditions,...(node.conditions||[])],functions=[...context.functions,...(node.functions||[])];
 if(node.type==='minecraft:item'&&node.name)exposures.push({item:node.name,table:context.table,category:category(context.table),origin:context.origin,entry_weight:node.weight??1,entry_quality:node.quality??0,conditions:JSON.stringify(conditions),functions:JSON.stringify(functions),reference_path:context.chain.join(' → '),note:'Structural occurrence only. Weight is local to its pool; conditions/alternatives/functions are not evaluated, and this is not an independent probability or hourly yield.'});
 if(node.type==='minecraft:loot_table'&&typeof node.value==='string'){
  const target=node.value;if(!seen.has(target)&&tables.has(target)){const next=new Set(seen);next.add(target);explore(tables.get(target).data,{...context,conditions,functions,chain:[...context.chain,target]},next);}
 }
 for(const [k,v]of Object.entries(node))if(k!=='functions'&&k!=='conditions'&&k!=='value'){
  if(Array.isArray(v)){for(const child of v)if(child&&typeof child==='object')explore(child,{...context,conditions,functions},seen);}
  else if(v&&typeof v==='object')explore(v,{...context,conditions,functions},seen);
 }
}
for(const [id,t]of tables)explore(t.data,{table:id,origin:t.source,conditions:[],functions:[],chain:[id]},new Set([id]));
const items=read('items.json');
const coverage=items.map(i=>{const rows=exposures.filter(e=>e.item===i.id),groups=[...new Set(rows.map(e=>e.category))],sourceTables=[...new Set(rows.map(e=>e.table))];return {id:i.id,group:i.group,base_reference_vu:i.value_vu,source_category_count:groups.length,source_categories:groups.join('; '),loot_table_count:sourceTables.length,example_tables:sourceTables.slice(0,10).join('; '),source_route:i.source_route,note:rows.length?'Source occurrences are conditional, not measured acquisition rates; recipes, growing, capture and native villager offers are separate systems.':'No direct item loot occurrence indexed; not proof of unobtainability. Crafting, growing, native trades, capture, shearing, interaction and implicit item drops may supply it.'};});
save('loot-source-occurrences.json',exposures);csv('loot-source-occurrences.csv',exposures);save('item-source-coverage.json',coverage);csv('item-source-coverage.csv',coverage);
const result={effectiveLootTables:tables.size,occurrences:exposures.length,itemsWithLootOccurrence:coverage.filter(x=>x.loot_table_count>0).length,itemsWithoutDirectLootOccurrence:coverage.filter(x=>x.loot_table_count===0).length,categories:[...new Set(exposures.map(e=>e.category))].map(c=>({category:c,occurrences:exposures.filter(e=>e.category===c).length})),limits:'Structural supply index, not a loot simulator. No rates or unconditional probabilities are inferred from local weights. Native villager offers and non-loot world interactions are not indexed.'};
save('loot-source-summary.json',result);console.log(JSON.stringify(result));
