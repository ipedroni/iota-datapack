import assert from 'node:assert/strict';

// Ordinary purchases aim at 95% of reference value. Whole-block rounding may
// move above that target, but never above the reference-value margin guard.
// Retail encoding remains at/above 105% of reference, so this guard preserves
// a positive ordinary bid/ask spread before regional import exceptions.
export function nearestBlockPayout(target, referenceCap=target/.95){
 assert(Number.isFinite(target)&&target>64);
 assert(Number.isFinite(referenceCap)&&referenceCap>=1);
 const candidates=[...new Set([Math.floor(target/9),Math.ceil(target/9)])]
  .filter(n=>n>=1&&n<=64&&9*n<=referenceCap+1e-8)
  .sort((a,b)=>Math.abs(9*a-target)-Math.abs(9*b-target)||a-b);
 assert(candidates.length,'No safe representable block payout; change the lot/denomination explicitly.');
 return {emeralds:9*candidates[0],id:'minecraft:emerald_block',count:candidates[0]};
}
