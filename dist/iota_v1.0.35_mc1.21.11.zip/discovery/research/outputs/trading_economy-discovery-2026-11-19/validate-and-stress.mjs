import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const work=import.meta.dirname,root=path.resolve(work,'../../../../..');
const read=n=>JSON.parse(fs.readFileSync(path.join(work,n),'utf8'));
const save=(n,x)=>fs.writeFileSync(path.join(work,n),JSON.stringify(x,null,2)+'\n');
const csv=(n,rows)=>{const keys=Object.keys(rows[0]);const q=x=>'"'+String(x??'').replaceAll('"','""')+'"';fs.writeFileSync(path.join(work,n),keys.join(',')+'\n'+rows.map(r=>keys.map(k=>q(r[k])).join(',')).join('\n')+'\n');};
const walk=d=>fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]).sort();
const hash=f=>crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const registry=JSON.parse(fs.readFileSync(path.join(root,'vendor/generated/reports/items.json')));
const items=read('items.json'),recipes=read('recipes.json'),raw=read('effective-recipes-raw.json'),activities=read('activities.json'),variants=read('component-variants.json'),baskets=read('activity-baskets.json'),settings=read('assumptions.json');
const checks=[];const check=(label,fn)=>{fn();checks.push({label,result:'PASS'});};
check('Every official item ID appears exactly once',()=>assert.deepEqual(items.map(x=>x.id).sort(),Object.keys(registry).sort()));
check('All proposed prices are finite and positive; exclusions remain null',()=>{for(const i of items)assert(i.status==='excluded'?i.value_vu===null:Number.isFinite(i.value_vu)&&i.value_vu>0,i.id);});
check('Every effective recipe is represented exactly once',()=>assert.deepEqual(recipes.map(x=>x.id).sort(),Object.keys(raw).sort()));
// Reconstruct the effective graph independently from the generated vanilla data and pack overlays.
const effective=new Map();const addTree=(base,filters=[])=>{for(const f of walk(base)){const rel=path.relative(base,f).replaceAll('\\','/');const m=rel.match(/^([^/]+)\/recipe\/(.+)\.json$/);if(!m)continue;if(filters.some(b=>new RegExp(b.namespace??'.*').test(m[1])&&new RegExp(b.path??'.*').test('recipe/'+m[2]+'.json')))continue;effective.set(m[1]+':'+m[2],JSON.parse(fs.readFileSync(f)));}};
const moduleNames=['hands_off','tools','recipes','drops','world','hearts'];
const allFilters=moduleNames.flatMap(n=>JSON.parse(fs.readFileSync(path.join(root,'modules',n,'pack.mcmeta'))).filter?.block??[]);
addTree(path.join(root,'vendor/generated/data'),allFilters);
for(const n of moduleNames)addTree(path.join(root,'modules',n,'data'));
check('Independent source reconstruction matches all effective recipe definitions',()=>assert.deepEqual(Object.fromEntries([...effective].sort(([a],[b])=>a.localeCompare(b))),raw));
check('No unresolved ingredient tags',()=>assert.equal(read('summary.json').unresolvedTags.length,0));
check('All priced fixed recipes respect their stated input, fuel and service bound',()=>{for(const r of recipes.filter(r=>r.status==='fixed'&&r.output_value_vu!==null&&r.input_value_vu!==null))assert(r.output_value_vu<=r.input_value_vu+r.processing_value_vu+r.fuel_value_vu+1e-5,r.id);});
check('Every activity basket references an explicitly priced item or variant',()=>{const prices=new Map([...items,...variants].map(x=>[x.id,x.value_vu]));for(const b of baskets)assert(Number.isFinite(prices.get(b.item)),b.item);});
check('Activities reconcile revenue, opportunity inputs, wear, capital and XP',()=>{for(const a of activities){const sum=side=>baskets.filter(b=>b.activity===a.id&&b.side===side).reduce((s,b)=>s+b.total_vu,0);assert(Math.abs(sum('output')-a.revenue_vu_per_hour)<1e-6,a.id);assert(Math.abs(a.net_vu_per_world_hour-(sum('output')-sum('input')-a.wear_vu_per_hour-a.capital_charge_vu_per_hour-a.xp_opportunity_vu_per_hour))<1e-6,a.id);assert(a.active_minutes_per_world_hour>0&&a.active_minutes_per_world_hour<=60,a.id);}});
const price=n=>items.find(i=>i.id==='minecraft:'+n).value_vu;
check('Ice compression/reclaiming conserves reference value',()=>{assert(Math.abs(price('packed_ice')-9*price('ice'))<1e-5);assert(Math.abs(price('blue_ice')-81*price('ice'))<1e-5);});
check('Wool/string and leather/hide round trips conserve reference value',()=>{assert(Math.abs(price('white_wool')-4*price('string'))<1e-5);assert(Math.abs(price('leather')-4*price('rabbit_hide'))<1e-5);});
check('Iota slabs and stairs conserve reference value against their parent block',()=>{for(const r of recipes.filter(r=>r.reversible&&r.count===2&&r.slots.length===1&&/(?:_slab|_stairs)$/.test(r.output))){const input=r.chosen_inputs?.[0],iv=items.find(i=>i.id===input)?.value_vu,ov=items.find(i=>i.id===r.output)?.value_vu;if(iv!==null&&ov!==null)assert(Math.abs(iv-2*ov)<1e-5,r.id);}});
// This is a transparent stress grid, not a probability distribution or confidence interval.
const stress=[];
for(const a of activities)for(const throughput of [.5,1,2])for(const marketPrice of [.75,1,1.25]){
 const revenue=a.revenue_vu_per_hour*throughput*marketPrice;
 const variable=(a.input_vu_per_hour+a.wear_vu_per_hour)*throughput*marketPrice+a.xp_opportunity_vu_per_hour*throughput;
 const capital=a.capital_charge_vu_per_hour;
 const net=revenue-variable-capital;
 stress.push({activity:a.id,throughput_multiplier:throughput,common_price_multiplier:marketPrice,active_minutes_held_fixed:a.active_minutes_per_world_hour,net_vu_world_hour:net,net_vu_active_hour:net*60/a.active_minutes_per_world_hour,ratio_active:net*60/a.active_minutes_per_world_hour/a.stage_target_vu_per_hour,note:'Mechanical stress only: identical time/capital held fixed while output and consumables scale; extreme points may be physically infeasible. Not a confidence interval.'});
}
save('sensitivity.json',stress);csv('sensitivity.csv',stress);
const summaries=activities.map(a=>{const rows=stress.filter(s=>s.activity===a.id);return {activity:a.id,baseline_net_world:a.net_vu_per_world_hour,baseline_net_active:a.net_vu_per_active_hour,min_stress_net_world:Math.min(...rows.map(r=>r.net_vu_world_hour)),max_stress_net_world:Math.max(...rows.map(r=>r.net_vu_world_hour)),baseline_ratio_active:a.relative_active_to_stage_target,baseline_ratio_world:a.relative_to_stage_target,retail_input_stress_net_world:a.retail_input_stress_net_vu,working_inputs_vu_world_hour:a.input_vu_per_hour,output_units_world_hour:baskets.filter(b=>b.activity===a.id&&b.side==='output').reduce((s,b)=>s+b.quantity_per_world_hour,0)};});
save('sensitivity-summary.json',summaries);csv('sensitivity-summary.csv',summaries);
const pressure=activities.map(a=>{
 const outputs=baskets.filter(b=>b.activity===a.id&&b.side==='output'),primary=outputs[0];
 const other=a.revenue_vu_per_hour-primary.total_vu;
 const target=a.stage_target_vu_per_hour*a.active_minutes_per_world_hour/60;
 const required=(target+a.input_vu_per_hour+a.wear_vu_per_hour+a.capital_charge_vu_per_hour+a.xp_opportunity_vu_per_hour-other)/primary.quantity_per_world_hour;
 return {activity:a.id,primary_output:primary.item,current_unit_vu:primary.unit_vu,output_quantity_world_hour:primary.quantity_per_world_hour,unit_vu_for_active_target_holding_other_terms_fixed:required,unit_multiplier:required/primary.unit_vu,active_target_world_equivalent_vu:target,note:'First-order diagnostic, not an approved price. Holds other outputs, input prices, wear, capital, rates and demand fixed. Linked recipe values must be rebuilt before adopting any change; negative values indicate other outputs already cover the target.'};
});
save('activity-price-pressure.json',pressure);csv('activity-price-pressure.csv',pressure);
const quotes=read('integer-quotes.json').map(q=>{
 const i=items.find(i=>i.id===q.id),unit=q.unit_vu/settings.vuPerEmerald;
 let best=null;
 for(let lot=1;lot<=i.stack;lot++){
  const coins=Math.max(1,Math.round(lot*unit));if(coins>64)continue;
  const error=coins/(lot*unit)-1;
  if(!best||Math.abs(error)<Math.abs(best.error)-1e-10)best={lot,coins,error};
 }
 return {...q,single_emerald_stack_exceeded:q.emerald_amount>64,best_single_stack_lot:best?.lot??null,best_single_stack_emerald_amount:best?.coins??null,best_single_stack_rounding_error:best?.error??null,best_single_stack_status:!best?'No one-stack Emerald payment':Math.abs(best.error)>.2?'More than 20% distortion remains':'Fits within 20% using an audited lot'};
});
save('integer-quotes.json',quotes);csv('integer-quotes.csv',quotes);
const expensive=quotes.filter(q=>q.single_emerald_stack_exceeded);
save('denomination-audit.json',{whole_emerald_rounding_poor_fit:quotes.filter(q=>q.status.startsWith('Poor')).length,single_emerald_stack_exceeded:expensive.length,rounding_poor_after_all_valid_lots:quotes.filter(q=>q.best_single_stack_status.startsWith('More')).length,items:expensive.map(q=>({id:q.id,emerald_amount:q.emerald_amount})),note:'The first heuristic uses one Emerald or one item; some distortions disappear with another lot. All valid item lots are separately enumerated with at most 64 Emeralds. More than 64 Emeralds cannot fit one payment slot. Two payment slots or a different denomination are separate future design decisions; this is not a configured trade.'});
const sourceFiles=moduleNames.flatMap(n=>walk(path.join(root,'modules',n))).concat(walk(path.join(root,'modules/expansions/tool_mastery')),walk(path.join(root,'modules/expansions/magical_discovery')));
save('runtime-source-manifest.json',{created:'2026-11-19',files:sourceFiles.map(f=>({path:path.relative(root,f).replaceAll('\\','/'),sha256:hash(f)})),note:'Snapshot of current base and frozen expansion sources; research does not edit these files. This is a reproducibility manifest, not a historical before/after Git proof.'});
save('validation.json',{checks,counts:{items:items.length,recipes:recipes.length,activities:activities.length,sensitivityCases:stress.length,expensiveQuotes:expensive.length},limits:'No Minecraft launch or measured throughput test was performed. Not a complete arbitrage proof over world mechanics or all component combinations.'});
console.log(JSON.stringify({checks:checks.length,passed:true,sensitivityCases:stress.length,expensiveQuotes:expensive.length}));
