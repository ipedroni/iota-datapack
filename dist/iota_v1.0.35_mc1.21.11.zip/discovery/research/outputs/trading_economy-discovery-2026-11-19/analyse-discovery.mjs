import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'../../../../..'),work=import.meta.dirname;
const load=n=>JSON.parse(fs.readFileSync(path.join(work,n)));
const save=(n,x)=>fs.writeFileSync(path.join(work,n),JSON.stringify(x,null,2)+'\n');
const items=load('items.json'),recipes=load('recipes.json'),settings=load('assumptions.json'),enchants=load('enchantments.json');
const prices=new Map(items.map(i=>[i.id,i.value_vu]));
const item=n=>items.find(i=>i.id==='minecraft:'+n);
const price=n=>{const key=n.includes(':')?n:'minecraft:'+n;const v=prices.get(key);if(!Number.isFinite(v))throw Error('Missing value '+key);return v;};
const csv=(name,rows)=>{const keys=Object.keys(rows[0]||{}),q=x=>x===null||x===undefined?'':'"'+(typeof x==='object'?JSON.stringify(x):String(x)).replaceAll('"','""')+'"';fs.writeFileSync(path.join(work,name),keys.join(',')+'\n'+rows.map(r=>keys.map(k=>q(r[k])).join(',')).join('\n')+'\n');};

// Component variants: brewing is not represented by ordinary crafting recipes.
const registry=JSON.parse(fs.readFileSync(path.join(root,'vendor/generated/reports/registries.json')));
const variants=[];const potionValues=new Map();
const glass=price('glass_bottle'),fuelPerBottle=price('blaze_powder')/20/3,brewWork=2/3*settings.targetActiveVUPerHour/3600;
potionValues.set('water',glass+0.02);
const potionRecipe={awkward:['water','nether_wart'],mundane:['water','redstone'],thick:['water','glowstone_dust'],weakness:['water','fermented_spider_eye'],fire_resistance:['awkward','magma_cream'],healing:['awkward','glistering_melon_slice'],leaping:['awkward','rabbit_foot'],night_vision:['awkward','golden_carrot'],poison:['awkward','spider_eye'],regeneration:['awkward','ghast_tear'],slow_falling:['awkward','phantom_membrane'],strength:['awkward','blaze_powder'],swiftness:['awkward','sugar'],turtle_master:['awkward','turtle_helmet'],water_breathing:['awkward','pufferfish'],infested:['awkward','stone'],oozing:['awkward','slime_block'],weaving:['awkward','cobweb'],wind_charged:['awkward','breeze_rod'],harming:['healing','fermented_spider_eye'],invisibility:['night_vision','fermented_spider_eye'],slowness:['swiftness','fermented_spider_eye']};
for(let pass=0;pass<5;pass++)for(const [name,[base,reagent]]of Object.entries(potionRecipe))if(potionValues.has(base))potionValues.set(name,potionValues.get(base)+price(reagent)/3+fuelPerBottle+brewWork);
for(const id of Object.keys(registry['minecraft:potion'].entries)){
 const n=id.slice(10);if(n.startsWith('long_')){const base=n.slice(5);if(potionValues.has(base))potionValues.set(n,potionValues.get(base)+price('redstone')/3+fuelPerBottle+brewWork);}
 if(n.startsWith('strong_')){const base=n.slice(7);if(potionValues.has(base))potionValues.set(n,potionValues.get(base)+price('glowstone_dust')/3+fuelPerBottle+brewWork);}
}
for(const id of Object.keys(registry['minecraft:potion'].entries)){
 const n=id.slice(10),v=potionValues.get(n);
 for(const form of ['potion','splash_potion','lingering_potion','tipped_arrow']){
  const val=v===undefined?null:form==='potion'?v:form==='splash_potion'?v+price('gunpowder')/3+fuelPerBottle+brewWork:form==='lingering_potion'?v+price('gunpowder')/3+(price('dragon_breath')-glass)/3+2*(fuelPerBottle+brewWork):(8*price('arrow')+v+price('gunpowder')/3+(price('dragon_breath')-glass)/3+2*(fuelPerBottle+brewWork))/8;
  const key='minecraft:'+form+'|'+n;prices.set(key,val);
  variants.push({id:key,base_item:'minecraft:'+form,variant:id,kind:'potion/effect',value_vu:val,source:'Supplemental manual brewing model; three-bottle batches; not ordinary recipe JSON',confidence:'Low',note:val===null?'No ordinary Survival brewing route selected (Luck); not a market quote':'Per-bottle input allocation; brew handling/XP/fuel assumptions require in-game audit; tipped-arrow container return conservatively not credited'});
 }
}
for(const e of enchants){const key='minecraft:enchanted_book|'+e.id+'|'+e.level;prices.set(key,e.book_total_vu);variants.push({id:key,base_item:'minecraft:enchanted_book',variant:e.id+' '+e.level,kind:e.curse?'curse book':'enchanted book',value_vu:e.book_total_vu,source:'Vanilla enchantment max levels; proposed acquisition premiums',confidence:'Low',note:e.note});}
const applied=[['iron_pickaxe','efficiency',1],['iron_pickaxe','efficiency',2],['iron_pickaxe','efficiency',3],['diamond_pickaxe','efficiency',3],['diamond_pickaxe','efficiency',5],['diamond_pickaxe','mending',1],['netherite_pickaxe','mending',1]];
for(const [base,ench,level]of applied){const e=enchants.find(e=>e.id==='minecraft:'+ench&&e.level===level);const key='minecraft:'+base+'|'+ench+'|'+level;const val=price(base)+e.premium_vu+settings.enchantApplicationServiceVU;prices.set(key,val);variants.push({id:key,base_item:'minecraft:'+base,variant:e.id+' '+level,kind:'enchanted equipment',value_vu:val,source:'Full item + component premium + 8 VU application-service allowance',confidence:'Low',note:'Illustrative equipment variant. Service allowance may underpay actual book/XP labour; see activity model. Not a selected NPC offer.'});}
save('component-variants.json',variants);csv('component-variants.csv',variants);

const activities=[],basket=[];
const stages={Early:0.5,Established:1,Advanced:2,Industrial:4};
function add(id,name,stage,mode,active,capital,amort,outputs,inputs={},wear=null,note=''){
 const r={id,name,stage,mode,active_minutes_per_world_hour:active,capital_vu:capital,amortization_hours:amort,stage_target_multiplier:stages[stage],rates_basis:'Illustrative assumption, not in-game measurement',note};
 let revenue=0,cost=0;
 for(const [side,entries]of [['output',outputs],['input',inputs]])for(const [key,q]of Object.entries(entries)){const p=price(key),value=q*p;basket.push({activity:id,side,item:key.includes(':')?key:'minecraft:'+key,quantity_per_world_hour:q,unit_vu:p,total_vu:value});if(side==='output')revenue+=value;else cost+=value;}
 const wearCost=wear?Math.min(item(wear[0]).replacement_vu_per_durability,item(wear[0]).repair_vu_per_durability??Infinity)*wear[1]:0;
 const xpPoints=id==='book_application'?18000:0,xpCost=xpPoints*settings.xpPointReferenceVU;const depreciation=capital/amort,net=revenue-cost-wearCost-depreciation-xpCost,target=settings.targetActiveVUPerHour*r.stage_target_multiplier;
 Object.assign(r,{xp_points_per_hour:xpPoints,xp_opportunity_vu_per_hour:xpCost,wear_item:wear?.[0]??null,wear_points_per_world_hour:wear?.[1]??0,wear_vu_per_hour:wearCost,revenue_vu_per_hour:revenue,input_vu_per_hour:cost,capital_charge_vu_per_hour:depreciation,net_vu_per_world_hour:net,net_emerald_per_world_hour:net/settings.vuPerEmerald,net_vu_per_active_hour:net*60/active,stage_target_vu_per_hour:target,relative_to_stage_target:net/target,relative_active_to_stage_target:net*60/active/target,price_multiplier_for_target:revenue>0?(target+cost+wearCost+depreciation+xpCost)/revenue:null,retail_input_stress_net_vu:revenue-cost*settings.retailStressMultiplier-wearCost-depreciation-xpCost});activities.push(r);
}
add('timber','Manual timber and replanting','Established','active',60,120,50,{oak_log:1800,oak_sapling:32},{bread:4},['iron_axe',1800],'Session yield includes travel/replanting by assumption; species/forest conditions require measurement');
add('stone','Stone mining with iron equipment','Established','active',60,160,60,{cobblestone:3000,flint:75},{bread:6},['iron_pickaxe',3000],'Flint output is the exact Iota 2.5% expectation conditional on eligible mining; 3000 blocks/h is an unmeasured conservative illustration, not an instant-mining setup');
add('sand','Sand extraction','Established','active',60,80,60,{sand:4500},{bread:4},['iron_shovel',4500],'4500 blocks/h is an unmeasured illustration; equipment, collection and travel require benchmark validation');
add('mixed_caving','Mixed ore caving','Established','active',60,400,80,{raw_iron:180,raw_copper:128,coal:128},{bread:6,torch:32},['iron_pickaxe',1200]);
add('iron_mining','Iron-focused mining and smelting','Established','active',60,400,80,{iron_ingot:240},{bamboo:960,bread:6},['iron_pickaxe',1800],'Mining input ore is gathered in this activity, not purchased; iron output includes smelting');
add('diamond_mining','Diamond expedition with developed equipment','Advanced','active',60,1000,100,{diamond:48,redstone:256,raw_gold:32},{bread:8,torch:32},['diamond_pickaxe',2400],'Diamond output rate is an unmeasured scenario, not an ore-generation estimate');
add('debris','Ancient Debris expedition','Advanced','active',60,1800,120,{ancient_debris:12},{bread:8,torch:32},['diamond_pickaxe',4000],'No beds/TNT included: a digging scenario; explosion routes have different costs');
add('quartz','Nether quartz gathering','Established','active',60,600,100,{quartz:960},{bread:6},['iron_pickaxe',960]);
add('foraging','Grass and flower foraging','Early','active',60,40,50,{wheat_seeds:800,flint:100,string:100,poppy:128},{bread:4},null,'Grass expectations use Iota base chances: 8% seeds, 1% Flint, 1% String for 10,000 eligible breaks; collection/flower rate assumed');
add('wheat','Established wheat agriculture','Established','active',60,320,80,{wheat:3840,wheat_seeds:960},{bread:4},null,'Seeds are net surplus after replanting; crop rates are synthetic, not growth measurements');
add('carrots','Established carrot agriculture','Established','active',60,320,80,{carrot:7680},{bread:4},null,'Output is net retained produce after reserving replanting stock; rates are synthetic');
add('potatoes','Established potato agriculture','Established','active',60,320,80,{potato:7680,poisonous_potato:32},{bread:4},null,'Output is net retained produce after reserving replanting stock; rates are synthetic');
add('cocoa','Cocoa production','Established','active',60,240,80,{cocoa_beans:3840},{bread:4});
add('sugar_cane','Sugar cane collection','Established','active',60,320,80,{sugar_cane:7680},{bread:4});
add('shearing','Wool production and shearing','Established','active',60,640,100,{white_wool:960},{wheat:64,bread:4},null,'Shears wear is not modeled as pickaxe wear; animal management rates need measurement');
add('hunting','Animal-food production','Established','active',60,640,100,{beef:320,leather:96},{wheat:256,bread:4},null,'Animal breeding/maturation, shelter and weapon wear not fully measured; scenario is provisional');
add('fishing','Manual fishing with ordinary equipment','Early','active',60,160,80,{cod:96,salmon:48,pufferfish:8,tropical_fish:4,nautilus_shell:1},{bread:4},null,'Partial illustrative basket: treasure enchantment components and fishing-rod wear omitted; total expected fishing income is not established');
add('archaeology','Archaeology expedition','Established','active',60,640,80,{angler_pottery_sherd:32,emerald:16,sniffer_egg:0.25},{brush:2,bread:6},null,'Assumed session basket; non-renewable site depletion and find time must be measured');
add('ancient_city','Ancient City loot expedition','Advanced','active',60,1600,100,{echo_shard:16,enchanted_golden_apple:0.5,disc_fragment_5:8,redstone:512},{bread:8,torch:32},null,'Assumed mixed session basket; not expected value per city/chest');
add('end_exploration','End exploration','Advanced','active',60,2400,120,{elytra:2,shulker_shell:16,diamond:8},{bread:8,firework_rocket:64},null,'Assumed session basket; flight-rocket variant and existing flight capital need audit');
add('trials','Trial exploration and rewards','Advanced','active',60,2000,100,{heavy_core:1,breeze_rod:64,diamond:8},{bread:8},null,'Assumed session basket; vault reward access is per player/site and not endlessly reset by new keys');
add('blaze','Blaze combat production','Established','active',60,800,100,{blaze_rod:128},{bread:6},null,'Combat armor/weapon risk allowances omitted; zero inventory loss assumed under Hearts');
add('mob_farm','Mixed mob farm','Advanced','automated',15,4000,160,{bone:1024,gunpowder:512,rotten_flesh:1024,string:256},{bread:2},null,'Assumed output basket; design, mobcap, biome and simulation distance are not fixed');
add('iron_farm','Established iron farm','Advanced','automated',10,4800,160,{iron_ingot:720,poppy:128},{bread:2},null,'Synthetic 720/h scenario; no farm design/rate has been verified');
add('large_iron_farm','Large iron infrastructure','Industrial','automated',10,24000,200,{iron_ingot:6000,poppy:1024},{bread:2},null,'Scaling stress case; not a measured or recommended farm');
add('gold_farm','Gold infrastructure','Industrial','automated',15,16000,200,{gold_nugget:12000,rotten_flesh:4096},{bread:2},null,'Synthetic scenario; world spawning windows are not modeled');
add('bamboo_farm','Bamboo infrastructure','Advanced','automated',10,3200,160,{bamboo:48000},{bread:2});
add('cane_farm','Sugar cane infrastructure','Advanced','automated',10,4800,160,{sugar_cane:16000},{bread:2});
add('gunpowder_farm','Gunpowder infrastructure','Industrial','automated',15,12000,200,{gunpowder:12000},{bread:2});
add('leather_alternative','Rotten Flesh leather processing','Established','processing',8,640,100,{leather:2400},{rotten_flesh:2400,bamboo:9600,bread:4},null,'Uses Iota smelting alternative; fuel rate is a discovery assumption');
add('glass_processing','Glass production','Established','processing',60,640,100,{glass:2400},{sand:2400,bamboo:9600,bread:4});
add('iron_processing','Raw Iron smelting service','Established','processing',60,640,100,{iron_ingot:2400},{raw_iron:2400,bamboo:9600,bread:4});
add('redstone_assembly','Repeater manufacturing','Established','manufacturing',8,800,100,{repeater:1200},{stone:3600,stick:2400,redstone:3600,bread:4},null,'Uses current Iota repeater recipe; raw inputs charged at reference value');
add('dispenser_assembly','Dispenser manufacturing','Established','manufacturing',4,800,100,{dispenser:600},{dropper:600,stick:1800,string:1800,bread:4});
add('iron_tools','Iron Pickaxe manufacturing','Established','manufacturing',60,800,100,{iron_pickaxe:600},{iron_ingot:1800,stick:1200,bread:4},null,'Nonstackable output handling is material to throughput');
add('diamond_tools','Diamond Pickaxe manufacturing','Established','manufacturing',60,2000,100,{diamond_pickaxe:600},{diamond:1800,stick:1200,bread:4},null,'Needs large working capital and a buyer; available supply/demand is not guaranteed');
add('wood_shapes','Wooden-stair preparation','Established','processing',10,320,100,{oak_stairs:12000},{oak_planks:6000,bread:4},null,'Lossless reclaiming prevents an intrinsic premium in both directions; service compensation would be separate');
add('potion_production','Fire Resistance brewing','Established','manufacturing',15,800,100,{'minecraft:potion|fire_resistance':600},{glass_bottle:600,nether_wart:200,magma_cream:200,blaze_powder:20,bread:4},null,'Three-bottle batches; water fill and handling allocation need audit');
add('book_application','Efficiency III book application','Established','manufacturing',25,800,100,{'minecraft:iron_pickaxe|efficiency|3':60},{iron_pickaxe:60,'minecraft:enchanted_book|minecraft:efficiency|3':60,bread:4},null,'Anvil XP: assumed 300 points per operation at 0.01 VU/point; exact cost depends on player level and operation');

save('activities.json',activities);save('activity-baskets.json',basket);csv('activities.csv',activities);csv('activity-baskets.csv',basket);

// Cost/route checks and fixed-denomination market-readiness diagnostics.
const quotes=items.filter(i=>i.value_vu!==null).map(i=>{
 const p=i.value_vu/settings.vuPerEmerald;
 const lot=p>=1?1:Math.min(i.stack,Math.ceil(1/p));
 const em=Math.max(1,Math.round(lot*p)),error=(em/(lot*p)-1);
 return {id:i.id,unit_vu:i.value_vu,lot,emerald_amount:em,rounding_error:error,status:Math.abs(error)>0.2?'Poor fit for whole-emerald item slot':i.component_sensitive?'Needs component quote':'Illustrative integer lot',note:'A reference quote is not approval to trade every item; one input slot cannot exceed max stack.'};
});
save('integer-quotes.json',quotes);csv('integer-quotes.csv',quotes);
const audits=[];
for(const r of recipes){
 if(r.status!=='fixed'){audits.push({severity:'manual',kind:'dynamic recipe',id:r.id,detail:r.note});continue;}
 if(r.input_value_vu===null||r.output_value_vu===null)audits.push({severity:'review',kind:'unvalued fixed route',id:r.id,detail:'Technical/unobtainable ingredient or output; do not silently assign zero'});
 const excess=r.net_transform_vu-r.processing_value_vu-r.fuel_value_vu;
 if(Number.isFinite(excess)&&excess>0.00001)audits.push({severity:'error',kind:'recipe cost inconsistency',id:r.id,detail:'Output exceeds resolved inputs plus stated service/fuel',amount:excess});
 if(Number.isFinite(r.net_transform_vu)&&r.net_transform_vu<-.5)audits.push({severity:'review',kind:'cheaper alternative or value loss',id:r.id,detail:'This route destroys reference value relative to a cheaper source; not automatically a bug',amount:r.net_transform_vu});
}
for(const a of activities)if(a.relative_to_stage_target<.67||a.relative_to_stage_target>1.5)audits.push({severity:'review',kind:'activity target gap',id:a.id,detail:a.note||'Benchmark throughput and values are proposed assumptions',amount:a.relative_to_stage_target});
for(const q of quotes)if(q.status.startsWith('Poor'))audits.push({severity:'review',kind:'currency granularity',id:q.id,detail:q.note,amount:q.rounding_error});
// Bartering: evaluate weighted raw outputs; preserve random component premiums.
const barter=JSON.parse(fs.readFileSync(path.join(root,'vendor/generated/data/minecraft/loot_table/gameplay/piglin_bartering.json')));
const entries=barter.pools[0].entries,totalWeight=entries.reduce((s,e)=>s+(e.weight||1),0),barterRows=[];
for(const e of entries){let qty=1,key=e.name;let addPremium=0,note='';for(const f of e.functions||[]){if(f.function==='minecraft:set_count')qty=typeof f.count==='number'?f.count:(f.count.min+f.count.max)/2;if(f.function==='minecraft:set_potion'){key=e.name+'|'+f.id.slice(10);}if(f.function==='minecraft:enchant_randomly'){const ens=enchants.filter(x=>x.id===f.options);addPremium=ens.reduce((s,x)=>s+x.premium_vu,0)/ens.length;note='Uniform-level premium mix assumed; enchantment-level sampling not independently verified';if(e.name==='minecraft:book')key='minecraft:enchanted_book';}}const unit=price(key)+addPremium,prob=(e.weight||1)/totalWeight;barterRows.push({item:key,probability:prob,mean_count:qty,unit_reference_vu:unit,expected_vu:prob*qty*unit,note});}
save('barter-reference.json',{source:'Official 1.21.11 gameplay/piglin_bartering loot table',totalWeight,rows:barterRows,expected_vu:barterRows.reduce((s,r)=>s+r.expected_vu,0),gold_input_vu:price('gold_ingot'),interpretation:'Expected value only, not guaranteed payout. Component premium mix is an assumption; stock/travel/risk not included.'});
save('audit-findings.json',audits);csv('audit-findings.csv',audits);
const report={itemCount:items.length,priced:items.filter(x=>x.value_vu!==null).length,technicalExcluded:items.filter(x=>x.status==='excluded').length,variants:variants.length,activities:activities.length,basketRows:basket.length,nativeRecipes:recipes.length,manualRecipes:recipes.filter(x=>x.status!=='fixed').length,auditErrors:audits.filter(x=>x.severity==='error').length,quoteGranularity:quotes.filter(x=>qBad(x)).length,activityBand:activities.map(x=>({id:x.id,netVU:x.net_vu_per_world_hour,ratio:x.relative_to_stage_target})),barterExpected:barterRows.reduce((s,r)=>s+r.expected_vu,0)};
function qBad(q){return q.status.startsWith('Poor');}
save('analysis-summary.json',report);
console.log(JSON.stringify({...report,activityBand:report.activityBand.slice(0,8)},null,2));
