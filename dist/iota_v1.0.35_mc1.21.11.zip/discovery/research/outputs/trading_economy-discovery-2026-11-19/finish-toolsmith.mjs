import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {nearestBlockPayout} from './market-currency.mjs';
// Legacy2026-11-19 reproduction only; current generator is docs/discovery/tests/execute-trading-plan.mjs.
if(!process.argv.includes('--legacy'))throw Error('Historical generator: use docs/discovery/tests/execute-trading-plan.mjs. Pass --legacy only to reproduce old research artifacts.');
const root=path.resolve(import.meta.dirname,'../../../../..');
const work=path.join(root,'docs/discovery/research/outputs/toolsmith-template-2026-11-19');
fs.mkdirSync(work,{recursive:true});
const items=JSON.parse(fs.readFileSync(path.join(import.meta.dirname,'items.json')));
const values=new Map(items.filter(x=>x.value_vu!==null).map(x=>[x.id,x.value_vu]));
// Economic denomination for this candidate template, not a reprice of the matrix.
const vuPerEmerald=1;
function retailCurrency(target){
 const nominal=Math.max(1,Math.ceil(target));
 // Keep cost A exactly ONE item. Native Hero reductions cannot lower it.
 // Cost B is not modified by native reputation/Hero/demand calculations.
 const a={id:'minecraft:emerald',count:1};
 if(nominal===1)return {emeralds:1,a,b:null};
 if(nominal<=65)return {emeralds:nominal,a,b:{id:'minecraft:emerald',count:nominal-1}};
 const blocks=Math.ceil((nominal-1)/9);
 assert(blocks<=64,'Price exceeds the selected two-slot currency encoding');
 return {emeralds:1+9*blocks,a,b:{id:'minecraft:emerald_block',count:blocks}};
}
function payout(target){
 const nominal=Math.max(1,Math.floor(target));
 if(nominal<=64)return {emeralds:nominal,id:'minecraft:emerald',count:nominal};
 return nearestBlockPayout(target);
}
const raw=[['flint',32,64,null],['coal',32,128,null],['charcoal',32,128,null],['copper_ingot',32,64,32],['iron_ingot',16,64,32],['gold_ingot',8,32,32],['diamond',1,4,1],['netherite_scrap',1,null,1]].map(([name,lot,buyCap,sellCap])=>{
 const id='minecraft:'+name,p=values.get(id),bid=payout(.95*p*lot),ask=retailCurrency(1.05*p*lot);
 assert(bid.emeralds<ask.emeralds);
 assert(!buyCap||buyCap%lot===0);assert(!sellCap||sellCap%lot===0);
 return {id,vu:p,lot,buyCap,sellCap,bid:buyCap?bid:null,ask:sellCap?ask:null,hypotheticalAsk:ask};
});
const gear=[];
for(const material of ['copper','iron','golden','diamond','netherite'])for(const family of ['pickaxe','axe','shovel','hoe']){
 const id=`minecraft:${material}_${family}`,p=values.get(id);assert(p>0,id);
 for(const [enchantment,cap] of [[null,0],['efficiency',5],['unbreaking',3],['fortune',3],['silk_touch',1],['mending',1]])for(let level=cap?1:0;level<=cap;level++){
  // Saturated research premiums are not measured acquisition costs. This
  // flatter candidate is deliberately separate from the source matrix.
  const premium=enchantment==='mending'?64:enchantment==='silk_touch'?32:enchantment==='fortune'?32+8*(level-1):8*level;
  const value=p+premium,ask=retailCurrency(1.05*value),bid=payout(.95*value);
  assert(bid.emeralds<=ask.emeralds);
  const ordinary=material!=='netherite';
  const journeyman=ordinary&&['copper','iron'].includes(material)&&!enchantment;
  const expert=ordinary&&['iron','golden'].includes(material)&&['efficiency','unbreaking'].includes(enchantment);
  const master=ordinary&&['golden','diamond'].includes(material)&&((['efficiency','unbreaking'].includes(enchantment)&&level>=2)||['fortune','mending'].includes(enchantment));
  const contracts={journeyman:journeyman?payout(.95*p):null,expert:expert?payout(.95*(p+8)):null,master:master?payout(.95*(p+16)):null};
  gear.push({id,enchantment,level,baseVU:p,premiumVU:premium,priceVU:value,referenceBid:bid,ask,contracts,retailMendingAllowed:false});
 }
}
// Every generated bid is at/below its reference; every ask at/above it.
for(const x of gear){assert(x.referenceBid.emeralds<=x.priceVU+1e-8);assert(x.ask.emeralds>=x.priceVU);for(const bid of Object.values(x.contracts))if(bid)assert(bid.emeralds<=x.priceVU);}
// Evaluate all raw purchase/sale offers even when different villagers draw them.
for(const b of raw.filter(x=>x.bid))for(const a of raw.filter(x=>x.ask&&x.id===b.id))assert(b.bid.emeralds/b.lot<a.ask.emeralds/a.lot);
const originalChest=[1,2,4,8,16,24,32].map(n=>({buyers:n,ingotsPerBatch:32,batches:Math.ceil(3456/(32*n)),hoursAfterInitialStock:Math.ceil(3456/(32*n))-1}));
const chest=[1,2,4,8,16,24,32].map(n=>({buyers:n,ingotsPerBatch:64,batches:Math.ceil(3456/(64*n)),minutesNormal:60*(Math.ceil(3456/(64*n))-1),minutesWithIdealSleep:30*(Math.ceil(3456/(64*n))-1)}));
const state={status:'Design candidate finalized under user delegation; not implemented trades',vuPerEmerald,raw,gear,originalChest,chest,checks:{rawSameItemArbitrage:false,gearBidAboveReference:false,unboundedSleepRefill:false},limitations:['Not a Minecraft execution test','No full recipe-network or actual supplier-price validation','Native minimum/OR enchantment matching still requires an adapter/prototype','Sale of preexisting vanilla stock with extreme discounts must be included before release']};
fs.writeFileSync(path.join(work,'template.json'),JSON.stringify(state,null,2)+'\n');
fs.writeFileSync(path.join(work,'prices.csv'),'id,enchantment,level,reference_vu,reference_bid,ask_value,journeyman_contract,expert_contract,master_contract\n'+gear.map(x=>[x.id,x.enchantment??'',x.level,x.priceVU,x.referenceBid.emeralds,x.ask.emeralds,...Object.values(x.contracts).map(c=>c?.emeralds??'')].join(',')).join('\n')+'\n');
const show=x=>x?`${x.emeralds} E`: '—';
const doc=`# Toolsmith — completed design template

This is the canonical working Toolsmith template for adapting other professions.
The user authorized completion without another approval round. Catalog, material
stages, full durability, no rerolls/duplicates, Secret conditions and calibration
points 1/3 are user-selected. Prices, batches, sleep acceleration, XP per trade,
currency encoding and purchase-family allocation below are agent-selected
calibrations under that delegation, not observed balance or implemented trades.
Read alongside [Trading Design Directions](trading_design_directions.md).

## Complete persistent catalog

All rows add offers; retain previous rows. Group every sale before every purchase.

| Stage | Toolsmith sells | Toolsmith buys | Villager XP per sale / purchase |
|---|---|---|---:|
| Novice | Two distinct tool families, Copper75%/Iron25% each | Flint; Coal OR Charcoal | 4 / 2 |
| Apprentice | The other two families, Copper75%/Iron25% | Other fuel; Copper OR Iron ingots | 5 / 3 |
| Journeyman | Copper OR Iron ingots; Iron OR Gold tool | One plain Copper/Iron tool; Iron OR Gold ingots | 10 / 5 |
| Expert | Iron OR Gold ingots, exclude previous sale; Gold/Diamond tool, 50% enchanted I–II | One Iron/Gold tool with Efficiency I+ OR Unbreaking I+; Gold ingots OR Diamond | 15 / 10 |
| Master | Two Gold/Diamond tools, always enchanted I–III | One Gold/Diamond tool with Efficiency II+ OR Unbreaking II+ OR Fortune I+ OR Mending I | 20 / 15 |
| Secret | One Diamond45% / Diamond tool45% / Scrap5% / Netherite tool5% | No addition | 0 / — |

Families are Pickaxe/Axe/Shovel/Hoe. Each individual buys one family/material pair
per equipment stage, not every candidate. Draw the THREE purchase families
without replacement across Journeyman/Expert/Master; this prevents overlapping
minimum-enchantment predicates for the same item. Material pools stay as selected.
Later two-material draws are uniform after excluding duplicate offers. Initial
four retail families are without replacement; later retail excludes exact prior
item/enchantment results. Exhaustively enumerate valid plans rather than silently
dropping a slot. All ordinary levels add two sales; total20 offers including
11 sales and9 purchases at Secret. No fixed Apprentice Iron purchase is added.

Raw purchase staircase excludes previous draws: Apprentice Iron forces Journeyman
Gold, then Expert Diamond. Apprentice Copper leaves Journeyman Iron/Gold; its
result excludes any previous Expert raw purchase. Retail and purchase draws are
independent; a Copper outcome while buying Iron in the same tier band is valid.

Purchased equipment must have zero damage, no curses, and one qualifying useful
enchantment at the appropriate stage. Plain Journeyman items have no gameplay
enchantments; ignore internal preservation metadata/enchantments for this check.
Preserve names/lore/mastery/data while validating; consume only after successful
payment. No provenance claim distinguishes crafted tools from equivalent loot.

## Enchantments and item values

One compatible common enchantment per sold tool. Expert I/II equal, Master
I/II/III weighted20/50/30, Secret III/IV/V50/35/15. Filter levels above native cap
before renormalizing; if none survive at Secret use the native maximum. This
means Unbreaking never exceeds III, Fortune III and Silk Touch I. Pools start
Efficiency/Unbreaking; Master/Secret also Fortune/Silk Touch. No retail Mending.

Use the independent matrix's base item VU. For this candidate, add8VU per Efficiency/
Unbreaking level, Fortune32/40/48VU,32VU for Silk Touch,64VU for Mending; this replaces exponential RESEARCH
premiums only inside this template. Purchase contracts pay a fixed premium for
their minimum quality: Journeyman0VU, Expert8VU, Master16VU, then apply the payout
formula. Additional/higher compatible enchants remain acceptable but earn no
extra payment in this first template. Fortune I/Mending satisfy the Master
contract; their full reference premium is not automatically paid. This avoids
promising variable native payouts within one offer. The CSV separates reference
bids from actual stage-contract payouts; Mending asks are valuation references,
not selected retail offers. Tier and level-price inequality audits remain needed
against real enchanting inputs and all other suppliers.

## Emeralds and rounding

Adopt1VU=1emerald as a provisional denomination for the complete template, leaving
the independent matrix untouched. Target payout floor(0.95P), retail ceil(1.05P).
Unstackable tools cannot use bulk lots to hide rounding: Iron Pickaxe is6E bought,
8E sold; Diamond Pickaxe46E/52E. These actual spreads33.3%/13.0% replace any claim
that all offers achieve10.5%. Unit Coal/Flint would both round to1E; use lots.

| Item | Lot | Merchant payout | Merchant retail | Buy units / sale units per batch |
|---|---:|---:|---:|---:|
${raw.map(x=>`| ${x.id.split(':')[1]} | ${x.lot} | ${show(x.bid)} | ${show(x.ask)} | ${x.buyCap??'—'} / ${x.sellCap??'—'} |`).join('\n')}

Toolsmith never sells Flint, Coal or Charcoal; their hypothetical asks are used
only in cross-profession analysis. Raw Diamond/Scrap retail is Secret only.
Ordinary equipment purchase and sale caps are2items per selected offer/batch.
Master buys no new raw item; Netherite equipment is never bought. Full prices
for all families/one-enchantment variants are in the generated research CSV.

### Native discount and currency encoding

Set priceMultiplier=0 and keep cost A exactly ONE item. For a material purchase
lot q>1, use cost A=1material and cost B=q-1same material; payout is unchanged.
For retail <=65E use cost A=1emerald, B=price-1emeralds. Higher retail uses A=1E,
B=ceil((target-1)/9)emerald blocks: exact encoded price1+9B. This rounds upward
by up to8E and fits all generated Toolsmith outputs. Purchase payouts above64E
use the nearest whole-block payout to the unrounded95% target, constrained to
not exceed the reference value. Ties round down; an unsafe upward result falls
back to the lower adjacent multiple. Thus a71E target pays8blocks=72E when the
margin guard allows it, rather than7blocks=63E. This rounding policy is now
user-approved. Retail encoding still rounds upward to preserve its price floor.

Reason: native discounts affect cost A, not cost B; A cannot fall below1.
Do not assume priceMultiplier=0 alone disables Hero discounts. This encoding
preserves native Hero/gifts without granting an immediate buy/sell money loop.
Choose fixed prices for this first prototype; do not also implement the earlier
proposed5% loyalty discount. Two input slots with the same item are an explicit
UX compromise requiring in-game quick-move testing. Block payouts also require
space/transaction tests. No currency token or new item is introduced.

Native ItemCost uses DataComponentExactPredicate, confirmed in official1.21.11
server mappings. Arbitrary minimum levels plus extra enchantments/OR acceptance
are NOT thereby proven possible in a normal offer. Prototype an eligibility
adapter before runtime implementation; do not silently replace I+ with exact I,
strip names/data, or add unrestricted enchanted-item purchases. This is a
technical gate, not an unresolved catalog decision.

## Replenishment and sleep

Each ordinary offer refills to its cap every60 loaded simulation minutes with
reachable workstation, independently per villager. Secret:120minutes. No shared
demand; no banked/offline batches; no reload/GUI/jobsite reroll replenishment.
All simultaneous offer timers may share a villager's clock; preserve uses and
phase on save. Never overwrite Offers from a pristine snapshot to enforce order.

One completed qualifying sleep may deduct30minutes ONCE per ordinary cycle,
only after at least15 loaded minutes since that cycle began. No carryover credit;
no sleep acceleration for Secret. Therefore ordinary replenishment cannot be
faster than30 loaded minutes, even with repeated daytime sleeping. Require a
completed safe sleep, not merely entering/leaving a bed. Base World can provide
the completion hook; without World use a native completed night sleep. A short
nap or sleeping in another unloaded village cannot restock it. Preserve native
AI/workstation requirements; suppress native extra refills only after a prototype
proves this can be done without resetting offers or breaking transactions.

## Secret, reputation and names

Native UI stays Master5. Internal Secret unlock requires450cumulative villager XP
AND local reputation>=20 AND (defended that village against raid OR cured THIS
villager), all earned by the same player. Reputation0initial,-100..100range;
commerce+1/exchange capped+10lifetime per player/village; first local defense+10,
first resident cure+10; hit-5,kill-20. Do not repeat bonuses from cure loops.
After qualifying, persist the unlock on the merchant; normal offers are shared
with other players. Gossip is individual, not an existing village-wide counter:
village IDs, membership/migration and historical event attribution need a prototype.
Assign a random personal name at Apprentice once, preserving player-set names.

## Chest and breeding calculations

Large chest=54*64=3456ingots. With old32unit cap and initially full stocks:
${originalChest.map(x=>`${x.buyers}buyers: ${x.hoursAfterInitialStock}h`).join('; ')}.
With selected64unit Iron cap:
${chest.map(x=>`${x.buyers}buyers: ${x.minutesNormal}min, or ${x.minutesWithIdealSleep}min with ideal eligible sleep`).join('; ')}.
Exclude interaction/travel time. Buyers mean eligible leveled Toolsmiths, not
total population. Uniform staircase draws give75% probability of Iron buying;
32Toolsmiths average24buyers, not32guaranteed. Under the selected cap this
representative24buyer case takes120min, or60min with ideal sleep credits.

Eight adults give four parallel pairs. Twenty-four births need144Bread or
576Carrots/Potatoes/Beetroots, sufficient valid beds and loaded time. Ideal
birth waves near0/5/10/15/20/25min, then20min maturation, put32adults near45min
plus courtship/schedule delays. This is a theoretical lower-bound schedule,
not a measured breeder build time. Housing/food/transport and Toolsmith leveling
are additional. World clock skips do not advance cooldown/maturation ticks.

## Verification and release boundary

Generator checks integer stacks, currency capacity, raw-lot compatibility,
same-item undiscounted arbitrage and gear bid/reference/ask inequalities. These
are arithmetic checks, not a Monte Carlo rerun or proof of balanced play.
Still test native two-slot discounts, transactional integrity, all recipe and
other-supplier cycles, full/empty inventory, curse cleanup, sleep hooks and
native matching. No Trading code or ZIP is implemented by this document.
`;
fs.writeFileSync(path.join(work,'TOOLSMITH_TEMPLATE_LEGACY.md'),doc);
console.log(JSON.stringify({rawRows:raw.length,gearRows:gear.length,maxRetail:Math.max(...gear.map(x=>x.ask.emeralds)),checks:'passed',template:'docs/discovery/drafts/trading_toolsmith_template.md'},null,2));
