"""Package standalone research artifacts without dependencies or gameplay resources."""
import csv
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

work = Path(__file__).resolve().parent
out = work.parent.parent.parent / 'docs/discovery/research/outputs/01a1e661-66fd-7850-8264-8da8e32c1749/economy-discovery'
files = sorted(p for p in work.iterdir() if p.is_file() and p.suffix in {'.md', '.json', '.csv', '.mjs', '.py'} and p.name != 'unresolved-first-pass.json')
for file in files:
    if file.suffix == '.json':
        json.loads(file.read_text(encoding='utf-8'))
    elif file.suffix == '.csv':
        with file.open(encoding='utf-8', newline='') as handle:
            rows = csv.reader(handle)
            header = next(rows)
            assert all(len(row) == len(header) for row in rows), file.name
validation = json.loads((out / 'xlsx-independent-validation.json').read_text(encoding='utf-8'))
assert validation['passed'] and validation['worksheets'] == 13 and not validation['errorCells']
runtime = json.loads((work / 'runtime-source-manifest.json').read_text(encoding='utf-8'))
for source in runtime['files']:
    current_path = source['path']
    if current_path.startswith('expansions/'):
        current_path = 'modules/' + current_path
    assert hashlib.sha256((work.parent.parent.parent / current_path).read_bytes()).hexdigest() == source['sha256'], source['path']
extra = [out / 'iota_economy_discovery_2026-11-19.xlsx', out / 'workbook-validation.json', out / 'xlsx-independent-validation.json', out / 'formula-scan.json']
manifest = [{'path': 'research/' + p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size} for p in files]
manifest.extend({'path': p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size} for p in extra)
archive = out / 'iota_economy_discovery_2026-11-19_research.zip'
with ZipFile(archive, 'w', ZIP_DEFLATED, compresslevel=9) as bundle:
    for file in files:
        bundle.write(file, 'research/' + file.name)
    for file in extra:
        bundle.write(file, file.name)
    bundle.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
    bundle.writestr('RESEARCH_NOT_DATAPACK.txt', 'Initial economic discovery only. Not an installable datapack. Prices and rates are unmeasured proposals. Read research/TRADING_README.md. No profession catalog or gameplay change is included.\n')
with ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert not any('node_modules' in name or name.endswith('.log') for name in bundle.namelist())
    for entry in manifest:
        assert hashlib.sha256(bundle.read(entry['path'])).hexdigest() == entry['sha256']
(out / 'package-validation.json').write_text(json.dumps({'jsonAndCsvFilesValidated': len([p for p in files if p.suffix in {'.json', '.csv'}]), 'runtimeSourceFilesVerified': len(runtime['files']), 'archivedFiles': len(manifest) + 2, 'archive': archive.name, 'bytes': archive.stat().st_size, 'crcAndHashesPassed': True}, indent=2) + '\n', encoding='utf-8')
print(str(archive))
