import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {nearestBlockPayout} from './market-currency.mjs';
// Legacy2026-11-19 reproduction only; current generator is docs/discovery/tests/execute-trading-plan.mjs.
if(!process.argv.includes('--legacy'))throw Error('Historical generator: use docs/discovery/tests/execute-trading-plan.mjs. Pass --legacy only to reproduce old research artifacts.');
const root=path.resolve(import.meta.dirname,'../../../../..');
const out=path.join(root,'docs/discovery/research/outputs/profession-drafts-2026-11-19');
fs.mkdirSync(out,{recursive:true});
const items=new Map(JSON.parse(fs.readFileSync(path.join(import.meta.dirname,'items.json'))).map(x=>[x.id,x]));
const farm=new Map(JSON.parse(fs.readFileSync(path.join(import.meta.dirname,'farmability-items.json'))).map(x=>[x.id,x]));
const N=s=>'minecraft:'+s;
const x=(name,extra={})=>({id:N(name),...extra});
const pool=(...names)=>names.map(n=>typeof n==='string'?x(n):n);
const ench=(id,enchantment,level)=>x(id,{enchantment,level});
const book=(enchantment,level)=>x('enchanted_book',{enchantment,level,stored:true});
const req=(ids,quality)=>ids.map(id=>x(id,{quality}));
const map=(destination,fee)=>x('filled_map',{service:'exploration_map',destination,serviceVU:fee});
const potion=(effect,estimate)=>x('potion',{potion:effect,estimateVU:estimate});
const row=(stage,sales,purchases=[])=>({stage,sales,purchases});
const armor=(materials,quality=null)=>materials.flatMap(m=>['helmet','chestplate','leggings','boots'].map(f=>x(`${m}_${f}`,quality?{quality}:{})));
const armorEnch=(materials,level)=>materials.flatMap(m=>['helmet','chestplate','leggings','boots'].flatMap(f=>['protection','unbreaking'].map(e=>ench(`${m}_${f}`,e,Math.min(level,e==='unbreaking'?3:4)))));
const weapon=(materials,level=0)=>materials.flatMap(m=>['sword','spear'].map(f=>level?ench(`${m}_${f}`,'sharpness',level):x(`${m}_${f}`)));
const leather=['helmet','chestplate','leggings','boots'];
const professions=[
 {id:'armorer',role:'An equipment artisan: protection first, then material supply and commissioned armor.',notes:'Draw the initial four armor slots without replacement across Novice/Apprentice. For equipment purchases, reserve distinct slots across the three stages to avoid overlapping predicates. Secret material outcomes follow the Toolsmith weights; do not sell boss drops.',rows:[
  row('Novice',[armor(['copper','iron']),armor(['copper','iron'])],[pool('coal','charcoal'),pool('copper_ingot','iron_ingot')]),
  row('Apprentice',[armor(['copper','iron']),armor(['copper','iron'])],[pool('leather'),pool('iron_ingot','copper_ingot')]),
  row('Journeyman',[pool('copper_ingot','iron_ingot'),armor(['iron','golden'])],[armor(['copper','iron'],'plain'),pool('gold_ingot')]),
  row('Expert',[pool('iron_ingot','gold_ingot'),armorEnch(['golden','diamond'],2)],[armor(['iron','golden'],'armor-basic'),pool('diamond')]),
  row('Master',[armorEnch(['golden','diamond'],3),armorEnch(['golden','diamond'],3)],[armor(['golden','diamond'],'armor-advanced')]),
  row('Secret',[[x('diamond',{weight:45}),x('netherite_scrap',{weight:5}),...armorEnch(['diamond'],4).map(a=>({...a,weight:45/8})),...armorEnch(['netherite'],4).map(a=>({...a,weight:5/8}))]])]},
 {id:'weaponsmith',role:'An equipment artisan for Swords and Spears; axes remain a Toolsmith responsibility in this first draft.',notes:'Novice draws Copper/Iron for each weapon family; Apprentice supplies the other material for each, excluding duplicates. Thus buying Iron never precedes an eligible Copper/Iron retail band. No Mace/Trident sale replaces its acquisition challenge. Choose Expert/Master purchase families without replacement.',rows:[
  row('Novice',[pool('copper_sword','iron_sword'),pool('copper_spear','iron_spear')],[pool('coal','charcoal'),pool('copper_ingot','iron_ingot')]),
  row('Apprentice',[pool('copper_sword','iron_sword'),pool('copper_spear','iron_spear')],[pool('flint'),pool('iron_ingot','copper_ingot')]),
  row('Journeyman',[pool('iron_ingot','gold_ingot'),weapon(['golden'])],[req(['copper_sword','copper_spear','iron_sword','iron_spear'],'plain'),pool('gold_ingot')]),
  row('Expert',[weapon(['diamond']),weapon(['golden'],2)],[req(['iron_sword','iron_spear','golden_sword','golden_spear'],'weapon-basic'),pool('diamond')]),
  row('Master',[weapon(['golden','diamond'],3),weapon(['golden','diamond'],3)],[req(['golden_sword','golden_spear','diamond_sword','diamond_spear'],'weapon-advanced')]),
  row('Secret',[[x('diamond',{weight:45}),x('netherite_scrap',{weight:5}),...weapon(['diamond'],5).map(a=>({...a,weight:22.5})),...weapon(['netherite'],5).map(a=>({...a,weight:2.5}))]])]},
 {id:'fletcher',role:'An equipment artisan for projectile weapons and ammunition.',notes:'Feathers and String are the two guaranteed starting purchases. Journeyman buys plain Bow/Crossbow; Expert and Master use different enchanted weapon families. No weapon kits or bundle-opening system is revived.',rows:[
  row('Novice',[pool('bow'),pool('arrow')],[pool('feather'),pool('string')]),
  row('Apprentice',[pool('crossbow'),pool('spectral_arrow')],[pool('flint'),pool('stick')]),
  row('Journeyman',[pool(x('tipped_arrow',{potion:'poison',estimateVU:1.5})),pool(ench('bow','unbreaking',1))],[req(['bow','crossbow'],'plain'),pool('tripwire_hook')]),
  row('Expert',[pool(ench('bow','power',2)),pool(ench('crossbow','quick_charge',2))],[req(['bow','crossbow'],'ranged-basic'),pool('iron_ingot')]),
  row('Master',[pool(ench('bow','power',3)),pool(ench('crossbow','quick_charge',3))],[req(['bow','crossbow'],'ranged-advanced')]),
  row('Secret',[pool(ench('bow','power',5),ench('bow','infinity',1),ench('crossbow','multishot',1))])]},
 {id:'leatherworker',role:'An artisan providing durable leather equipment, materials and cosmetic specialization without requiring passive-animal killing.',notes:'Initial four armor slots are without replacement. Choose different Expert/Master purchase slots. Rotten Flesh input uses the existing Iota Leather route; no new tanning mechanic is assumed.',rows:[
  row('Novice',[leather.map(f=>x('leather_'+f)),leather.map(f=>x('leather_'+f))],[pool('rotten_flesh'),pool('leather')]),
  row('Apprentice',[leather.map(f=>x('leather_'+f)),leather.map(f=>x('leather_'+f))],[pool('rabbit_hide'),pool('string')]),
  row('Journeyman',[pool('leather'),pool('rabbit_hide')],[req(leather.map(f=>'leather_'+f),'plain'),pool('red_dye','blue_dye')]),
  row('Expert',[pool('leather_horse_armor'),armorEnch(['leather'],2)],[req(leather.map(f=>'leather_'+f),'armor-basic'),pool('black_dye','white_dye')]),
  row('Master',[armorEnch(['leather'],3),armorEnch(['leather'],3)],[req(leather.map(f=>'leather_'+f),'armor-advanced')]),
  row('Secret',[pool({...ench('leather_chestplate','protection',4),dye:0x387ca0,weight:95},{...ench('leather_chestplate','mending',1),dye:0x387ca0,weight:5})])]},
 {id:'farmer',role:'A producer exchanging complementary crops, seed access, animal feed and prepared staples.',notes:'Common seed exchange is proposed here after finishing Toolsmith. Do not include Torchflower/Pitcher seeds or replace Sniffer discovery. Food and seed capacity is higher than equipment capacity.',rows:[
  row('Novice',[pool('bread'),pool('carrot')],[pool('wheat'),pool('carrot','potato')]),
  row('Apprentice',[pool('potato'),pool('apple')],[pool('beetroot'),pool('pumpkin')]),
  row('Journeyman',[pool('wheat_seeds','beetroot_seeds','pumpkin_seeds','melon_seeds'),pool('hay_block')],[pool('melon'),pool('wheat_seeds','beetroot_seeds','pumpkin_seeds','melon_seeds')]),
  row('Expert',[pool('pumpkin_pie'),pool('golden_carrot')],[pool('bread'),pool('baked_potato')]),
  row('Master',[pool('cake'),pool('honey_bottle')],[pool('pumpkin_pie')]),
  row('Secret',[pool('golden_apple')])]},
 {id:'butcher',role:'A food provider selling meat and prepared meals while buying complementary food inputs, not demanding a livestock slaughter loop.',notes:'Eggs/Milk are fixed starting purchases. Bucket purchases consume the container and pay its included value. Raw Cod/Salmon purchases at Journeyman are a NEW suggested outlet for the angler, not a reversal of Fisherman refusing fish.',rows:[
  row('Novice',[pool('cooked_chicken'),pool('cooked_porkchop')],[pool('egg'),pool('milk_bucket')]),
  row('Apprentice',[pool('cooked_beef'),pool('cooked_mutton')],[pool('carrot','potato'),pool('wheat')]),
  row('Journeyman',[pool('cooked_cod'),pool('cooked_salmon')],[pool('cod','salmon'),pool('bowl')]),
  row('Expert',[pool('cooked_rabbit'),pool('rabbit_stew')],[pool('red_mushroom','brown_mushroom'),pool('beetroot')]),
  row('Master',[pool('pumpkin_pie'),pool('golden_carrot')],[pool('mushroom_stew','beetroot_soup')]),
  row('Secret',[pool(x('suspicious_stew',{stew:'saturation',estimateVU:10}))])]},
 {id:'fisherman',role:'A fish supplier and fishing-equipment specialist, not a buyer of the same catch.',notes:'NEVER buys raw or cooked fish. Only Master buys enchanted rods, avoiding two overlapping enchantment-grade offers on one item. Earlier plain-rod contracts explicitly reject gameplay enchantments.',rows:[
  row('Novice',[pool('cod'),pool('salmon')],[pool('string'),pool('stick')]),
  row('Apprentice',[pool('cooked_cod'),pool('fishing_rod')],[pool('coal','charcoal'),pool('iron_ingot')]),
  row('Journeyman',[pool('bucket'),pool('cooked_salmon')],[req(['fishing_rod'],'plain'),pool('bowl')]),
  row('Expert',[pool('tropical_fish_bucket'),pool('pufferfish_bucket')],[pool('charcoal','coal'),pool('glass_bottle')]),
  row('Master',[pool(ench('fishing_rod','luck_of_the_sea',2)),pool(ench('fishing_rod','lure',2))],[req(['fishing_rod'],'fishing-advanced')]),
  row('Secret',[pool({...ench('fishing_rod','luck_of_the_sea',3),weight:47.5},{...ench('fishing_rod','lure',3),weight:47.5},{...ench('fishing_rod','mending',1),weight:5})])]},
 {id:'shepherd',role:'A textile/color producer, decorator and provider of practical beds and shears.',notes:'Color variants are meaningful outputs; quantity/price changes are not new offers. Patterned Secret banners are cosmetic and do not imply a new custom item. Avoid paying extra for arbitrary banner-pattern counts.',rows:[
  row('Novice',[pool('white_wool'),pool('shears')],[pool('white_wool'),pool('string')]),
  row('Apprentice',[pool('white_carpet'),pool('red_dye','blue_dye','yellow_dye')],[pool('red_dye','blue_dye','yellow_dye'),pool('black_wool','gray_wool','brown_wool')]),
  row('Journeyman',[pool('white_bed','red_bed','blue_bed'),pool('white_banner')],[pool('white_carpet'),pool('leather')]),
  row('Expert',[pool('red_wool','blue_wool','yellow_wool'),pool('black_dye','white_dye')],[pool('white_bed','red_bed','blue_bed'),pool('white_banner')]),
  row('Master',[pool('red_carpet','blue_carpet','yellow_carpet'),pool('painting')],[pool('painting')]),
  row('Secret',[pool(x('white_banner',{banner:'flower-blue',serviceVU:8}),x('white_banner',{banner:'creeper-green',serviceVU:12}))])]},
 {id:'librarian',role:'A knowledge supplier with stable useful books and progressively specialized enchantments.',notes:'Teaching found books remains FUTURE work, not an implemented contract. Secret Mending is a proposed rare supply route, not a guaranteed biome book; no experiment is required. Discovery integration only registers acquired items when that expansion is installed.',rows:[
  row('Novice',[pool('book'),pool('bookshelf')],[pool('paper'),pool('ink_sac')]),
  row('Apprentice',[pool(book('efficiency',1),book('unbreaking',1)),pool('lapis_lazuli')],[pool('leather'),pool('book')]),
  row('Journeyman',[pool(book('protection',2),book('power',2)),pool(book('fortune',1),book('looting',1))],[pool('bookshelf'),pool('glass')]),
  row('Expert',[pool(book('efficiency',2),book('power',3)),pool(book('respiration',2),book('depth_strider',2))],[pool('amethyst_shard'),pool('glow_ink_sac')]),
  row('Master',[pool(book('efficiency',4),book('protection',4)),pool(book('unbreaking',3),book('fortune',3))],[pool(book('efficiency',3),book('unbreaking',2))]),
  row('Secret',[[{...book('mending',1),weight:5},{...book('frost_walker',2),weight:5},{...book('efficiency',5),weight:45},{...book('looting',3),weight:45}]])]},
 {id:'cartographer',role:'A survey/navigation specialist selling exploration directions rather than the treasure itself.',notes:'Map prices include an explicit unmeasured survey-service allowance. Destinations are proposals, not pre-generated map IDs. A filled map needs runtime exploration-map generation; do not sell empty placeholders. Do not buy blank or copied written books as discoveries.',rows:[
  row('Novice',[pool('map'),pool('compass')],[pool('paper'),pool('glass_pane')]),
  row('Apprentice',[pool('spyglass'),pool(map('village',12))],[pool('ink_sac'),pool('amethyst_shard')]),
  row('Journeyman',[pool(map('shipwreck',16)),pool(map('ruined_portal',20))],[pool('map'),pool('compass')]),
  row('Expert',[pool(map('ocean_monument',32)),pool(map('trial_chambers',36))],[pool('spyglass'),pool('clock')]),
  row('Master',[pool(map('woodland_mansion',48)),pool('recovery_compass')],[pool('recovery_compass')]),
  row('Secret',[pool(map('ancient_city',64))])]},
 {id:'cleric',role:'An expedition reagent and brewing supplier, complementing gathering and exploration.',notes:'Potion prices are explicit provisional batch/service estimates, not plain potion-ID matrix values. Secret Echo Shard/Breeze Rod remains a proposal; neither Nether Star nor Heavy Core is sold.',rows:[
  row('Novice',[pool('redstone'),pool('lapis_lazuli')],[pool('rotten_flesh'),pool('nether_wart')]),
  row('Apprentice',[pool('glowstone_dust'),pool('quartz')],[pool('glass_bottle'),pool('red_mushroom','brown_mushroom')]),
  row('Journeyman',[pool('experience_bottle'),pool('ender_pearl')],[pool('spider_eye'),pool('blaze_powder')]),
  row('Expert',[pool(potion('fire_resistance',10)),pool(potion('strong_healing',8))],[pool('magma_cream'),pool('phantom_membrane')]),
  row('Master',[pool(potion('slow_falling',12)),pool(potion('strong_regeneration',14))],[pool('ghast_tear')]),
  row('Secret',[[x('wind_charge',{weight:45}),x('breeze_rod',{weight:45}),x('echo_shard',{weight:10})]])]},
 {id:'mason',role:'A high-throughput construction supplier who benefits builders without making the workstation trade-exclusive.',notes:'Flint is guaranteed early retail, reserved here rather than Toolsmith. Bulk stock is higher than gear stock. Finished stone variants are made by the artisan who already has a Stonecutter; player recipes remain as selected. Secret is a bulk material offer, not one decorative block per two hours.',rows:[
  row('Novice',[pool('flint'),pool('stone')],[pool('cobblestone'),pool('gravel')]),
  row('Apprentice',[pool('clay_ball'),pool('brick')],[pool('sand'),pool('clay_ball')]),
  row('Journeyman',[pool('terracotta'),pool('quartz_block')],[pool('sandstone'),pool('glass')]),
  row('Expert',[pool('stone_bricks'),pool('chiseled_stone_bricks')],[pool('terracotta'),pool('stone_bricks')]),
  row('Master',[pool('prismarine'),pool('sea_lantern')],[pool('quartz_block')]),
  row('Secret',[pool('calcite','amethyst_block','purpur_block')])]},
];
const qualityPremium={plain:0,'armor-basic':8,'armor-advanced':16,'weapon-basic':8,'weapon-advanced':16,'ranged-basic':8,'ranged-advanced':16,'fishing-advanced':16};
const enchPremium=(e,l)=>e==='mending'?64:e==='silk_touch'?32:e==='fortune'?32+8*(l-1):8*l;
function value(a){
 const item=items.get(a.id);assert(item,`Unknown item ${a.id}`);
 let v=a.estimateVU??item.value_vu,basis=a.estimateVU?'Agent-estimated component/service value':'Provisional independent matrix';
 if(a.service==='exploration_map'){v=items.get(N('map')).value_vu+a.serviceVU;basis='Empty map plus unmeasured survey fee';}
 if(a.stored){v=items.get(N('book')).value_vu;basis='Book plus template enchantment premium';}
 if(a.enchantment)v+=enchPremium(a.enchantment,a.level);
 if(a.quality)v+=qualityPremium[a.quality];
 if(a.banner)v+=a.serviceVU;
 assert(Number.isFinite(v)&&v>0,`No usable valuation: ${a.id}`);
 return {v,basis};
}
function currency(target,buying){
 let n=buying?Math.floor(target):Math.ceil(target);n=Math.max(n,1);
 if(buying){if(n<=64)return {value:n,payment:[{item:'emerald',count:n}]};const p=nearestBlockPayout(target);return {value:p.emeralds,payment:[{item:'emerald_block',count:p.count}]};}
 if(n<=65)return {value:n,payment:[{item:'emerald',count:1},...(n>1?[{item:'emerald',count:n-1}]:[])]};
 const blocks=Math.ceil((n-1)/9);assert(blocks<=64,`Unencodable retail ${target}`);
 return {value:1+9*blocks,payment:[{item:'emerald',count:1},{item:'emerald_block',count:blocks}]};
}
const directRisk=new Set(['iron_ingot','gold_ingot','gold_nugget','rotten_flesh','string','bone','gunpowder','stick','paper','pumpkin','melon','wheat']);
const smallStock=new Set(['diamond','netherite_scrap','echo_shard','ghast_tear','breeze_rod']);
function quote(a,dir,profession,stage){
 const {v,basis}=value(a),item=items.get(a.id),f=farm.get(a.id),name=a.id.split(':')[1];
 const nonstack=item.stack===1||a.service;
 let cap=nonstack?2:64;
 if(profession==='mason'&&!nonstack)cap=dir==='sell'?256:128;
 if(['farmer','butcher','fisherman'].includes(profession)&&!nonstack)cap=128;
 if(profession==='fletcher'&&name.endsWith('arrow'))cap=128;
 if(dir==='buy'&&(directRisk.has(name)||(f?.pressure??0)>=.7))cap=Math.min(cap,64);
 if(smallStock.has(name))cap=dir==='buy'?4:2;
 if(stage==='Secret')cap=profession==='mason'?64:1;
 const qs=nonstack||stage==='Secret'&&profession!=='mason'?[1]:[1,2,4,8,16,32,64].filter(q=>q<=Math.min(cap,item.stack));
 const options=[];
 for(const q of qs){
  if(.95*v*q<1)continue;
  if(1.05*v*q>577||.95*v*q>=585)continue;
  const bid=currency(.95*v*q,true),ask=currency(Math.max(1.05*v*q,bid.value+1),false);
  const error=Math.max(Math.abs(bid.value/(.95*v*q)-1),ask.value/(1.05*v*q)-1);
  options.push({q,bid,ask,error});
 }
 assert(options.length,`No denomination for ${a.id} (${v})`);
 options.sort((a,b)=>a.error-b.error||a.q-b.q);
 const z=options[0],price=dir==='buy'?z.bid:z.ask;
 assert(cap%z.q===0);assert(z.bid.value<z.ask.value);
 assert(z.bid.value<=v*z.q+1e-7);assert(z.ask.value>=v*z.q);
 const inputCosts=dir==='buy'?[{id:a.id,count:1},...(z.q>1?[{id:a.id,count:z.q-1}]:[])]:price.payment.map(p=>({id:N(p.item),count:p.count}));
 for(const cost of inputCosts)assert(cost.count>=1&&cost.count<=items.get(cost.id).stack);
 return {...a,referenceVU:v,valueBasis:basis,farmability:{status:f?.status??'unknown',pressure:f?.pressure??null,coverage:f?.coverage??0},direction:dir,lot:z.q,price,inputCosts,unitEmeralds:price.value/z.q,stockUnits:cap,uses:cap/z.q,roundingError:z.error};
}
const key=a=>JSON.stringify([a.id,a.enchantment??null,a.level??null,a.quality??null,a.potion??null,a.stew??null,a.destination??null,a.banner??null,a.dye??null]);
const plans=[],quotes=[];
for(const p of professions){
 assert.equal(p.rows.length,6);let serial=0;
 const xp={Novice:[4,2],Apprentice:[5,3],Journeyman:[10,5],Expert:[15,10],Master:[20,15],Secret:[0,0]};
 const rows=p.rows.map(r=>({...r,villagerXP:{sale:xp[r.stage][0],purchase:xp[r.stage][1]},sales:r.sales.map(c=>({slot:++serial,candidates:c.map(a=>quote(a,'sell',p.id,r.stage))})),purchases:r.purchases.map(c=>({slot:++serial,candidates:c.map(a=>quote(a,'buy',p.id,r.stage))}))}));
 for(const r of rows)assert.equal(r.sales.length,r.stage==='Secret'?1:2);
 if(p.id==='fisherman')for(const r of rows)for(const s of r.purchases)assert(s.candidates.every(a=>!['cod','salmon','cooked_cod','cooked_salmon','tropical_fish','pufferfish'].map(N).includes(a.id)));
 for(const r of rows)for(const s of [...r.sales,...r.purchases])for(const a of s.candidates)quotes.push({profession:p.id,stage:r.stage,slot:s.slot,...a});
 plans.push({...p,rows});
}
// Every candidate retains its reference; only stock uses farmability pressure.
// Unknown coverage is never silently treated as zero automation potential.
function accepts(b,a){
 if(b.id!==a.id)return false;
 if(b.enchantment)return b.enchantment===a.enchantment&&b.level===a.level;
 if(!b.quality)return !b.potion||b.potion===a.potion;
 if(b.quality==='plain')return !a.enchantment;
 const e=a.enchantment,l=a.level??0,advanced=b.quality.endsWith('advanced');
 if(advanced&&e==='mending')return true;
 if(e==='unbreaking'&&l>=(advanced?2:1))return true;
 if(b.quality.startsWith('armor'))return e==='protection'&&l>=(advanced?2:1);
 if(b.quality.startsWith('weapon'))return e==='sharpness'&&l>=(advanced?2:1);
 if(b.quality.startsWith('ranged'))return ['power','quick_charge'].includes(e)&&l>=(advanced?2:1);
 if(b.quality.startsWith('fishing'))return ['luck_of_the_sea','lure'].includes(e)&&l>=2;
 return false;
}
// Include completed Toolsmith prices in cross-profession comparisons.
const toolsmith=JSON.parse(fs.readFileSync(path.join(root,'docs/discovery/research/outputs/toolsmith-template-2026-11-19/template.json')));
const external=[];
for(const a of toolsmith.raw){if(a.ask)external.push({...a,profession:'toolsmith',direction:'sell',unitEmeralds:a.ask.emeralds/a.lot});if(a.bid)external.push({...a,profession:'toolsmith',direction:'buy',unitEmeralds:a.bid.emeralds/a.lot});}
for(const a of toolsmith.gear){
 const mat=a.id.split(':')[1].split('_')[0];
 if(a.enchantment!=='mending'&&!(mat==='netherite'&&!a.enchantment))external.push({...a,profession:'toolsmith',direction:'sell',unitEmeralds:a.ask.emeralds});
 for(const [stage,bid]of Object.entries(a.contracts))if(bid)external.push({...a,profession:'toolsmith',direction:'buy',unitEmeralds:bid.emeralds,stage});
}
let directPairs=0;
for(const b of [...quotes,...external].filter(x=>x.direction==='buy'))for(const a of [...quotes,...external].filter(x=>x.direction==='sell'&&accepts(b,x))){
 assert(b.unitEmeralds<a.unitEmeralds,`Direct arbitrage: ${b.profession}->${a.profession} ${key(b)}`);directPairs++;
}
// Validate existence of at least one unique complete plan, including armor
// initial family selection and raw/fuel exclusions. Backtrack, never drop a slot.
function validPlan(p,force=null){
 const slots=p.rows.flatMap(r=>[...r.sales,...r.purchases].map(s=>({...s,stage:r.stage,direction:r.sales.includes(s)?'sell':'buy'})));
 const seen={sell:new Set(),buy:new Set()},families=new Set(),purchaseFamilies=new Set(),chosen=[];
 function pick(i){
  if(i===slots.length)return true;
  const s=slots[i];
  for(const a of s.candidates){
   if(force&&force.slot===s.slot&&key(a)!==force.key)continue;
   const k=key(a);if(seen[s.direction].has(k))continue;
   let family=null;
   if(['armorer','leatherworker'].includes(p.id)&&s.direction==='sell'&&['Novice','Apprentice'].includes(s.stage)){
    family=a.id.split('_').at(-1);if(families.has(family))continue;
   }
   let purchaseFamily=null;
   if(s.direction==='buy'&&a.quality&&(['armorer','leatherworker'].includes(p.id)||['weaponsmith','fletcher'].includes(p.id)&&s.stage!=='Journeyman')){
    purchaseFamily=a.id.split('_').at(-1);if(purchaseFamilies.has(purchaseFamily))continue;
   }
   seen[s.direction].add(k);if(family)families.add(family);if(purchaseFamily)purchaseFamilies.add(purchaseFamily);chosen.push({stage:s.stage,direction:s.direction,id:a.id,key:k});
   if(pick(i+1))return true;
   chosen.pop();seen[s.direction].delete(k);if(family)families.delete(family);if(purchaseFamily)purchaseFamilies.delete(purchaseFamily);
  }
  return false;
 }
 assert(pick(0),`No complete unique plan for ${p.id}`);return chosen;
}
const examplePlans=plans.map(p=>({profession:p.id,offers:validPlan(p).sort((a,b)=>(a.direction==='sell'?0:1)-(b.direction==='sell'?0:1))}));
let feasibleCandidates=0;
for(const p of plans)for(const r of p.rows)for(const s of [...r.sales,...r.purchases])for(const a of s.candidates){validPlan(p,{slot:s.slot,key:key(a)});feasibleCandidates++;}
// Read native supported-item tags rather than assuming Spear/armor compatibility.
const data=path.join(root,'vendor/generated/data/minecraft');
function tagItems(id,visited=new Set()){
 if(!id.startsWith('#'))return [id];if(visited.has(id))return [];visited.add(id);
 const rel=id.slice(1).split(':')[1],file=path.join(data,'tags/item',rel+'.json');assert(fs.existsSync(file),id);
 return JSON.parse(fs.readFileSync(file)).values.flatMap(x=>tagItems(typeof x==='string'?x:x.id,new Set(visited)));
}
let supported=0;
for(const a of quotes.filter(x=>x.enchantment)){
 const def=JSON.parse(fs.readFileSync(path.join(data,'enchantment',a.enchantment+'.json')));
 assert(a.level<=def.max_level);if(a.stored)continue;const ids=(Array.isArray(def.supported_items)?def.supported_items:[def.supported_items]).flatMap(x=>tagItems(x));
 assert(ids.includes(a.id),`Unsupported enchant ${a.enchantment} on ${a.id}`);supported++;
}
const recipeChecks=[];
for(const [source,result,factor] of [['rabbit_hide','leather',.25],['leather','rabbit_hide',4],['white_wool','string',4],['string','white_wool',.25],['hay_block','wheat',9],['wheat','hay_block',1/9],['bookshelf','book',3],['iron_ingot','iron_nugget',9],['gold_ingot','gold_nugget',9],['diamond','diamond_block',1/9]]){
 const asks=quotes.filter(x=>x.direction==='sell'&&x.id===N(source)&&!x.enchantment),bids=quotes.filter(x=>x.direction==='buy'&&x.id===N(result)&&!x.enchantment);
 if(!asks.length||!bids.length)continue;
 const cheapest=Math.min(...asks.map(x=>x.unitEmeralds)),highest=Math.max(...bids.map(x=>x.unitEmeralds));
 const surplus=highest*factor-cheapest;assert(surplus<=1e-6,`Reversible recipe arbitrage ${source}->${result}`);recipeChecks.push({source,result,factor,surplus});
}
fs.writeFileSync(path.join(out,'catalogs.json'),JSON.stringify({status:'Proposed profession adaptations, not approved catalogs or implemented trades',denomination:'1 provisional VU per emerald',professions:plans},null,2)+'\n');
fs.writeFileSync(path.join(out,'example-plans.json'),JSON.stringify(examplePlans,null,2)+'\n');
const columns=['profession','stage','direction','slot','id','enchantment','level','quality','potion','destination','lot','unitEmeralds','stockUnits','uses','referenceVU','valueBasis','farmabilityStatus','farmabilityPressure','roundingError'];
const csv=v=>'"'+String(v??'').replaceAll('"','""')+'"';
fs.writeFileSync(path.join(out,'prices-and-stock.csv'),columns.join(',')+'\n'+quotes.map(q=>columns.map(c=>csv(c==='farmabilityStatus'?q.farmability.status:c==='farmabilityPressure'?q.farmability.pressure:q[c])).join(',')).join('\n')+'\n');
const summary={passed:true,professions:plans.length,candidateQuotes:quotes.length,uniqueExamplePlans:examplePlans.length,candidatesProvenExtendable:feasibleCandidates,directSameComponentPairsChecked:directPairs,nativeEnchantmentSupportChecks:supported,reverseRecipeChecks:recipeChecks,measuredRatesUsed:false,indexPriceEffect:0,unknownFarmabilityQuotes:quotes.filter(x=>x.farmability.status==='unknown').length,largeRoundingQuotes:quotes.filter(x=>x.roundingError>.10).length,limits:['Candidate prices are not measured income','No real player trading or discount execution','Only specified reversible recipes checked, not the entire recipe/smelting/loot network','No modified Monte Carlo run','A single forced candidate can be extended, not every arbitrary combination of prior draws; generation must backtrack']};
fs.writeFileSync(path.join(out,'validation.json'),JSON.stringify(summary,null,2)+'\n');
const title=id=>id.split('_').map(x=>x[0].toUpperCase()+x.slice(1)).join(' ');
const label=a=>title(a.id.split(':')[1])+(a.enchantment?' — '+title(a.enchantment)+' '+a.level:'')+(a.quality?' ['+a.quality+']':'')+(a.potion?' ['+a.potion+']':'')+(a.stew?' ['+a.stew+']':'')+(a.destination?' → '+title(a.destination):'')+(a.banner?' ['+a.banner+']':'')+(a.dye?' [dyed]':'');
const slotLabel=s=>{
 const weighted=s.candidates.some(c=>c.weight!==undefined),total=s.candidates.reduce((n,c)=>n+(c.weight??1),0);
 if(s.candidates.length<=4)return s.candidates.map(a=>`${label(a)} (${a.lot} for ${a.price.value}E; stock ${a.stockUnits}${weighted?'; draw '+(100*(a.weight??1)/total).toFixed(1)+'%':''})`).join(' OR ');
 const groups=new Map();
 for(const a of s.candidates){
  const m=a.id.match(/minecraft:(.+)_(helmet|chestplate|leggings|boots)$/),g=m?title(m[1])+' armor'+(a.enchantment?' — '+title(a.enchantment)+' '+a.level:'')+(a.quality?' ['+a.quality+']':''):label(a);
  if(!groups.has(g))groups.set(g,[]);groups.get(g).push(a);
 }
 return [...groups].map(([name,c])=>{
  const prices=c.map(a=>a.price.value),lo=Math.min(...prices),hi=Math.max(...prices);
  return `${name}${c.length>1?' (draw one armor slot)':''}: ${c[0].lot} for ${lo===hi?lo:lo+'–'+hi}E; stock ${c[0].stockUnits}${weighted?'; '+(100*c.reduce((n,a)=>n+(a.weight??1),0)/total).toFixed(1)+'%':''}`;
 }).join(' OR ');
};
let doc=`# Other professions — proposed catalog and pricing draft

Toolsmith was completed FIRST in [Toolsmith Template](trading_toolsmith_template.md).
This document adapts it to the twelve other employed vanilla professions.
All new catalogs here are PROPOSALS for review, not user-approved lists, actual
trades, measured balance or a new release. No datapack/world/ZIP changes are made.
The Wandering Trader and unemployed/nitwit villagers are outside this draft.

## Shared rules and evidence

Carry over fixed career plans, no jobsite rerolls, unique offers, sales-first
ordering, safe full-durability purchases, material coherence, names at Apprentice,
and shared visible offers after a qualifying player's internal Secret unlock.
Secret remains native Master5, requires450villager XP AND reputation>=20 AND
(local raid defense OR curing that villager). No shared demand or population-prosperity
mechanic is introduced. Each ordinary stage adds two sales; purchases are
additional. Earlier offers persist; all listed slots are additions, not a full
randomized shop per level.

Villager XP per sale/purchase inherits Toolsmith: Novice4/2, Apprentice5/3,
Journeyman10/5, Expert15/10, Master20/15; Secret adds no further XP requirement.

Retain the completed Toolsmith60minute loaded refill; bounded sleep credit can
reduce ordinary cycles to30minutes, never below. Secret120minutes, no sleep
credit. Building supplies get larger batches because delivering a usable build
is different from delivering equipment; Mason Secret is64blocks, not one block.
Other Secret offers cap at one item per cycle. Preserve workstation/AI checks.

Prices use the independent matrix's provisional reference values at1VU=1emerald,
not farm throughput measurements. Use template enchantment premiums; minimum
quality contracts are fixed8VU/16VU premiums, not payment for every extra enchant.
Native minimum/OR matching still requires an eligibility adapter. Empty potion
IDs, map destinations and pattern services require separate values; rows mark
those manual estimates explicitly instead of claiming matrix coverage.

Farmability index alpha remains ZERO: do not apply an unexplained price nerf.
For purchases, directly modeled high pressure or known automated metal/mob/crop
routes cap ordinary volume at64units; food staples otherwise128, building
sales256. Unknown index coverage is UNKNOWN, not unautomatable or safe. This is
a first stock-risk screen, not an established village budget or a proof that
buyer multiplication cannot dominate income.

Each candidate below states TOTAL item lot, TOTAL emerald value paid/charged,
and TOTAL units in stock. Purchases consume the item/container. Use the Toolsmith
currency encoding: first input count1, remainder in input B, priceMultiplier0;
otherwise native Hero discounts can erase a thin margin. High payouts use whole
emerald blocks; high asks use1emerald plus blocks. Full encoding is in JSON.
Both identical input stacks and actual Hero behavior still need player tests.

### Price/stock table reading

OR means a permanent draw from eligible candidates for one offer slot. PLUS
means another independent slot. Filter duplicates in that direction and solve
the whole plan before committing. Do not treat quantity changes as new offers.
Armor early draws use four distinct slots; enforce exclusions on families and
overlapping enchanted purchases as described per profession. Each candidate was
forced into a complete unique plan; examples are grouped sales-first. Arbitrary
greedy combinations still require backtracking.
Toolsmith itself is not redefined here.
`;
for(const p of plans){
 doc+=`\n## ${title(p.id)}\n\n${p.role}\n\n${p.notes}\n\n| Stage | Villager sells | Villager buys |\n|---|---|---|\n`;
 for(const r of p.rows)doc+=`| ${r.stage} | ${r.sales.map(slotLabel).join(' PLUS ')} | ${r.purchases.map(slotLabel).join(' PLUS ')||'No addition'} |\n`;
}
doc+=`\n## Purchase-grade definitions\n\nPlain means no gameplay enchantment and zero damage. Armor basic accepts
Protection I+ OR Unbreaking I+; advanced accepts Protection II+ OR Unbreaking II+
OR Mending I. Weapons use Sharpness I+/II+ OR Unbreaking I+/II+, with Mending I
also accepted at advanced. Ranged uses Power/Quick Charge I+/II+ as applicable,
OR Unbreaking I+/II+, adding Mending at advanced. Fishing advanced accepts
Luck of the Sea II+ OR Lure II+ OR Unbreaking II+ OR Mending I. Extra compatible
enchants do not disqualify equipment; no curse. These are eligibility rules,
not a claim that native exact-component costs can express them directly.
Book purchase candidates are exact named single-enchantment contracts; mixed
books are outside this first draft, rather than silently discarded or underpaid.

## Arithmetic audit and limitations

- ${summary.candidateQuotes} candidate quotes, each individually extendable into a complete
  unique plan; ${summary.directSameComponentPairsChecked} cross-profession
  same-component buy/sell comparisons passed. This checks every proposed pool
  candidate, not only the twelve sample plans.
- ${summary.nativeEnchantmentSupportChecks} equipment enchantment/cap checks use official generated
  1.21.11 supported-item tags, including Spears. No illegal above-max levels.
- ${summary.reverseRecipeChecks.length} applicable selected reversible conversion directions passed
  their unit-price inequality. This is NOT a full recipe-network proof.
- ${summary.largeRoundingQuotes} candidate quotes exceed10% rounding error; inspect the CSV.
  Unstackable equipment cannot fix this through bigger lots. No claim of a
  uniform10.5% realized shop margin is made.
- ${summary.unknownFarmabilityQuotes} quotes have unknown farmability coverage. No new rates were
  measured and the200k simulation was not rerun with these new prices.
- Stock bounds do not prevent multiplying buyers. Include1/8/32-villager
  scenarios, World/sleep effects, crafting work and exploration returns next.

Before implementation, audit recipe/smelting/repair/other-supplier cycles,
minimum-enchantment matching, exact metadata preservation, partial/full inventory,
native GUI discount behavior, historical raid/cure attribution and map/service
generation. No kits, teaching system, timed rerolls or advancement tree is added.
`;
fs.writeFileSync(path.join(out,'PROFESSION_CATALOG_LEGACY.md'),doc);
console.log(JSON.stringify(summary,null,2));
