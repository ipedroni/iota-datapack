"""Independently check exported XLSX contents using the Python standard library."""
import json
import math
import posixpath
import sys
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET

work = Path(__file__).resolve().parent
farmability = '--farmability' in sys.argv
out = work.parent.parent.parent / 'docs/discovery/research/outputs/01a1e661-66fd-7850-8264-8da8e32c1749' / ('economy-farmability' if farmability else 'economy-discovery')
filename = out / ('iota_economy_matrix_2026-11-19_farmability.xlsx' if farmability else 'iota_economy_discovery_2026-11-19.xlsx')
ns = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
load = lambda name: json.loads((work / name).read_text(encoding='utf-8'))
checks = []

def near(actual, expected, label):
    if expected is None:
        assert actual in (None, ''), (label, actual, expected)
    else:
        assert isinstance(actual, (int, float)) and math.isclose(actual, expected, rel_tol=1e-8, abs_tol=1e-6), (label, actual, expected)

with ZipFile(filename) as archive:
    rel = ET.fromstring(archive.read('xl/_rels/workbook.xml.rels'))
    paths = {x.attrib['Id']: posixpath.normpath(posixpath.join('xl', x.attrib['Target'])) if not x.attrib['Target'].startswith('/') else x.attrib['Target'][1:] for x in rel}
    book = ET.fromstring(archive.read('xl/workbook.xml'))
    shared = []
    if 'xl/sharedStrings.xml' in archive.namelist():
        shared = [''.join(x.itertext()) for x in ET.fromstring(archive.read('xl/sharedStrings.xml'))]
    sheets, formulas, errors = {}, 0, []
    for sheet in book.find('m:sheets', ns):
        name = sheet.attrib['name']
        rid = sheet.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']
        document = ET.fromstring(archive.read(paths[rid]))
        cells = {}
        for cell in document.findall('.//m:sheetData/m:row/m:c', ns):
            address, kind = cell.attrib['r'], cell.attrib.get('t')
            node = cell.find('m:v', ns)
            value = node.text if node is not None else None
            if kind == 'e':
                errors.append((name, address, value))
            elif kind == 's' and value is not None:
                value = shared[int(value)]
            elif kind == 'inlineStr':
                value = ''.join(cell.find('m:is', ns).itertext())
            elif kind in ('n', 'b', None) and value is not None:
                value = float(value)
            if cell.find('m:f', ns) is not None:
                formulas += 1
            cells[address] = value
        sheets[name] = cells
    assert not errors, errors
    checks.append('No cached Excel error cells across all worksheets')
    expected_names = {'Overview', 'Items', 'Activities', 'Parameters', 'Baskets', 'Recipes', 'Variants', 'Sensitivity', 'Quotes', 'PricePressure', 'Acquisition', 'Audit', 'Sources'}
    if farmability:
        expected_names.update({'Farmability', 'FarmSources'})
    assert set(sheets) == expected_names
    checks.append(f'All {len(expected_names)} expected worksheets exported')
    for row, item in enumerate(load('items.json'), 6):
        assert sheets['Items'][f'A{row}'] == item['id']
        near(sheets['Items'].get(f'F{row}'), item['value_vu'], item['id'])
        near(sheets['Items'].get(f'I{row}'), item['stack'], item['id'] + ' stack')
    checks.append('All 1505 item IDs, proposed prices, exclusions and stack limits match the model')
    for row, activity in enumerate(load('activities.json'), 6):
        assert sheets['Activities'][f'A{row}'] == activity['id']
        for col, field in [('O', 'net_vu_per_world_hour'), ('P', 'net_vu_per_active_hour'), ('R', 'relative_active_to_stage_target')]:
            near(sheets['Activities'][f'{col}{row}'], activity[field], activity['id'] + ' ' + field)
    checks.append('All 39 activity net incomes and active target ratios reconcile')
    for row, quote in enumerate(load('integer-quotes.json'), 6):
        assert sheets['Quotes'][f'A{row}'] == quote['id']
        for col, field in [('D', 'lot'), ('E', 'emerald_amount'), ('F', 'rounding_error'), ('I', 'best_single_stack_lot'), ('J', 'best_single_stack_emerald_amount'), ('K', 'best_single_stack_rounding_error')]:
            near(sheets['Quotes'].get(f'{col}{row}'), quote[field], quote['id'] + ' ' + field)
    checks.append('All 1383 simple quotes and optimized-lot snapshots reconcile')
    for row, case in enumerate(load('sensitivity.json'), 6):
        near(sheets['Sensitivity'][f'D{row}'], case['net_vu_world_hour'], case['activity'] + ' stress')
    checks.append('All 351 sensitivity formula results match independent model calculations')
    for row, case in enumerate(load('activity-price-pressure.json'), 6):
        near(sheets['PricePressure'][f'E{row}'], case['unit_vu_for_active_target_holding_other_terms_fixed'], case['activity'] + ' pressure')
    checks.append('All 39 primary-output pressure calculations reconcile')
    if farmability:
        for row, case in enumerate(load('farmability-items.json'), 6):
            near(sheets['Items'].get(f'S{row}'), case['pressure'], case['id'] + ' farmability')
            near(sheets['Items'].get(f'U{row}'), case['referenceVU'], case['id'] + ' alpha-zero candidate')
        near(sheets['Parameters']['B21'], 0, 'Default alpha must not alter reference values')
        checks.append('All 1505 farmability snapshots/candidates reconcile; alpha zero preserves original values')
    assert formulas > 10000
    checks.append('Workbook contains live formulas rather than only static results')

result = {'file': filename.name, 'checks': checks, 'worksheets': len(sheets), 'formulaCount': formulas, 'errorCells': errors, 'passed': True}
(out / 'xlsx-independent-validation.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2))
