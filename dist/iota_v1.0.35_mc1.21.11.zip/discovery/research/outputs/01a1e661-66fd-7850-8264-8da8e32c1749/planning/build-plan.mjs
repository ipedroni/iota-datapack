import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {Workbook,SpreadsheetFile} from 'file:///C:/Users/Ivan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/@oai/artifact-tool/dist/artifact_tool.mjs';

const root=path.resolve(import.meta.dirname,'../../../../../..');
const out=import.meta.dirname;
const directions='Trading Design Directions';
const rows=[];
function add(id,order,area,kind,status,task,agreed,next,depends='',source=directions){
 rows.push([id,order,area,kind,status,task,agreed,next,depends,'',source]);
}
add('T01','Now','Trading','Decision','Needs decision','Choose a discount policy for ordinary single-stack trades','Use one input stack instead of1+remainder. Nearest safe block payouts are approved.','Compare reputation/Hero effects and effective bid/ask prices before selecting the replacement policy.');
add('P01','Now','Toolsmith','Decision','Needs decision','Redistribute tool sales and purchases','One new sale and purchase per ordinary level. Copper/Iron start is useful. Too much equipment arrives too late.','Choose five ordinary sales and five purchases, with earlier specialization and a medium ingot reserve.');
add('P02','Now','Armorer','Decision','Needs decision','Redistribute armor and material offers','All catalogs remain reviewable. Armorer buys more ingots and sells fewer than the other smiths.','Choose essential early pieces, earlier useful upgrades and a smaller equipment catalog.');
add('P03','Now','Weaponsmith','Decision','Needs decision','Redistribute weapon and material offers','One new sale and purchase per level. Weaponsmith buys fewer ingots and retains more for sale.','Choose weapon families, upgrade timing and material offers without redundant equipment.');
add('P04','Now','Fletcher','Decision','Needs decision','Review ammunition and ranged equipment','The current catalog is a proposal. One new sale and purchase per ordinary level.','Review Bow/Crossbow, ammunition and enchanted-purchase timing under the smaller budget.');
add('P05','Now','Leatherworker','Decision','Needs decision','Review leather equipment and supplies','Alternative Leather/Hide recipes exist. Current trades remain proposals.','Select useful equipment, materials and cosmetic offers without filling levels with similar pieces.');
add('P06','Now','Farmer','Decision','Needs decision','Distribute seed and crop offers','Wheat Seeds are the fixed introductory purchase. Seed retail must be early if retained. More seed types belong in pools.','Place Wheat/Beetroot/Pumpkin/Melon seed and crop candidates within one purchase per level.');
add('P07','Now','Shepherd','Decision','Needs decision','Set the textile sale pool','String is selected for the sale pool. Beds/Paintings were questioned; a Wool/Dye/Carpet/Banner focus was proposed.','Decide Beds/Paintings explicitly and place String, colors and finished textiles by level.');
add('P08','Now','Librarian','Decision','Needs decision','Reduce enchanted-book offers','Too many enchanted books. Echo Shard is selected as a possible Secret sale.','Choose which few ordinary books remain and the Secret resource/book pool.');
add('P09','Now','Butcher','Decision','Needs decision','Review food sales and complementary purchases','Meat supply remains available. Eggs/Milk/crops support players who avoid killing passive animals.','Review foods and inputs, container costs and the proposed raw-fish outlet.');
add('P10','Now','Fisherman','Decision','Needs decision','Retain strengths while reducing the slot layout','A preferred example, not final approval. Fisherman does not buy fish.','Preserve its identity and useful choices while selecting one new sale and purchase per level.');
add('P11','Now','Cartographer','Decision','Needs decision','Review navigation services and utility items','A preferred example, not final approval. Recovery Compass pricing needs review.','Choose map/service progression and utility placement. Reprice the Recovery Compass separately in E02.');
add('P12','Now','Cleric','Decision','Needs decision','Review reagents, potions and Secret','Wind Charges and Ghast Tears are selected Secret sale candidates. Other outcomes remain proposals.','Choose the ordinary catalog and Secret draw pool, quantities and odds.');
add('P13','Now','Mason','Decision','Needs decision','Review useful bulk construction supply','A preferred example, not final approval. Flint belongs early. All rows remain reviewable.','Select core building materials, finished products and a Secret pool under the smaller slot budget.');
add('R01','Now','Regional trade','Research','To research','Build the biome and product-family preference matrix','Regional framework is selected. Existing research is a qualitative candidate palette.','Compare resource scarcity, useful imports and cultural preferences before assigning profession pools.','', 'Regional trade candidates');
add('R02','Now','Regional trade','Research','To research','Study neighboring biomes and practical resource distance','Biome identity alone does not establish distance or scarcity in a particular world.','Define distances and sample-world measurements, then assess what a datapack can detect safely.','R01','Regional trade candidates');
add('R03','Now','Regional trade','Decision','Needs decision','Define settlement and commercial-region identity','Villager appearance, jobsite biome and item origin are different. Career plans must remain persistent.','Choose the region reference and rules for village membership, moving merchants and boundary changes.','R01');
add('R04','Now','Regional trade','Decision','Needs decision','Select regional counts, unlocks and product pools','Add1–2 local sales and1–2 foreign purchases per applicable region. Draw once and avoid duplicates.','Choose exact counts and stages, then local/foreign pools by profession. Preserve Fisherman restrictions.','R01, P01–P13');
add('R05','Now','Regional trade','Decision','Needs decision','Define profitable import premiums','Regional imports are the approved exception to ordinary shop margins. No premium percentage is selected.','Set destination payouts from actual source prices, lot rounding, handling and transport costs.','R02, R04, T01');
add('R06','Now','Regional trade','Decision','Needs decision','Decide what qualifies as a foreign product','No provenance tracking exists. Plants/animals can move and reproduce locally.','Decide whether item type or verified origin matters, and handle teleportation and relocated merchants.','R03');
add('S01','Next','Secret','Decision','Needs decision','Review Secret rewards and draw odds across professions','Secret should skip some progression or ease prolonged search/grind. Netherite Scrap is the reference example.','Review every profession pool for that purpose, including stock, quantities and rare-resource alternatives.','P01–P13');
add('S02','Next','Secret','Research','To research','Specify reliable reputation and historical event records','450villager XP AND reputation>=20 AND(local raid defense OR curing that villager) is selected.','Prove village membership, event attribution, record persistence and unlock behavior before implementation.','R03');
add('S03','Next','Mending access','Decision','Needs decision','Decide when routine equipment maintenance becomes optional','Mending supply intersects Secret rewards, ordinary loot, anvil changes and optional discovery.','Choose its eligible merchant/reward sources and rarity without assuming the old Librarian draft is approved.','P08, S01','Future Directions F-015; Trading directions');
add('E01','Next','Smith stocks','Decision','Needs decision','Set exact ingot capacities for the three smiths','Armorer buys high/sells low. Toolsmith medium/medium. Weaponsmith buys low/sells high.','Compare the same ingot and refill interval. Set stock separately from transaction lot size.','P01, P02, P03');
add('E02','Next','Pricing','Decision','Needs decision','Reprice Echo Shards and Recovery Compasses together','The old32VU Echo Shard anchor drives a559E lot of2compasses. This is an estimate, not measured value.','Choose a one-compass retail quote and consistent shard, recipe and resale values.','P08, S01');
add('E03','Next','Pricing','Decision','Needs decision','Finalize lots, margins and integer prices','Prices were well received as examples. Safe nearest-block payout rounding is approved. All prices remain reviewable.','Reprice selected catalogs after discounts, single-stack encoding and regional premiums are settled.','T01, E01, E02, R05, S03');
add('E04','Next','Economy research','Research','To research','Calibrate actual labor and full investment costs','The reference Iron Farm has measured production but only modeled partial material payback.','Measure representative active work and complete setup/transport/selling effort for calibration.','', 'Economy discovery; Iron Farm benchmark');
add('E05','Next','Economy research','Validation','To validate','Simulate the revised individual-stock economy','The first200k journeys are complete, but use older stock/price assumptions. Shared demand is rejected.','Update inputs and test1/8/32buyers, sleep, import routes, farm scaling and zero-work cycles.','E03, E04, R06','Farmability and simulation');
add('C01','Next','Trades prototype','Research','To research','Prove enchantment eligibility in native offers','Native ItemCost uses exact component predicates. Minimum/OR conditions and extra enchants are not implemented.','Prototype safe matching without rejecting higher levels or altering item identity.','P01, P02, P03','Toolsmith Template');
add('C02','After review','Catalog sources','Implementation','To do','Regenerate compact ordinary catalogs and synchronize the preview','Current generated data/HTML still show older slot counts and1+remainder inputs.','Apply reviewed catalogs, single-stack lots, current approvals and selected Secret pools together.','P01–P13, T01, E03');
add('C03','After review','Trades runtime','Implementation','To do','Implement persistent career and offer state','No Trades runtime exists. No rerolls, duplicates, stock resets or transactional item loss are allowed.','Prototype one complete merchant with sales-first ordering and safe promotions/save/reload.','C01, C02');
add('C04','After review','Trades runtime','Implementation','To do','Implement and validate replenishment and sleep','60loaded-minute ordinary/120minute Secret timers and bounded sleep credit are working calibrations.','Validate selected timing with World on/off and prevent repeated-sleep/refill abuse.','C03');
add('C05','After review','Trades runtime','Implementation','To do','Implement Secret and regional features','Unlock conditions and regional framework are selected, but their runtime does not exist.','Add tested historical records, region behavior and persistent random pools.','S02, R04, R05, R06, C03');
add('B01','Independent','Tool Mastery','Research','To research','Protect all player tools, weapons and armor safely','Rollout approved. Only the opt-in Diamond Pickaxe fixture is proven for native wear<=2.','Prototype pre-destruction interception for large wear events and identify the exact source item.','', 'Broken Tool Prototype; Expansion Status');
add('B02','Independent','Tool Mastery','Implementation','To do','Automatically unequip broken armor without loss','Automatic unequip is required when armor becomes Broken.','Handle full inventory, simultaneous pieces, owner-safe overflow and data-preserving repair/restore.','B01','Broken Tool Prototype');
add('B03','Independent','Tool Mastery','Validation','To validate','Test complete Broken and repair cycles','Name, enchantments, lore, mastery and unrelated data must survive.','Test weapon/utility families, armor, both hands, swaps, high damage, reloads and full inventories.','B01, B02','Broken Tool Prototype; Test Checklist');
add('B04','Later','Tools repair','Research','To research','Investigate one material restoring full durability','Requested repair direction remains unresolved. Native repairable changes material, not the25%fraction.','Prototype a custom repair interaction and decide whether it fits the intended anvil workflow.','B01','Future Directions F-020; Anvil Behavior');
add('V01','Independent','Tools curses','Validation','To validate','Validate base curse removal in player inventory flows','Base policy is staged. Native direct book/tool cleanup preserves other data.','Test pickup, existing inventory, equipped gear, trade books and container withdrawal in Minecraft.','', 'Changelog1.0.35; Test Checklist');
add('V02','Independent','Drops metals','Validation','To validate','Verify player-credit and Looting metal drops','Source is staged. Analytical expectations and native no-player sampling passed.','Check credited kills, no credit and Looting0–III. Preserve the selected unchanged equipment salvage.','', 'Changelog1.0.35; Metal drop tests');
add('L01','Later','Loot design','Decision','Needs decision','Review equipment, treasure and enchanted-book loot','Selected broad design follow-up. New Secret access may change resource scarcity.','Review loot against crafting, trade shortcuts, maintenance and optional expansions.','S01, E03','Future Directions F-024');
add('D01','Next','Documentation','Documentation','To do','Consolidate current decisions and remove superseded claims','Every profession remains reviewable. Older tables and approval labels conflict with later notes.','Replace obsolete slot layouts/approval wording and align generators, guide and preview.','P01–P13');
add('D02','After review','Validation','Validation','To validate','Verify code structure and separate manual gameplay checks','Function/reference/JSON audits exist. Minecraft loading need not be repeated for every ZIP.','Run affected automated checks and update concise player commands/checklists after changes.','C03, C04, C05, B03');
add('D03','After review','Delivery','Delivery','Deferred','Package selected changes after review and validation','Base1.0.35 is staged; shipped base is1.0.34. Existing expansion ZIPs remain0.0.1. ZIP updates are deferred.','Choose release scope/version, then build installable ZIPs, changelog and test checklist.','D02, V01, V02','Changelog; Expansion Status');

assert.equal(new Set(rows.map(r=>r[0])).size,rows.length);
const dependencies=new Map(rows.map(r=>[r[0],r[8].replace('P01–P13',Array.from({length:13},(_,i)=>'P'+String(i+1).padStart(2,'0')).join(',')).split(',').map(s=>s.trim()).filter(Boolean)]));
const visited=new Set(),visiting=new Set();
function checkDependencies(id){assert(dependencies.has(id),'Unknown dependency '+id);assert(!visiting.has(id),'Circular task dependency '+id);if(visited.has(id))return;visiting.add(id);for(const dep of dependencies.get(id))checkDependencies(dep);visiting.delete(id);visited.add(id);}
for(const id of dependencies.keys())checkDependencies(id);
const futureText=(await fs.readFile(path.join(root,'docs/future_directions.md'),'utf8')).replaceAll('\r\n','\n');
const groups=new Map([...futureText.matchAll(/^## (\d+)\. (.+)$/gm)].map(m=>[Number(m[1]),m[2]]));
const excluded=new Set(['D-005','F-005','F-008','F-015','F-020','F-024']);
const future=[];
let group=0;
for(const part of futureText.split(/(?=^## |^### )/m)){
 const g=part.match(/^## (\d+)\./);if(g){group=Number(g[1]);continue;}
 const m=part.match(/^### ([FD]-\d+) — (.+)/);if(!m||excluded.has(m[1]))continue;
 const state=part.match(/\*\*State:\*\* (.*?)\. \*\*Owner:\*\* (.*?)\./s);
 const body=part.replace(/^###[^\n]*\n/,'').replace(/\*\*State:[\s\S]*?\n\n/,'').replace(/\*\*Design tags:[\s\S]*?\n\n/,'').trim().split(/\n\n/).map(x=>x.replace(/\n/g,' '));
 let status=m[1]==='F-010'?'Frozen':'Deferred';
 const trigger={
  'F-001':'After basic profession catalogs and native transaction safety',
  'F-002':'After stable settlement identity and ownership tracking',
  'F-003':'After testing buyer multiplication and anti-confinement goals',
  'F-004':'After the basic individual-stock economy is validated',
  'F-006':'Only if persistent-catalog rules are explicitly revisited',
  'F-007':'After the Toolsmith/basic profession review',
  'F-009':'After basic merchant catalogs and delivery ownership are stable',
  'F-010':'When Magical Discovery development is explicitly resumed',
  'F-026':'After the gameplay journey has settled'
 }[m[1]]||'Revisit after the active catalog/economy work';
 future.push([m[1],groups.get(group)||String(group),state?.[2]||'',status,m[2],body.join(' '),trigger,'','Future Directions '+m[1]]);
}
assert(!future.some(r=>excluded.has(r[0])));
// Keep original backlog evidence in the source column; no discarded shared
// demand proposal is promoted into a pending action.
const workbook=Workbook.create(),main=workbook.worksheets.add('Next steps'),back=workbook.worksheets.add('Future');
const colors={header:'#314B40',ink:'#24312B',line:'#D7DFD9',edit:'#FFF2CC',stripe:'#F3F6F4',muted:'#5D6D63'};
function sheetBase(sheet,title,headers,data,widths){
 const end=9+data.length,col=String.fromCharCode(64+headers.length);
 sheet.showGridLines=false;sheet.getRange(`A1:${col}${end}`).format.font={name:'Arial',size:11,color:colors.ink};
 sheet.getRange('A2').values=[['Iota']];sheet.getRange('B2').values=[[sheet.name==='Next steps'?'Next steps':'Deferred proposals']];sheet.getRange('A2:B2').format.font={name:'Arial',size:16,bold:true,color:colors.header};
 sheet.getRange('I2').values=[['As of']];sheet.getRange('J2').values=[[new Date('2026-11-20T12:00:00Z')]];sheet.getRange('J2').setNumberFormat('yyyy-mm-dd');
 sheet.getRange(`A3:${col}3`).format.borders={bottom:{style:'thin',color:colors.line}};
 sheet.getRange(`A9:${col}9`).values=[headers];sheet.getRange(`A10:${col}${end}`).values=data;
 const table=sheet.tables.add(`A9:${col}${end}`,true,sheet.name==='Next steps'?'IotaNextSteps':'IotaFuture');table.style='TableStyleLight1';table.showFilterButton=true;
 sheet.getRange(`A9:${col}9`).format={fill:colors.header,font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',verticalAlignment:'center',wrapText:true,rowHeight:32};
 sheet.getRange(`A10:${col}${end}`).format.verticalAlignment='top';sheet.getRange(`A10:${col}${end}`).format.wrapText=true;
 for(let i=0;i<widths.length;i++)sheet.getRange(`${String.fromCharCode(65+i)}1:${String.fromCharCode(65+i)}${end}`).format.columnWidthPx=widths[i];
 for(let i=0;i<data.length;i++){
  const height=Math.max(66,...data[i].map((s,j)=>Math.ceil(String(s).length/Math.max(10,(widths[j]-16)/7))*18+18));
  sheet.getRange(`A${i+10}:${col}${i+10}`).format.rowHeightPx=height;
  if(i%2===1)sheet.getRange(`A${i+10}:${col}${i+10}`).format.fill=colors.stripe;
 }
 sheet.freezePanes.freezeRows(9);sheet.freezePanes.freezeColumns(3);
 return end;
}
const headers=['ID','Sequence','Area','Work type','State','Task or decision','Established direction','Next action','Depends on','Decision notes','Source'];
const end=sheetBase(main,'Iota next actions and decisions',headers,rows,[75,108,145,110,128,280,335,315,135,270,230]);
main.tabColor=colors.header;
main.getRange('A4').values=[['Items']];main.getRange('B4').formulas=[[`=COUNTIFS(E10:E${end},"<>Done")`]];
main.getRange('D4').values=[['Decisions']];main.getRange('E4').formulas=[[`=COUNTIFS(E10:E${end},"Needs decision")`]];
main.getRange('G4').values=[['To validate']];main.getRange('H4').formulas=[[`=COUNTIFS(E10:E${end},"To validate")`]];
main.getRange('A6').values=[['Edit State and Decision notes. All profession catalogs remain under review. Sequence is suggested, not a deadline.']];
main.getRange('A6').format.font={name:'Arial',size:11,color:colors.muted};
const states=['Needs decision','To do','To research','To validate','Deferred','Done'];
main.getRange(`E10:E${end}`).dataValidation={rule:{type:'list',values:states}};
main.getRange(`E10:E${end}`).format.fill=colors.edit;main.getRange(`J10:J${end}`).format.fill=colors.edit;
main.getRange(`E10:E${end}`).conditionalFormats.add('containsText',{text:'Done',format:{fill:'#E5EFE8',font:{color:'#365A42'}}});
const futureHeaders=['ID','Theme group','Owner or module','State','Proposal','Open scope','Revisit after','Decision notes','Source'];
const futureEnd=sheetBase(back,'Iota deferred proposals',futureHeaders,future,[75,200,155,110,280,490,280,270,205]);
back.getRange('A4').values=[['Items']];back.getRange('B4').formulas=[[`=COUNTA(A10:A${futureEnd})`]];
back.getRange('D4').values=[['Frozen']];back.getRange('E4').formulas=[[`=COUNTIFS(D10:D${futureEnd},"Frozen")`]];
back.getRange('A6').values=[['Grouped by thematic similarity from Future Directions, not implementation priority. No rejected shared-demand task.']];
back.getRange('A6').format.font={name:'Arial',size:11,color:colors.muted};
back.getRange(`D10:D${futureEnd}`).dataValidation={rule:{type:'list',values:['Deferred','Frozen','Needs decision','Done']}};
back.getRange(`D10:D${futureEnd}`).format.fill=colors.edit;back.getRange(`H10:H${futureEnd}`).format.fill=colors.edit;
// The Future tab has no J column in its table; retain the same date position
// intentionally above the table without formatting an extra body column.
back.getRange('J2').format.columnWidthPx=110;
workbook.recalculate();
assert.equal(main.getRange('B4').values[0][0],rows.length);
assert.equal(main.getRange('E4').values[0][0],rows.filter(r=>r[4]==='Needs decision').length);
// Exercise the actual editable workflow, then restore the original snapshot.
const original=main.getRange('E10').values[0][0];main.getRange('E10').values=[['Done']];workbook.recalculate();
assert.equal(main.getRange('B4').values[0][0],rows.length-1);main.getRange('E10').values=[[original]];workbook.recalculate();
console.log((await workbook.inspect({kind:'table',range:'Next steps!A4:H4',include:'values,formulas',tableMaxRows:1,tableMaxCols:8,maxChars:1200})).ndjson);
const errorScan=await workbook.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:20},maxChars:1000});
await fs.writeFile(path.join(out,'formula-check.ndjson'),errorScan.ndjson);
for(const [sheetName,file,range] of process.argv.includes('--skip-render')?[]:[['Next steps','next-steps-preview.png','A1:H15'],['Future','future-preview.png','A1:G14']]){
 const image=await workbook.render({sheetName,range,scale:1,format:'png'});await fs.writeFile(path.join(out,file),new Uint8Array(await image.arrayBuffer()));
}
const xlsx=await SpreadsheetFile.exportXlsx(workbook);const filename=path.join(out,'iota_next_steps_2026-11-20.xlsx');await xlsx.save(filename);
await fs.writeFile(path.join(out,'plan-source.json'),JSON.stringify({asOf:'2026-11-20',activeRows:rows,futureRows:future},null,2));
console.log(JSON.stringify({file:filename,actions:rows.length,future:future.length,needsDecision:rows.filter(r=>r[4]==='Needs decision').length,editableWorkflowTest:'passed'}));
