"""Build compact, source-priced, constrained examples for the local trade preview."""
import concurrent.futures
import copy
import json
import random
import urllib.request
from pathlib import Path

root = Path(__file__).resolve().parents[4]
output = Path(__file__).resolve().parent
data = json.loads((output / 'catalogs.json').read_text())['professions']
smith = json.loads((root / 'docs/discovery/research/outputs/toolsmith-template-2026-11-19/template.json').read_text())
stages = ['Novice', 'Apprentice', 'Journeyman', 'Expert', 'Master', 'Secret']

def raw(name, direction):
    a = next(x for x in smith['raw'] if x['id'] == 'minecraft:' + name)
    p = a['ask' if direction == 'sell' else 'bid']
    payment = ([{'item': p['id'].split(':')[1], 'count': p['count']}] if direction == 'buy'
               else [{'item': x['id'].split(':')[1], 'count': x['count']} for x in [p['a'], p['b']] if x])
    cap = a['sellCap' if direction == 'sell' else 'buyCap']
    return dict(id=a['id'], lot=a['lot'], price={'value': p['emeralds'], 'payment': payment},
                stockUnits=cap, uses=cap//a['lot'], referenceVU=a['vu'])

def gear(materials, families, direction='sell', quality=None, levels=None, secret=False):
    result = []
    for a in smith['gear']:
        name = a['id'].split(':')[1]
        material, family = name.split('_', 1)
        if material not in materials or family not in families:
            continue
        e, level = a['enchantment'], a['level']
        if direction == 'buy':
            contract = a['contracts'].get(quality)
            if not contract:
                continue
            # One broad purchase contract per item, not a different payout per
            # enchantment example. Preserve the accepted-minimum display label.
            if any(x['id'] == a['id'] for x in result):
                continue
            q = dict(id=a['id'], quality={'journeyman':'plain','expert':'tool-basic','master':'tool-advanced'}[quality],
                     lot=1, stockUnits=2, uses=2, referenceVU=a['baseVU']+{'journeyman':0,'expert':8,'master':16}[quality],
                     price={'value':contract['emeralds'],'payment':[{'item':contract['id'].split(':')[1],'count':contract['count']}]})
        else:
            if levels is None and e is not None:
                continue
            if levels is not None:
                if e not in levels or level not in levels[e]:
                    continue
            p=a['ask']
            q=dict(id=a['id'], enchantment=e, level=level, lot=1, stockUnits=1 if secret else 2,
                   uses=1 if secret else 2, referenceVU=a['priceVU'],price={'value':p['emeralds'],
                   'payment':[{'item':x['id'].split(':')[1],'count':x['count']} for x in [p['a'],p['b']] if x]})
        result.append(q)
    return result

families=['pickaxe','axe','shovel','hoe']
smith_rows=[]
def row(stage, sales, purchases):
    smith_rows.append({'stage':stage,'sales':[{'candidates':a} for a in sales],
                       'purchases':[{'candidates':a} for a in purchases]})
early=[dict(a,weight=75 if ':copper_' in a['id'] else 25) for a in gear(['copper','iron'],families)]
row('Novice',[early,early],[[raw('flint','buy')],[raw(x,'buy') for x in ['coal','charcoal']]])
row('Apprentice',[early,early],[[raw(x,'buy') for x in ['coal','charcoal']], [raw(x,'buy') for x in ['copper_ingot','iron_ingot']]])
row('Journeyman',[[raw(x,'sell') for x in ['copper_ingot','iron_ingot']],gear(['iron','golden'],families)],
    [gear(['copper','iron'],families,'buy','journeyman'),[raw(x,'buy') for x in ['iron_ingot','gold_ingot']]])
expert=gear(['golden','diamond'],families)+gear(['golden','diamond'],families,levels={'efficiency':[1,2],'unbreaking':[1,2]})
expert=[dict(a,weight=.5 if not a.get('enchantment') else .125) for a in expert]
row('Expert',[[raw(x,'sell') for x in ['iron_ingot','gold_ingot']],expert],
    [gear(['iron','golden'],families,'buy','expert'),[raw(x,'buy') for x in ['gold_ingot','diamond']]])
master=gear(['golden','diamond'],families,levels={'efficiency':[1,2,3],'unbreaking':[1,2,3],'fortune':[1,2,3],'silk_touch':[1]})
master=[dict(a,weight=1 if a['enchantment']=='silk_touch' else {1:.2,2:.5,3:.3}[a['level']]) for a in master]
row('Master',[master,master],[gear(['golden','diamond'],families,'buy','master')])
secret=[dict(raw('diamond','sell'),weight=45),dict(raw('netherite_scrap','sell'),weight=5)]
for mat,w in [('diamond',45),('netherite',5)]:
    candidates=gear([mat],families,levels={'efficiency':[3,4,5],'unbreaking':[3],'fortune':[3],'silk_touch':[1]},secret=True)
    secret.extend(dict(a,weight=w*({3:.5,4:.35,5:.15}[a['level']] if a['enchantment']=='efficiency' else 1)/16) for a in candidates)
row('Secret',[secret],[])
data.insert(0,{'id':'toolsmith','rows':smith_rows})

all_quotes=[]
professions=[]
def identity(a):
    return tuple(str(a.get(k,'')) for k in ['id','enchantment','level','quality','potion','stew','destination','banner','dye'])

for profession in data:
    slots=[]
    for r in profession['rows']:
        for direction,field in [('sell','sales'),('buy','purchases')]:
            for s in r[field]:
                ids=[]
                for a in s['candidates']:
                    q={k:a[k] for k in ['id','enchantment','level','quality','potion','stew','destination','banner','dye','lot','price','stockUnits','uses','referenceVU','weight'] if k in a}
                    q.update(stage=r['stage'],direction=direction)
                    ids.append(len(all_quotes));all_quotes.append(q)
                slots.append(dict(stage=r['stage'],direction=direction,candidates=ids))
    samples=[]
    for sample in range(4):
        rng=random.Random(profession['id']+str(sample));seen={'sell':set(),'buy':set()};early_families=set();purchased=set();chosen=[]
        def solve(i):
            if i==len(slots):return True
            slot=slots[i]
            candidates=sorted(slot['candidates'],key=lambda n:rng.random()**(1/max(.001,all_quotes[n].get('weight',1))),reverse=True)
            for idx in candidates:
                a=all_quotes[idx];key=identity(a)
                if key in seen[slot['direction']]:continue
                family=None;purchase=None
                if profession['id'] in ['toolsmith','armorer','leatherworker'] and slot['direction']=='sell' and slot['stage'] in ['Novice','Apprentice']:
                    family=a['id'].split('_')[-1]
                    if family in early_families:continue
                if slot['direction']=='buy' and a.get('quality') and (profession['id'] in ['toolsmith','armorer','leatherworker'] or profession['id'] in ['weaponsmith','fletcher'] and slot['stage']!='Journeyman'):
                    purchase=a['id'].split('_')[-1]
                    if purchase in purchased:continue
                seen[slot['direction']].add(key)
                if family:early_families.add(family)
                if purchase:purchased.add(purchase)
                chosen.append(idx)
                if solve(i+1):return True
                chosen.pop();seen[slot['direction']].remove(key)
                if family:early_families.remove(family)
                if purchase:purchased.remove(purchase)
            return False
        assert solve(0),profession['id']
        chosen.sort(key=lambda n:0 if all_quotes[n]['direction']=='sell' else 1)
        assert len(chosen)==20
        samples.append(chosen)
    professions.append({'id':profession['id'],'samples':samples,'slots':slots})

names={a['id'].split(':')[1] for a in all_quotes}|{'emerald','emerald_block'}
base='https://cdn.jsdelivr.net/gh/InventivetalentDev/minecraft-assets@1.21.11/assets/minecraft/textures/'
special={'crossbow':'crossbow_standby','compass':'compass_16','recovery_compass':'recovery_compass_16','clock':'clock_00','fishing_rod':'fishing_rod','potion':'potion','tipped_arrow':'tipped_arrow_base'}
block_alias={'glass_pane':'glass','hay_block':'hay_block_side','white_carpet':'white_wool','red_carpet':'red_wool','blue_carpet':'blue_wool','yellow_carpet':'yellow_wool','terracotta':'terracotta','amethyst_block':'amethyst_block','melon':'melon_side','pumpkin':'pumpkin_side','quartz_block':'quartz_block_side'}
def exists(url):
    try:
        req=urllib.request.Request(url,method='HEAD',headers={'User-Agent':'Iota-trade-preview'})
        with urllib.request.urlopen(req,timeout=12) as response:return response.status==200 and 'image' in response.headers.get('Content-Type','')
    except Exception:return False
def icon(name):
    if name.endswith('_bed'):return name,{'kind':'bed','url':base+'block/'+name.replace('_bed','_wool')+'.png'}
    if name.endswith('_banner'):return name,{'kind':'banner','url':base+'block/'+name.replace('_banner','_wool')+'.png'}
    for part in [special.get(name,name),name]:
        u=base+'item/'+part+'.png'
        if exists(u):return name,{'kind':'item','url':u}
    part=block_alias.get(name,name)
    u=base+'block/'+part+'.png'
    if exists(u):return name,{'kind':'block','url':u}
    # Native plants can use their placed texture without turning into cubes.
    u=base+'block/'+part+'_stage0.png'
    if exists(u):return name,{'kind':'item','url':u}
    return name,{'kind':'missing','url':base+'item/barrier.png'}
previous=output/'preview-data.json'
cache=json.loads(previous.read_text()).get('icons',{}) if previous.exists() else {}
pending=[n for n in sorted(names) if n not in cache or cache[n]['kind']=='missing']
with concurrent.futures.ThreadPoolExecutor(max_workers=12) as executor:
    icons={**cache,**dict(executor.map(icon,pending))}
payload={'professions':professions,'quotes':all_quotes,'icons':icons}
(output/'preview-data.json').write_text(json.dumps(payload,separators=(',',':')))
print(json.dumps({'professions':len(professions),'quotes':len(all_quotes),'iconCount':len(icons),'missing':[n for n,v in icons.items() if v['kind']=='missing'],'bytes':(output/'preview-data.json').stat().st_size}))
