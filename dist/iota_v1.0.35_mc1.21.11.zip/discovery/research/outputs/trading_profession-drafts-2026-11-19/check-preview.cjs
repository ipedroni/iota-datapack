const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url');
const {chromium}=require('C:/Users/Ivan/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const options={headless:true};
 const installed=['C:/Program Files/Google/Chrome/Application/chrome.exe','C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'].find(p=>fs.existsSync(p));
 if(installed)options.executablePath=installed;
 const browser=await chromium.launch(options);
 try{
  const page=await browser.newPage({viewport:{width:768,height:1100}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto(pathToFileURL(path.join(__dirname,'trade-preview-check.html')).href);
  await page.frameLocator('iframe').locator('#iota-profession').waitFor();
  const frame=page.frames().find(f=>f!==page.mainFrame());
  const select=(id,v)=>frame.locator('#iota-'+id).selectOption(String(v));
  const names=await frame.locator('#iota-profession option').evaluateAll(xs=>xs.map(x=>x.value));
  assert.equal(names.length,13);
  let selections=0;
  for(const id of names){
   await select('profession',id);
   for(let stage=0;stage<=5;stage++){
    await select('stage',stage);
    const count=await frame.locator('#iota-offers button').count();
    assert.equal(count,[4,8,12,16,19,20][stage],id+' stage '+stage);selections++;
   }
  }
  const target=await frame.evaluate(()=>{
   const d=JSON.parse(document.getElementById('iota-trade-data').textContent);
   for(const p of d.professions)for(let sample=0;sample<4;sample++)for(const n of p.samples[sample]){
    const q=d.quotes[n];if(q.direction==='buy'&&q.price.payment.some(x=>x.item==='emerald_block'))return {profession:p.id,sample,n,value:q.price.value};
   }
  });
  assert(target);await select('profession',target.profession);await select('sample',target.sample);await select('stage',5);
  await frame.locator(`[data-quote="${target.n}"]`).click();
  assert((await frame.locator('#iota-equivalent').innerText()).includes('= '+target.value+' emeralds'));
  assert((await frame.locator('#iota-game-title').innerText()).endsWith('— Master'));
  await select('profession','toolsmith');await select('sample',0);await select('stage',4);
  await frame.evaluate(()=>document.fonts.ready);
  await frame.waitForFunction(()=>[...document.querySelectorAll('#iota-trade-flow img')].every(x=>x.complete&&x.naturalWidth>0));
  const folder='C:/Users/Ivan/.codex/visualizations/2026/11/16/01a1e661-66fd-7850-8264-8da8e32c1749';
  await page.locator('iframe').screenshot({path:path.join(folder,'iota-trades-desktop.png')});
  await page.setViewportSize({width:360,height:1700});
  await frame.waitForFunction(()=>document.getElementById('iota-villager-preview').getBoundingClientRect().width<400);
  assert(await frame.evaluate(()=>document.documentElement.scrollWidth<=document.documentElement.clientWidth+1));
  await page.locator('iframe').screenshot({path:path.join(folder,'iota-trades-mobile.png')});
  assert.deepEqual(errors,[]);
  const result={passed:true,professions:13,levelSelections:selections,blockPayoutEquivalent:true,secretTitleRemainsMaster:true,mobileHorizontalOverflow:false,javascriptErrors:errors};
  fs.writeFileSync(path.join(__dirname,'preview-validation.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
