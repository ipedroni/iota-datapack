advancement revoke @s only iota_armor_poc:break_chest
data remove storage iota_armor_poc:scratch item
execute store success score #copied iota_apoc run data modify storage iota_armor_poc:scratch item set from entity @s equipment.chest
execute unless score #copied iota_apoc matches 1 run return 0
function iota_armor_poc:break_common {slot:"armor.chest"}
