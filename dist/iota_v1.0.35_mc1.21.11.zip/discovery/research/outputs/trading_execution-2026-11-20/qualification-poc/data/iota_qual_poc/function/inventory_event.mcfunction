execute at @s if entity @e[type=minecraft:villager,tag=iota_qual_poc_merchant,distance=..8] run function iota_qual_poc:refresh
advancement revoke @s only iota_qual_poc:inventory_event
