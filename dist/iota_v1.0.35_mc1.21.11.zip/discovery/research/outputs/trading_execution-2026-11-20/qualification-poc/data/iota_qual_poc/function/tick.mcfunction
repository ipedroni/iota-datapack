execute as @a unless score @s iota_qbusy matches 0..1 run scoreboard players set @s iota_qbusy 0
execute as @a at @s unless entity @e[type=minecraft:villager,tag=iota_qual_poc_merchant,distance=..8] run function iota_qual_poc:cleanup
execute as @e[type=minecraft:item] if items entity @s contents #iota_qual_poc:equipment[minecraft:note_block_sound="iota_qual_poc:plain",minecraft:map_color=1091328] run item modify entity @s contents iota_qual_poc:cleanup
execute as @e[type=minecraft:item] if items entity @s contents #iota_qual_poc:equipment[minecraft:note_block_sound="iota_qual_poc:plain",minecraft:map_color=1091329] run item modify entity @s contents iota_qual_poc:cleanup
execute as @e[type=minecraft:item] if items entity @s contents #iota_qual_poc:equipment[minecraft:note_block_sound="iota_qual_poc:basic",minecraft:map_color=1091328] run item modify entity @s contents iota_qual_poc:cleanup
execute as @e[type=minecraft:item] if items entity @s contents #iota_qual_poc:equipment[minecraft:note_block_sound="iota_qual_poc:basic",minecraft:map_color=1091329] run item modify entity @s contents iota_qual_poc:cleanup
execute as @e[type=minecraft:item] if items entity @s contents #iota_qual_poc:equipment[minecraft:note_block_sound="iota_qual_poc:other",minecraft:map_color=1091328] run item modify entity @s contents iota_qual_poc:cleanup
execute as @e[type=minecraft:item] if items entity @s contents #iota_qual_poc:equipment[minecraft:note_block_sound="iota_qual_poc:other",minecraft:map_color=1091329] run item modify entity @s contents iota_qual_poc:cleanup
