summon minecraft:item ~ ~0.5 ~ {Tags:["iota_armor_restore_buffer"],Invulnerable:1b,NoGravity:1b,PickupDelay:32767s,Item:{id:"minecraft:stone",count:1}}
$item replace entity @e[type=minecraft:item,tag=iota_armor_restore_buffer,limit=1,sort=nearest,distance=..2] contents from entity @s $(slot)
data modify storage iota_armor_poc:scratch item set from entity @e[type=minecraft:item,tag=iota_armor_restore_buffer,limit=1,sort=nearest,distance=..2] Item
data remove storage iota_armor_poc:scratch item.components."!minecraft:equippable"
execute if data storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."minecraft:equippable" run data modify storage iota_armor_poc:scratch item.components."minecraft:equippable" set from storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."minecraft:equippable"
execute if data storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."!minecraft:equippable" run data modify storage iota_armor_poc:scratch item.components."!minecraft:equippable" set value {}
data remove storage iota_armor_poc:scratch item.components."!minecraft:attribute_modifiers"
execute if data storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."minecraft:attribute_modifiers" run data modify storage iota_armor_poc:scratch item.components."minecraft:attribute_modifiers" set from storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."minecraft:attribute_modifiers"
execute if data storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."!minecraft:attribute_modifiers" run data modify storage iota_armor_poc:scratch item.components."!minecraft:attribute_modifiers" set value {}
execute store result score #had_data iota_apoc run data get storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.had_data
data remove storage iota_armor_poc:scratch item.components."minecraft:lore"[{translate:"iota.status.broken"}]
execute store result score #lore_size iota_apoc run data get storage iota_armor_poc:scratch item.components."minecraft:lore"
execute if score #lore_size iota_apoc matches 0 if data storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc{had_lore:0b} run data remove storage iota_armor_poc:scratch item.components."minecraft:lore"
data remove storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc
execute store result score #data_size iota_apoc run data get storage iota_armor_poc:scratch item.components."minecraft:custom_data"
execute if score #data_size iota_apoc matches 0 if score #had_data iota_apoc matches 0 run data remove storage iota_armor_poc:scratch item.components."minecraft:custom_data"
data modify entity @e[type=minecraft:item,tag=iota_armor_restore_buffer,limit=1,sort=nearest,distance=..2] Item set from storage iota_armor_poc:scratch item
$item replace entity @s $(slot) from entity @e[type=minecraft:item,tag=iota_armor_restore_buffer,limit=1,sort=nearest,distance=..2] contents
kill @e[type=minecraft:item,tag=iota_armor_restore_buffer,distance=..2]
