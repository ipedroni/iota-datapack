# Source slot is fixed by native armor family; no nearest-item or hand guess.
execute store success score #had_data iota_apoc run data get storage iota_armor_poc:scratch item.components."minecraft:custom_data"
execute store success score #had_lore iota_apoc run data get storage iota_armor_poc:scratch item.components."minecraft:lore"
data modify storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc set value {broken:1b,saved:{}}
execute store result storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.had_data byte 1 run scoreboard players get #had_data iota_apoc
execute store result storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.had_lore byte 1 run scoreboard players get #had_lore iota_apoc
execute if data storage iota_armor_poc:scratch item.components."minecraft:equippable" run data modify storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."minecraft:equippable" set from storage iota_armor_poc:scratch item.components."minecraft:equippable"
execute if data storage iota_armor_poc:scratch item.components."!minecraft:equippable" run data modify storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."!minecraft:equippable" set value {}
data remove storage iota_armor_poc:scratch item.components."minecraft:equippable"
data modify storage iota_armor_poc:scratch item.components."!minecraft:equippable" set value {}
execute if data storage iota_armor_poc:scratch item.components."minecraft:attribute_modifiers" run data modify storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."minecraft:attribute_modifiers" set from storage iota_armor_poc:scratch item.components."minecraft:attribute_modifiers"
execute if data storage iota_armor_poc:scratch item.components."!minecraft:attribute_modifiers" run data modify storage iota_armor_poc:scratch item.components."minecraft:custom_data".iota_armor_poc.saved."!minecraft:attribute_modifiers" set value {}
data remove storage iota_armor_poc:scratch item.components."minecraft:attribute_modifiers"
data modify storage iota_armor_poc:scratch item.components."!minecraft:attribute_modifiers" set value {}
execute unless data storage iota_armor_poc:scratch item.components."minecraft:lore" run data modify storage iota_armor_poc:scratch item.components."minecraft:lore" set value []
data modify storage iota_armor_poc:scratch item.components."minecraft:lore" append value {translate:"iota.status.broken",fallback:"Broken",color:"red",italic:0b}
summon minecraft:item ~ ~0.5 ~ {Tags:["iota_armor_buffer"],Invulnerable:1b,NoGravity:1b,PickupDelay:32767s,Item:{id:"minecraft:stone",count:1}}
data modify entity @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] Owner set from entity @s UUID
data modify entity @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] Item set from storage iota_armor_poc:scratch item
item modify entity @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] contents iota_armor_poc:full_damage
execute store success score #ready iota_apoc run data get entity @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] Item.components."minecraft:custom_data".iota_armor_poc
$execute if score #ready iota_apoc matches 1 if score #live iota_apoc matches 1 if score #different iota_apoc matches 0 run item replace entity @s $(slot) with minecraft:air
data merge entity @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] {PickupDelay:0s}
tag @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] add iota_armor_broken_drop
tag @e[type=minecraft:item,tag=iota_armor_buffer,limit=1,sort=nearest,distance=..2] remove iota_armor_buffer
