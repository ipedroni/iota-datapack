advancement revoke @s only iota_armor_poc:break_chest
data modify storage iota_armor_poc:scratch capture set value {name:"chest",slot:"armor.chest",source:"equipment.chest"}
data modify storage iota_armor_poc:scratch capture.owner set from entity @s UUID
function iota_armor_poc:capture/process with storage iota_armor_poc:scratch capture
