advancement revoke @s only iota_armor_poc:break_feet
data modify storage iota_armor_poc:scratch capture set value {name:"feet",slot:"armor.feet",source:"equipment.feet"}
data modify storage iota_armor_poc:scratch capture.owner set from entity @s UUID
function iota_armor_poc:capture/process with storage iota_armor_poc:scratch capture
