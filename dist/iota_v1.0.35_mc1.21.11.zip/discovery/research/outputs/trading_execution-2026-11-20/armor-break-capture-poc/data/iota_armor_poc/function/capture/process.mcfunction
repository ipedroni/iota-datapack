data remove storage iota_armor_poc:scratch item
$data modify storage iota_armor_poc:scratch item set from entity @s Inventory[{id:"minecraft:structure_void",components:{"minecraft:custom_data":{iota_armor_capture:{slot:"$(name)",owner:$(owner)}}}}].components."minecraft:custom_data".iota_armor_capture.original
$execute unless data storage iota_armor_poc:scratch item.id run data modify storage iota_armor_poc:scratch item set from entity @e[type=minecraft:item,nbt={Item:{id:"minecraft:structure_void",components:{"minecraft:custom_data":{iota_armor_capture:{slot:"$(name)",owner:$(owner)}}}}},limit=1] Item.components."minecraft:custom_data".iota_armor_capture.original
execute unless data storage iota_armor_poc:scratch item.id run return 0
# Only remove the live source if it is the exact item captured in this event.
data remove storage iota_armor_poc:scratch current
$execute store success score #live iota_apoc run data modify storage iota_armor_poc:scratch current set from entity @s $(source)
scoreboard players set #different iota_apoc 1
execute if score #live iota_apoc matches 1 store success score #different iota_apoc run data modify storage iota_armor_poc:scratch current set from storage iota_armor_poc:scratch item
scoreboard players set #ready iota_apoc 0
function iota_armor_poc:break_common with storage iota_armor_poc:scratch capture
$execute if score #ready iota_apoc matches 1 run clear @s minecraft:structure_void[minecraft:custom_data~{iota_armor_capture:{slot:"$(name)",owner:$(owner)}}] 1
$execute if score #ready iota_apoc matches 1 run kill @e[type=minecraft:item,nbt={Item:{id:"minecraft:structure_void",components:{"minecraft:custom_data":{iota_armor_capture:{slot:"$(name)",owner:$(owner)}}}}},limit=1]
