advancement revoke @s only iota_capture:head
data modify storage iota_capture:results actual_slot set from entity @s equipment.head
data modify storage iota_capture:results captured set from entity @s Inventory[{id:"minecraft:structure_void"}].components."minecraft:custom_data".iota_capture
