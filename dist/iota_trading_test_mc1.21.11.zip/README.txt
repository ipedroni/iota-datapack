Iota Trading test for Minecraft Java 1.21.11

Install this ZIP in the datapacks folder of a disposable world. Do not enable the experimental Villager Trade Rebalance for this test.

With commands enabled, use /function iota_trades:production/test_spawn
This creates a new test villager. Give it the workstation for the profession you want to try, and step away from its interaction area briefly so the initial offers can publish. Existing and untagged villagers keep their vanilla or previously saved data.

The test covers runtime draws for the 13 approved professions. Regional trade is deferred. Current prices and restock timing are provisional. Cartographer structure searches may still delay a tick, especially in unexplored terrain.