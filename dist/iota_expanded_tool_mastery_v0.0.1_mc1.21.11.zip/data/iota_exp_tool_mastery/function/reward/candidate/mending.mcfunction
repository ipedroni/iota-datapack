execute if data storage iota_tool_mastery:progress stack.components."minecraft:enchantments"."minecraft:infinity" run return 0
$return run function iota_exp_tool_mastery:reward/eligible {enchant:"$(enchant)",min:$(min),max:$(max),weight:$(weight),pool:"$(pool)"}
