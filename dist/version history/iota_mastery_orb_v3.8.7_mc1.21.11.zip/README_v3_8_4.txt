POC v3.8.4 - Minecraft Java 1.21.11

Changes:
- Hitbox lowered 0.125 blocks (two texture pixels); visual orb unchanged.
- Left-click the orb to remove it. In Survival/Adventure, it drops its item; in Creative, it is removed without a drop.
- When the supporting anvil disappears (including falling), the orb is dropped.
- All other mechanics inherited from v3.8.3.

TEST ONLY IN A BACKUP WORLD. This is a datapack POC, not validated in game.

Test:
1. Replace old POC zip with this one, /reload.
2. Left-click orb in Survival; verify one orb drops and station disappears.
3. Replace orb, break supporting anvil; verify one orb drops.
4. Replace orb, remove block below anvil to make it fall; verify one orb drops.
5. Test right-click XP transfer and no accidental attack trigger.
6. Test Creative break separately.

Known limits: no full multiplayer atomicity, and item drops are subject to ordinary world physics.
