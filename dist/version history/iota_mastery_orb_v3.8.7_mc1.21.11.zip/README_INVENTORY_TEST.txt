POC v3.8.1 - Inventory test helper (Minecraft 1.21.11)

/reload
/function anvil_poc:test_inventory_fill
/function anvil_poc:test_inventory_status
/function anvil_poc:test_inventory_clear

Fills ONLY empty player inventory slots (36 slots) with uniquely tagged paper.
Does not modify existing items. Offhand and armor are not filled.
For tool transfer tests, equip test tools in both hands BEFORE filling.
Use in a backup test world. Clear removes only tagged paper.
No change to orb transfer logic.
