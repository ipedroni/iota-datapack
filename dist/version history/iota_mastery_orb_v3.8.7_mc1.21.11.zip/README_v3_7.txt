POC ANVIL v3.7 — Minecraft Java 1.21.11

Receita (crafting table):
 A L A
 L E L
 A L A
A = Amethyst Shard (4); L = Lapis Lazuli (4); E = Ender Pearl (1).

A orbe e uma player_head personalizada com perfil/textura e nome/lore.
A deteccao de colocacao ainda reconhece qualquer player_head sobre anvil (limitacao herdada da v3.6).

ATUALIZACAO DA HITBOX ANTIGA:
/reload
/function anvil_poc:orb_remove
/function anvil_poc:orb_scan

A hitbox v3.7 tem largura 0.80, altura 0.40 e origem Y +0.395 do bloco da cabeca.
Sons e particulas sao emitidos apenas apos a transferencia confirmada.
A transferencia continua limitada a picaretas de ferro de teste marcadas; NAO usar itens valiosos.
POC sem rollback transacional e sem seguranca multiplayer comprovada.
O datapack principal nao foi alterado.
