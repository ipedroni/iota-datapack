# Mastery Orb experimental module

Archived from POC Anvil v3.8.7. This standalone experimental module preserves
the station, interaction, recovery, migration, recipes, and test functions from
the audited source. It is excluded from the Tool Mastery 3.8.8 pack.

Known discovery from Minecraft Java 1.21.11 in-game tests: vanilla anvil repair,
combination, and renaming preserve the XP and custom data of the left input.
The right input does not transfer mastery XP through the vanilla anvil. The
experimental orb's 25% XP transfer would therefore be its distinct feature.

The old POC implementation does not yet implement the 3.8.8 enchantment transfer
or the corrected orb identity. It is preserved as research code, not an approved
release. Debug and legacy user-facing text may be pt-BR.