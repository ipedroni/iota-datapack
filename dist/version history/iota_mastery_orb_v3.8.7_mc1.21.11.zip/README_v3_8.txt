POC Anvil v3.8 — Minecraft Java 1.21.11

Changes:
- On placing a player head above an anvil, converts it into an item_display and an interaction entity.
- Hitbox 0.70 wide, 0.55 high, starting 0.08 above head block bottom. Display rendering position/scale EXPERIMENTAL.
- Subtle enchant particles every 10 ticks (2 particles per station, within 16 blocks of a player).
- Invalid combinations: smoke + short anvil sound.
- Preserves 25% XP transfer and successful sound/particle feedback from v3.7.

TEST (in a COPY of your world):
1. Remove v3.7, install v3.8, /reload.
2. /function anvil_poc:orb_give, place head on anvil.
3. Verify head is visually displayed and click works across entire visible orb.
4. /function anvil_poc:give_rich_items, right-click orb. Main hand should have 3500 XP, offhand consumed.
5. Try clicking with empty hands: smoke and low anvil sound once.
6. Break anvil: interaction and display should disappear.
7. Test crafting recipe: 4 amethyst shards, 4 lapis lazuli, 1 ender pearl.

IMPORTANT LIMITATIONS:
- Experimental item_display visual transform may need tuning.
- Removing the supporting anvil removes the display and does not return the orb item. Test in creative first.
- Any standing player head above an anvil is recognized (not yet restricted to the orb).
- Temporary armor stand and storage transfer logic is not multiplayer-transaction safe; test only in singleplayer with test items.
- v3.7 is stable fallback. Main datapack untouched.
