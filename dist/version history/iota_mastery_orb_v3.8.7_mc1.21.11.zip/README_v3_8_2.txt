POC Anvil v3.8.2 for Minecraft Java 1.21.11

Changes from v3.8.1:
- Raise item_display model 0.25 blocks (translation Y 0.17 -> 0.42).
- Raise interaction hitbox by the same amount to retain visual alignment.
- Automatically migrate existing v3.8 and v3.8.1 station entities once on /reload.
- Keep 25% XP transfer, positive/negative feedback, subtle aura, recipe, inventory test functions unchanged.

Installation: replace previous ZIP in world/datapacks, then /reload.
Do not keep two versions active simultaneously.
Test in a backup world; not validated in game.
