POC Anvil v3.8.7 - Minecraft Java 1.21.11

SOURCE: user-supplied tested v3.8.6 ZIP. Isolated POC; does not change the main datapack.

CHANGES
- Hitbox width 0.55 blocks (X and Z); height 0.55; vertical position unchanged.
- Existing v3.8.6 stations are migrated once via ap_orb_v387 tag.
- Added test_enchantments_different, test_enchantments_verify,
  test_enchantments_conflict, test_enchantments_conflict_verify,
  test_safety_help.
- XP transfer logic, item recovery, aura, recipe, and drops remain unchanged.

START: /reload, then /function anvil_poc:test_safety_help

TEST A: Empty both hands. Run /function anvil_poc:test_enchantments_different.
Right-click installed orb. Run /function anvil_poc:test_enchantments_verify.
Expected: 3000 + floor(2000*0.25)=3500 XP. Mainhand retains Efficiency III,
Unbreaking II, damage, lore, custom name and unrelated custom_data. Fortune III
and Mending from secondary must NOT transfer. Offhand becomes empty.

TEST B: Empty both hands. Run /function anvil_poc:test_enchantments_conflict.
Right-click orb, then /function anvil_poc:test_enchantments_conflict_verify.
Expected: Silk Touch remains, Fortune not added, 3500 XP, offhand consumed.

TEST C: Use the orb (right-click) for each case. Clear both hands between cases.
- Cap: /function anvil_poc:give_cap_primary and /function anvil_poc:case_999.
  Expected: primary stays at 8000; both items remain.
- Zero gain: prepare the two tools from TEST A, then remove the secondary
  to a safe slot and run /function anvil_poc:case_0. Both items remain.
- Missing or invalid item: prepare the primary from TEST A and leave the
  offhand empty, then repeat with a stick in the offhand. Both hands stay as-is.
- Rounding: prepare TEST A, move the secondary to a safe slot and run
  /function anvil_poc:case_999. Expected: primary at 3249 XP; offhand empty.
- Inspect components before and after using /data get entity @s SelectedItem.

TEST D: Inventory full. Equip test tools before test_inventory_fill;
run test_inventory_status, transfer, then test_inventory_clear.

TEST E: Repeated left-click, break anvil, falling anvil, decorative head mining,
placing unrelated player heads above anvils, /reload with stations present.
For multiplayer: test with two players near separate stations, then near the
same station, with disposable test tools only. Observe temporary armor stands,
XP, item counts, and unwanted cross-player effects.

KNOWN LIMITATIONS (inherited from v3.8.6)
- Transaction is not fully atomic; no rollback between primary XP write and
  offhand consumption. Do not use valuable items.
- Global temporary armor stand tag ap_v25_temp may cause conflicts between
  concurrent player transfers; multiplayer safety NOT proven.
- Station conversion may treat unrelated player heads on anvils as orbs.
- Decorative drops with identical orb texture may be renamed even if unrelated.
- Verification functions are diagnostics, not comprehensive automated tests.
- Existing stations from experimental v3.8.5 are not migrated.

All newly added in-game test messages are in English. Legacy messages unchanged.
