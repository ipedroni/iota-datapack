# Development command audit — 2026-11-18

Applies to Iota base 1.0.34 and the two optional expansions 0.0.1. This is
command/test maintenance, not a restart of expansion feature development.
Use disposable worlds for item grants, XP overrides and discovery resets.
Commands are player-run `/function <ID>` unless otherwise indicated.

## Removed

| Function ID | Reason |
| --- | --- |
| `iota_exp_magical_discovery:register` | Obsolete Efficiency-III-only POC; inventory scanning now registers eligible books/equipment automatically. |
| `iota_exp_magical_discovery:apply_efficiency_3` | Obsolete manual enchanting entry point outside the frozen discovery-register scope. |
| `iota_exp_magical_discovery:apply_unlocked` | Internal helper used only by the removed manual enchanting command. |
| `iota_exp_magical_discovery:apply_paid` | Internal helper that spent three XP levels and applied Efficiency III; no current supported caller. |
| `iota_drops:test_structure_loot` | Redundant container-target version of the six preview loot rolls; keep the inventory-based test instead. |

Removed stale help instructions, misleading scratch-score diagnostic output
and unused `ed_levels`/`ed_success` objective declarations. Existing world
scoreboards are not deleted. Compatibility fields and stored discoveries remain.

## Iota base — retained

| Function ID | Purpose / side effect |
| --- | --- |
| `iota_drops:test_bundles` | Grants five themed bundle samples. Inventory space required. |
| `iota_drops:test_structure_loot_all` | Rolls six structure-preview bundle loot tables into inventory. Random; an empty roll is not a failure. Does not inspect naturally generated chests. |
| `iota_tools:test/broken_pickaxe` | Grants the opt-in nearly worn prototype pickaxe. Ordinary equipment remains outside the prototype. |
| `iota_tools:test/broken_pickaxe_unbreaking` | Separate Unbreaking fixture; tests enchantment interaction, not a duplicate. |
| `iota_tools:test/broken_status` | Reads held-item components without modifying them. |
| `iota_hearts:diagnose` | Reads maximum-health attributes, loss count and recovery timer. |
| `iota_hearts:recover_in_10s` | Advances active heart recovery to at most ten normal-rate seconds remaining; campfires accelerate it further. |
| `iota_hearts:recover` | Instant recovery of tracked maximum-heart loss and timer cleanup. Does not fill ordinary missing current health. Existing gameplay function, also useful manually. |
| `iota_hearts:xp/diagnose` | Reads current reconstructed XP and personal recovery record. |
| `iota_hearts:xp/test_setup` | **Replaces current XP with 1,000 points.** For controlled death tests only; does not reset an existing orb. |

Both Hearts diagnoses are needed: health recovery and recoverable XP use
different state. Confirmed scenarios remain useful regressions after changes.

## Tool Mastery — retained

Requires the expansion installed. Each fixture grants a diamond pickaxe just
below a distinct level threshold. Hold it in the main hand in Survival and mine
one stone block. The five commands are intentionally retained:

```mcfunction
/function iota_exp_tool_mastery:test/level_up_i
/function iota_exp_tool_mastery:test/level_up_ii
/function iota_exp_tool_mastery:test/level_up_iii
/function iota_exp_tool_mastery:test/level_up_iv
/function iota_exp_tool_mastery:test/level_up_v
```

They test Rookie, Apprentice, Adept, Expert and Masterwork transitions,
notifications and eligible milestone rewards. A fixture grant is not a full
armor/ranged/shield progression test or proof that every random reward occurs.
Keep `iota_exp_tool_mastery:status` for held-item XP and `:help` for guidance.
Help now accurately distinguishes the visible rank from command-inspected XP.

## Magical Discovery — retained and corrected

| Function ID | Purpose |
| --- | --- |
| `iota_exp_magical_discovery:status` | Public shorthand for the shared world list; retained for compatibility. |
| `iota_exp_magical_discovery:world_status` | Explicit shared-world list, including initial unlocked entries. |
| `iota_exp_magical_discovery:mastery_status` | Personal discoveries; name retained for compatibility. Now correctly labeled and includes all 41 scanner enchantments, not only mastery reward candidates. |
| `iota_exp_magical_discovery:diagnose` | Inspects the held item's enchantment components; no longer presents the temporary `ed_found` value as meaningful discovery status. |
| `iota_exp_magical_discovery:reset` | Clears all 41 personal enchantment counters, including seven previously omitted. Keeps the world register. Carried items are automatically rediscovered. |
| `iota_exp_magical_discovery:help` | Describes automatic scanning, the above commands and unchanged native table offers. |

The generator now preserves scanner objectives beyond the reward pool when
rebuilt, including the scan clock, and generates complete personal lists/resets.
This avoids reintroducing the incomplete command coverage. Progression and
reward probabilities are unchanged. Reset is a manual utility, not gameplay.

## Separate and archived tests

Keep `tests/anvil-persistence/` and `tools/build-anvil-tests.mjs` as reproducible
vanilla anvil regression evidence. The test-only pack is not included in base
or expansion ZIPs. Four setup/verify pairs cover repair, combine, reversed
inputs and rename; user-validated custom-data persistence is distinct from
the current broken-tool and repair-property tests.

The archived Mastery Orb POC is outside this cleanup. Its standalone code and
debug functions remain archived; no `anvil_poc` or `iota_test` namespace is
introduced into current playable distributions.

## Validation and manual follow-up

Static checks cover retained command existence, removed-function absence,
function references in active code/help/tags, complete Discovery personal
status/reset coverage, JSON parsing and distribution boundaries. They do not
load Minecraft. Recheck updated help, personal reset/re-discovery, held-item
diagnoses and all five level-up fixtures in a disposable world after installing
the refreshed ZIPs. Expansion versions remain 0.0.1; replace old copies.
