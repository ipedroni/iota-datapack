data modify storage iota_tools:broken_feedback lore set value []
data modify storage iota_tools:broken_feedback lore set from entity @s Inventory[{Slot:-106b}].components."minecraft:lore"
data remove storage iota_tools:broken_feedback lore[{insertion:"iota:broken_status"}]
data modify storage iota_tools:broken_feedback lore append value {text:"Broken",color:"red",italic:false,insertion:"iota:broken_status"}
item modify entity @s weapon.offhand iota_tools:mark_broken_poc
data modify storage iota_tools:broken_feedback slot set value "weapon.offhand"
function iota_tools:broken/apply_lore with storage iota_tools:broken_feedback
function iota_tools:broken/effects
data remove storage iota_tools:broken_feedback lore
data remove storage iota_tools:broken_feedback slot
