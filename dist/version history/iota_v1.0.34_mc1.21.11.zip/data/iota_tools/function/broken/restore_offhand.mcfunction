data modify storage iota_tools:broken_feedback lore set value []
data modify storage iota_tools:broken_feedback lore set from entity @s Inventory[{Slot:-106b}].components."minecraft:lore"
data remove storage iota_tools:broken_feedback lore[{insertion:"iota:broken_status"}]
item modify entity @s weapon.offhand iota_tools:restore_broken_poc
data modify storage iota_tools:broken_feedback slot set value "weapon.offhand"
function iota_tools:broken/apply_lore with storage iota_tools:broken_feedback
data remove storage iota_tools:broken_feedback lore
data remove storage iota_tools:broken_feedback slot
