scoreboard objectives add iota_world dummy
execute in minecraft:overworld run gamerule minecraft:advance_time false
