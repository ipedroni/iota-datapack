$time add $(skip)
