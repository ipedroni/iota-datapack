# Iota — Design Directions

Current implementation baseline: 1.0.34, Minecraft Java 1.21.11.
Development commands and the completed cleanup audit: [Test Commands](TEST_COMMANDS.md).
This document separates shipped behavior from approved directions and future ideas.

Documentation structure:

| Location | Role |
| --- | --- |
| DESIGN_DIRECTIONS.md (this file, docs root) | Canonical project-wide guide: consolidated behavior, goals and future directions |
| Drafts/ | Active designs and feature/POC notes awaiting consolidation, including Hearts XP and Broken Tools |
| Drafts/Research/ | Research, audits and supporting evidence for those designs; not independent gameplay specifications |
| TEST_CHECKLIST.md and TEST_COMMANDS.md (docs root) | Current verification checklist and development command catalog |
| Changelog/ | Release history and expansion milestone/freeze status |

Consolidate settled design into this guide when ready; retain research as
evidence and test documents for reproducibility. A draft's explicit approval
status is preserved while its details are being integrated. This organization
does not itself change gameplay or approve unresolved proposals.

For Minecraft Java 1.21.11. Place the Iota base ZIP in the world's datapacks
folder in place of the previous Iota ZIP and any standalone copies of its
modules. Reopen the world or restart the server to apply the Overworld settings.

| Module | Namespace |
| --- | --- |
| Hands Off | iota_hands_off |
| Tools | iota_tools |
| Recipes | iota_recipes |
| Drops | iota_drops |
| World | iota_world |
| Hearts | iota_hearts |

The Iota base ZIP is named iota_v1.0.34_mc1.21.11.zip and contains six modules. Optional expansions are separate ZIPs:
Iota Expanded: Tool Mastery (iota_exp_tool_mastery) and Iota Expanded: Magical
Discovery (iota_exp_magical_discovery). Install either, both, or neither.

| Optional expansion | Namespace |
| --- | --- |
| Iota Expanded: Tool Mastery | iota_exp_tool_mastery |
| Iota Expanded: Magical Discovery | iota_exp_magical_discovery |

The experimental Mastery Orb remains archived separately.

When upgrading, remove the old integral ZIP and install the new base plus any
expansions you want to retain. Never enable the old integral alongside them.
Persistent item fields, scoreboards and discovery levels retain their previous
identifiers. Migration is intended to preserve them and still requires in-game validation. Internal
legacy storage and lore marker IDs are retained for compatibility. Commands use
the new expansion namespaces. Removing an expansion disables its behavior but
does not erase the item's stored data or reverse previously applied rewards.

## Hands Off

Mining is 80% slower when the main hand is empty or holds an item outside
the recognized mining tool and exemption tags.

## Tools

Wooden and stone pickaxes, axes, shovels and hoes mine 50% slower than
vanilla. Their netherite counterparts mine about 11% faster. Gold tools can harvest blocks at the same tier as iron tools.

The following durability and enchantability values apply to vanilla
pickaxes, axes, shovels, hoes and swords when held in the main hand.

| Material | Durability | Enchantability |
| --- | ---: | ---: |
| Wood | 16 | 4 |
| Stone | 64 | 4 |
| Copper | 248 | 8 |
| Iron | 456 | 8 |
| Gold | 64 | 24 |
| Diamond | 1,560 | 12 |
| Netherite | 2,032 | 16 |

Tools also halves enchantment anvil_cost values, rounded up with a minimum of
one. This affects the enchantment contribution, not the whole operation price.
Wood/stone/netherite handheld tools and weapons (including spears) use Stick,
Flint and Netherite Scrap for anvil repair after being held in either hand.
Armor is unchanged. The repair fraction remains vanilla. Prior-work penalties are cleared on
managed tools/weapons in accessible player slots as of 1.0.32.
See [Anvil Behavior](Drafts/Research/ANVIL_BEHAVIOR.md) for current behavior and the material-repair audit.

## Recipes

### Tools

Replaces the vanilla recipes for wooden and stone pickaxes, axes, shovels,
hoes, swords and spears. Wooden tools use sticks in place of planks. Stone tools
use flint in place of cobblestone.

Wooden spears use three sticks diagonally. Stone spears use a flint tip and
two sticks diagonally. Both patterns support horizontal mirroring.
The wooden sword uses five sticks in a cross, including the center; the wooden
shovel uses three sticks vertically. Shields retain their vanilla planks-and-iron recipe.

### Materials

| Ingredients | Result |
| --- | --- |
| Smelt rotten flesh | 1 leather |
| Leather | 4 rabbit hide |
| Charcoal and bone meal | 1 ink sac |
| Ink sac and glowstone dust | 1 glow ink sac |
| Cobweb | 2 string |
| Wool of any color | 4 string |
| Wheat | 1 wheat seed |
| Honey bottle and green dye | 1 slimeball |

### Storage

| Ingredients | Result |
| --- | --- |
| 8 logs in a ring | 4 chests |
| 4 amethyst shards, 4 turtle scutes and 1 echo shard | 2 shulker shells |

### Automation

| Ingredients | Result |
| --- | --- |
| Dropper, 3 sticks and 3 string | 1 dispenser |
| Redstone in the upper corners and center, sticks at the middle sides, stone across the bottom | 1 repeater |
| Three redstone torches in a row above stone–quartz–stone | 1 comparator |
| Three redstone dust above three sticks above stone–quartz–stone | 1 comparator |
| Alternating glowstone/redstone dust around an empty center; either dust may occupy the corners | 1 redstone lamp |

### Building

Finished variants (bricks, chiseled blocks, pillars and polished blocks) are
made in the Stonecutter. Wax application, moss addition, material assembly and
Chiseled Bookshelves remain at the crafting table. The Stonecutter recipe is
unchanged. All 254 vanilla cutting routes remain, with 26 wooden cutting routes
added. Shape production remains available at BOTH stations:

| Shape | Crafting table | Stonecutter |
| --- | --- | --- |
| Slabs | 3 blocks → 6 slabs | 1 block → 2 slabs |
| Stairs | 6 blocks → 12 stairs, mirrored pattern supported | 1 block → 2 stairs |
| Walls | 6 blocks → 6 walls | 1 block → 1 wall |

Raw copper shortcuts also yield two stairs; cutting into Cut Copper first
provides a higher yield. Recovery returns the final material, not the shortcut's
original input. Oxidation, wax, moss and wood species are preserved.

### Reclaiming

| Ingredients | Result |
| --- | --- |
| Two identical slabs, vertically | 1 corresponding block |
| Two identical stairs, horizontally or vertically | 1 corresponding block |
| Six identical walls, two rows of three | 6 corresponding blocks |
| Packed ice | 9 ice |
| Blue ice | 9 packed ice |

## Drops

- Selected leaves can drop string and have adjusted stick drops. Short
  and tall grass have an 8% wheat seed drop chance and can also drop flint,
  sticks, feathers and string.
- Gravel has a higher chance to drop flint at lower Fortune levels. Mining
  stone and selected rock blocks with a pickaxe can yield extra flint.

Selected structure loot tables also roll for themed bundles. Each chest
listed below also has a separate 2.5% chance to contain an empty bundle.

| Source | Bundle | Chance |
| --- | --- | ---: |
| Village house chests | Forager | 3% |
| Village toolsmith chests | Primitive | 5% |
| Shipwreck supply chests | Explorer | 4% |
| Ancient city and woodland mansion chests | Adventurer | 1% |
| Trail Ruins archaeology | Abandoned | 3% |

## World

The Overworld has one hour of day and one hour of night at 20 TPS. Beds
work at either time with vanilla safety checks. When enough players complete
sleep, the weather clears. Daytime sleep advances the clock three Minecraft
hours. Nighttime sleep advances to dawn.

## Hearts

Players keep their inventory on death. In Survival, each death costs one
heart at standard maximum health, up to five lost hearts. Each death
restarts a five-minute timer, including deaths at the cap. All missing hearts
return together, with one sound and one particle burst. The action bar
displays Full recovery in m:ss only while sneaking, appearing immediately and
clearing on release. During lost-maximum-heart recovery, a small red/gray dust
aura appears around the torso once per second; near lit campfires the existing
green recovery effect takes over. The lost-heart burst is delayed ten live
ticks after respawn (0.5 seconds at normal tick rate) for visibility; its sound
plays immediately. Ordinary missing current health does not
trigger this aura. Each respawn after a Survival death plays the beacon deactivation sound and emits a burst of 24 damage-indicator particles around the torso, including at the heart-loss cap. A death while already at the cap also applies Hunger III for 60 seconds to make natural healing harder. Eating
can still restore the hunger needed for natural healing. Further deaths at
the cap refresh the effect at the same strength.

## Iota Expanded: Tool Mastery

### Design goal

Tool Mastery gives players a reason to grow attached
to equipment they craft and use. Encountering a new item should prompt a
choice. A player might replace a trusted tool with accumulated bonuses,
keep using it after finding alternatives, or save it as a keepsake.

### Current behavior

New gear starts Unranked. Eligible uses grant 1 XP plus 0.25 XP per point of
durability consumed. Armor gains XP from hostile hits with a two-second
cooldown and a gain adjusted for the piece's durability. Shields earn XP from
blocks in either hand, including blocks with zero wear. XP stays with the
item. Its tooltip shows only the rank. Use the status command to inspect XP. On the vanilla anvil, put the item whose progress you want to keep in
the left slot. The XP level cost contributed by each vanilla enchantment
on the anvil is halved, rounded up with a minimum of one.

| Rank | Handheld gear XP | Armor and shield XP | Mining speed at the threshold |
| --- | ---: | ---: | ---: |
| Unranked | 0 | 0 | 0% |
| Rookie | 5 | 5 | 0% |
| Apprentice | 400 | 100 | +2% |
| Adept | 1,600 | 300 | +8% |
| Expert | 4,000 | 700 | +20% |
| Masterwork | 8,000 | 1,500 | +40% |

The mining speed bonus grows with XP from Apprentice to Masterwork while
the tool is held in the main hand. Expert and Masterwork shields reduce the
disable cooldown by 10% and 20%, respectively.

Adept, Expert and Masterwork can grant compatible enchantment upgrades.
Masterwork rolls for Treasure at 5% in Tier A and 0.5% in Tier B. If the rare
roll misses, an eligible common upgrade can still be granted. The milestone
ends without a reward if no eligible common upgrade remains. Bow, crossbow
and trident use Tier A odds. Shields use Tier B odds.

Level-ups use 12 blue particles at every rank, plus 32 enchantment particles
at ranks III–V. Anvil audio plays at 0.40, followed eighteen ticks later by player
level-up at 0.40. No level-up/reward action-bar message is displayed.

## Iota Expanded: Magical Discovery

Design direction: single-player-first. Enchanting Table unlocks will be shared
across the world. In multiplayer, one player's discovery will unlock the same
offers for everyone. Per-player native-table filtering is outside this scope.
This global unlock mechanism is planned, not yet implemented.


### Design goal

Magical Discovery gives players a reason to explore the world and
engage with other enchanting systems. The original design for the Enchanting
Table starts with a pool of basic enchantments and levels already available
to each player. As players find enchanted books and discover new enchantments
or higher levels, those discoveries become eligible to appear in their
Enchanting Table offers.

### Current behavior

Players can register Efficiency III–V from an enchanted book in the main
hand. A player who knows Efficiency III can spend three XP levels to apply
it to a compatible tool through a command. Mastery rewards also record the
enchantment applied and unlock its lower levels for that player. Enchanting
Table offers currently follow vanilla selection rules.

Curse of Binding and Curse of Vanishing are removed from the vanilla random
loot, tradeable enchantment and Treasure tags.

## Commands

| Command | Purpose |
| --- | --- |
| /function iota_exp_tool_mastery:help | Show mastery help |
| /function iota_exp_tool_mastery:status | Inspect XP on the held item |
| /function iota_exp_magical_discovery:help | Show the book registration and application commands |
| /function iota_exp_magical_discovery:mastery_status | List discoveries gained from mastery |
| /function iota_exp_magical_discovery:reset | Reset your discoveries |

## Manual verification — base and optional expansions

Expansion-specific checks require the corresponding expansion to be installed.
See TEST_CHECKLIST.md for migration and recipe checks. Static checks do
not establish Minecraft loading or successful migration.

- Sleep safely during rain. Check the three-hour jump by day and the jump
  to dawn at night, with clear weather after each.
- Lose multiple hearts in Survival, then run
  /function iota_hearts:recover_in_10s. The remaining timer should be at
  most ten seconds. Check that a death resets the full timer and that all
  lost hearts return together when the timer ends. At the cap, verify that the next death gives 60 seconds of Hunger III without another heart loss.
- Select a newly crafted pickaxe. Four blocks of stone with one durability
  point spent per block should bring it to Rookie. Use separate pickaxes
  to check that each tracks its own progress.
- Use the level-up commands below, select the test pickaxe in Survival and
  mine one stone block. Check the item name, rank, particles and sounds.
  For a rewarded item, confirm the discovery and verify that another use
  or an anvil repair does not repeat the reward.
- Throw and retrieve a trident that was held in the main hand. Check for
  XP on that trident. Try a shield in each hand, then hold two different
  shields and check that only the blocking shield gains XP. Compare the
  disable cooldown of Unranked, Expert and Masterwork shields.

| Target rank | Operator command |
| --- | --- |
| Rookie | /function iota_exp_tool_mastery:test/level_up_i |
| Apprentice | /function iota_exp_tool_mastery:test/level_up_ii |
| Adept | /function iota_exp_tool_mastery:test/level_up_iii |
| Expert | /function iota_exp_tool_mastery:test/level_up_iv |
| Masterwork | /function iota_exp_tool_mastery:test/level_up_v |

## Approved direction — Magical Discovery

Unify book discovery and mastery reward records. Prioritize single player and
world-wide Enchanting Table unlocks; multiplayer players share available offers.
Global pool updates and level gating are not implemented. Starting enchantments,
The starting list and shared lower-level unlock policy are approved;
implementing native-table level limits and refresh behavior remains unresolved. See CHANGELOG_EXPANSION_STATUS.md.

## Future changes — not implemented

### Next overall design step: equipment, treasure and enchanted-book loot

User-requested review, 2026-11-19: audit loot tables across the datapack for
equipment, treasures and enchanted books. Review their distribution, material
tiers, enchantment levels, rarity and progression role alongside crafting,
Trading, Tool Mastery and Magical Discovery. Preserve meaningful exploration
rewards and evaluate whether loot complements or bypasses those other routes.
This is a datapack-wide design task, not only a Trading catalog review.
No loot-table changes, specific removals or drop rates are selected yet.

### Under consideration: enchanted gems as application catalysts

Explore replacing direct enchanted-book application with a thematic, more
expensive intermediate: craft a diamond together with an enchanted book to
produce an enchanted diamond, then combine that gem with equipment in an anvil
or smithing table. The motivation is both thematic coherence and an additional
cost for deliberately selected enchantments. This is a discussion idea only.

Investigate how to represent stored enchantments on the gem, what happens to
the book and gem, multi-enchantment books, compatibility/levels, costs and the
appropriate workstation. Do not assume native anvil behavior accepts arbitrary
enchanted diamonds as book substitutes; a custom application mechanism may be
required. No implementation or expansion unfreezing is approved by this note.

### Hearts recoverable experience on death — 1.0.34

Survival deaths store 25% of current total XP points (rounded down) in a
personal floating orb, keeping the remainder. Only its owner can click to
recover it, once. A new death forfeits the previous unrecovered amount.
Zero-XP deaths also invalidate the old orb. Inventory preservation remains.

Ordinary grounded deaths try the death location. Airborne/void cases and
unsafe loaded sites use the actual resolved respawn location instead. No
chunks are force-loaded. UUID ownership and generation checks prevent stale
or other players' orbs from paying. Visuals use an XP-themed head, green/yellow
dust, a small interaction hitbox and an XP pickup sound, without a resource pack.

See [Hearts XP Recovery](Drafts/HEARTS_XP_RECOVERY.md) for lifecycle, attribution,
placement limits, commands and the unexecuted in-game checklist. Automated
arithmetic and lifecycle checks do not constitute Minecraft validation.

### Under consideration: unified progression expansion

Consider combining Iota Expanded: Tool Mastery and Iota Expanded: Magical
Discovery into one expansion focused on progression, discovery and attachment
to equipment and characters. Preserve clear internal system boundaries and
consider optional configuration rather than requiring separate ZIPs for every
system. "Vanilla-like" is a design aspiration, not sufficient by itself to
determine which features belong together.

Trading integration may include discovered offers, merchant specialization or
teaching enchantments if those ideas are approved later. Do not assume that
the whole trading economy (food, building supplies, prices and stock) belongs
in this expansion; decide its scope after the Trading design brief.

This is a future improvement only. Do not merge, rename or reorganize the
expansions now. Both remain separate and frozen at version 0.0.1.

### Planned: Iota advancement tree

Create a visible advancement tree that teaches progression through play.
Introduce primitive tools early, then add branches for tool and armor
mastery, anvil repairs, and enchantment discovery. Use the Recipes categories
to teach crafting changes. Keep technical event
advancements hidden from players.

### Under consideration: world generation structures

Consider adding custom structures to the World module. Structure designs
and spawn rules are open for discussion.

### Under consideration: lateral equipment progression

Study progression for tools, weapons and armor in which equipment has
different strengths and trade-offs. Explore how multiple options could
stay worth using as players advance.

### Under consideration: fixed enchanted book recipes

Study fixed crafting recipes for selected enchanted books. The books,
levels and ingredients are open for discussion.

### Villager trading — research before redesign

All previous Iota purchase, sale, kit and pricing proposals are discarded.
Trading is vanilla in the current pack. Future design starts from a study of
vanilla systems, without treating earlier decisions as approved constraints.

### Planned review: other armor types

Review armor outside the leather, iron, copper, gold, diamond and netherite
sets. Include chainmail and the turtle shell, and assess how each item fits
into Iota's equipment progression.

## Current recovery and discovery implementation

Hearts: recovery advances five times as fast within four block-grid units of a lit
campfire or soul campfire. Detection refreshes each second; multiple fires do
not stack. Full recovery beside a fire takes approximately 60 seconds.

Magical Discovery: once per second, direct inventory entries (including armor
and offhand) are scanned for regular and stored enchantments. Items are never
consumed. Nested container contents are excluded. Existing inventory is scanned
automatically. Non-curse maximum levels accumulate in shared #world scores;
higher levels imply knowledge of lower levels. The approved starting eight
enchantments are recorded at level I globally. This does NOT yet restrict native
Enchanting Table offers. Personal reset commands will be repopulated by items
still carried; shared discoveries are not cleared by personal reset.

While accelerated recovery is active, eight happy-villager particles appear
around the player once per second. No particles are emitted at full recovery
or away from lit campfires. No additional sound is played.

## Expansion freeze milestone

Both expansions are frozen at 0.0.1 after the shared discovery-register
integration. Only the base continues active development. See CHANGELOG_EXPANSION_STATUS.md.
Use /function iota_exp_magical_discovery:world_status to inspect the register.
Native table gating remains unimplemented and outside this freeze milestone.

## Discarded Trading prototype

The former Trading module, equipment kits and trade prices are removed from
the base as of 1.0.29. No worlds were loaded with the Trading prototype; no rollback is needed. Expansions remain frozen at 0.0.1.

## Trading research baseline

The three player-loop analyses (initial equipment, specific enchantments and
bulk building supplies) are in [Trading Loop Research](Drafts/Research/TRADING_LOOP_RESEARCH.md).
The desk study informs profession catalogs; its in-game measurement protocol
remains unexecuted and no new trade catalog is approved.

Trading tenets, practical directions, unresolved questions and future concepts
are consolidated in TRADING_DESIGN_GUIDELINES.md. Approved principles take
precedence over candidate mechanics; no new catalog is approved yet.

Future design assumes Minecraft Java 1.21.11 with the official Villager Trade
Rebalance experiment enabled. Prefer the built-in experiment instead of
reimplementing it; Cartographer and Wandering Trader changes are already
standard vanilla in this target version. This is a design assumption, not an
automatically enabled feature in the Iota ZIP. Comparison test worlds may enable
the experiment at creation. The final Trading release must work by installing
the datapack alone, without manual experiment activation or additional setup
commands. Implementation must meet that requirement independently of the
experimental study baseline; see TRADING_DESIGN_GUIDELINES.md.
No previous discarded Iota trade catalogs or kit decisions are reinstated.

## Repair penalty and broken-state prototype — 1.0.32

Tools clears repair_cost for the 42 vanilla tools/weapons in its managed tag,
across hotbar, main inventory, offhand, cursor and personal crafting slots.
Armor, bows, crossbows, tridents, modded items and closed container contents
are not in this tag. Cursor access has vanilla Creative-mode limitations.
Anvil input slots themselves are not directly accessible; let the equipment
pass through a managed player slot. The hard 40-level ceiling remains, so
other operation costs can still exceed it.

Opt-in test: /function iota_tools:test/broken_pickaxe now gives a nearly worn
diamond pickaxe protected by a technical item_damage enchantment. It reserves
two durability points to prevent native destruction, then enters broken state
on the next tick. Native anvil repair restores function. Ordinary tools do not
receive this behavior. See Drafts/BROKEN_TOOL_PROTOTYPE.md for scope and test cases.

## Repository layout and development

- modules/: six base modules and the archived Mastery Orb experiment.
- expansions/tool_mastery/: Iota Expanded: Tool Mastery.
- expansions/magical_discovery/: Iota Expanded: Magical Discovery.
- tools/: generators, validators and packaging.
- dist/: separately installable ZIPs.
- tests/: anvil persistence fixtures.
- vendor/: existing portable development tools and official registry data.

Build using tools/build-integrated.ps1 with -Distribution base, tool_mastery,
or magical_discovery. Default is base. Generate mastery from
tools/build-mastery-progress.mjs; it writes into expansions/.

Legacy storage iota_tool_mastery:progress, scoreboards, item custom_data and
legacy lore markers are intentionally retained for save compatibility.

Design goals, current behavior and future ideas are documented in docs/DESIGN_DIRECTIONS.md.

Documentation: Changelog/CHANGELOG.md retains release history; TEST_CHECKLIST.md is the
current regression checklist. Drafts/Research/ANVIL_BEHAVIOR.md audits implemented anvil changes.
Drafts/Research/CRAFTING_STONECUTTER_AUDIT.md and its generated filter manifest are retained
for reproducible recipe review. Changelog/CHANGELOG_EXPANSION_STATUS.md records the frozen scope.
