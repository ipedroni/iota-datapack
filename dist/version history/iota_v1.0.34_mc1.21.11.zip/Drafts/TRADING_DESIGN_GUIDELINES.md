# Trading — design guidelines

Current decisions: 2026-11-19. Target: Minecraft Java 1.21.11.
This is the working Trading draft awaiting consolidation into the project guide. Approved directions, working level
assignments and unresolved decisions are separated below. No new Trading
gameplay has been implemented; the discarded prototype remains discarded.

## Design tenets — approved

1. **Plug & play:** install the ZIP and load the world. No external dependencies,
   manual experiment activation or setup commands in the final release.
2. **Be intentional:** coherent, elegant decisions serving a clear vision.
3. **Show, don't tell:** minimize uncertainty, explanatory text and interface.
4. **Trust & recycle:** modify as little vanilla functionality as possible.
5. **Work for it:** emphasize the journey toward rewards.
6. **Less is more:** avoid excessive options, value and repetition.
7. **We all lift together:** worthwhile commercial opportunities across resource
   sources and playstyles.
8. **Different is good:** no single correct sandbox playstyle or mandatory loop.
9. Encourage exploration.
10. Encourage community building.
11. Encourage infrastructure building.
12. Encourage personalization and personification of villages and villagers.

Essential workstations must not become trade-exclusive to force participation.
Commercial income should let farmers, miners, explorers and manufacturers
exchange the products of their different activities.

## Economic criteria — approved

- Renewable/farmable goods should generally have lower unit value than
  harder-earned finite goods. Rarity alone does not determine the price.
- Useful processing and better constituent materials should increase value.
  Count effort, risk, fuel, XP, infrastructure, utility and alternatives;
  repeated crafting clicks alone do not justify unlimited added value.
- Compare wealth opportunities at similar development stages, including volume,
  investment, active work and passive output. No identical unit-price rule or
  exact emeralds/hour target has been selected.
- Profitable specialized production, including enchanted equipment assembly
  lines, is intended gameplay. Buying some inputs does not make a production
  chain an exploit.
- Prevent guaranteed immediate buy/resell profit and profit from endlessly
  repeating reversible conversions. Check Iota recipes, salvage, discounts,
  other vendors, enchanting and repair routes together.
- Paid prices for enchanted crafts must justify materials, processing and
  enchanting investment. Do not exclude goods merely because a player could
  be sentimentally attached to them; selling is the player's choice.
- Do not reward mass villager confinement as the default route to useful
  capacity. Keep direct gathering, crafting and exploration credible options.

Use the contemporary reasoning behind the 2012 Quick Fix proposal, not its old
prices or assumptions about modern farms.

## Profession progression matrix — approved

New services complement earlier useful offers; leveling never removes them.
Trading level represents commercial history, not a separate friendship meter.

| Group | Early relationship | Developed relationship |
| --- | --- | --- |
| **Artisans:** Armorer, Toolsmith, Weaponsmith, Fletcher, Leatherworker | Buy production inputs and sell their essential products | Also sell materials and buy selected player-made crafts, including enchanted equipment; client/supplier becomes fellow craftsperson |
| **Producers:** Farmer, Fisherman, Shepherd, Butcher | Exchange useful basic production and inputs | Broader complementary supply and processed products |
| **Academics:** Librarian, Cartographer, Cleric | Supply basic knowledge/materials and buy work inputs | Specialized knowledge and interest in player discoveries; client becomes collaborator |
| **Construction supplier:** Mason | Reliable building materials and useful input purchases | Broader finishes and capacity appropriate for larger projects; occasional supplier becomes construction partner |

Producer direction: crops and prepared staples for Farmer; textiles/colors for
Shepherd; animal-food supply from Butcher remains available to players who do
not produce it themselves. Regional demand is a future layer, not yet a catalog.

**Fisherman exception, approved:** supplies raw/prepared fish and fishing
equipment, buys fishing inputs such as String, and can buy player-made fishing
equipment, including enchanted rods, at advanced levels. Does not buy fish.
A different buyer for the player's catch remains unresolved.

Academics' discovery collaboration does not yet implement teaching or custom
offers. Librarian book supply, Cartographer exploration and Cleric expedition
materials remain their working roles; exact catalogs are open. Mending access
must be evaluated with maintenance, anvil behavior and optional expansions.

Mason prioritizes useful early construction supply and bulk throughput over
rarity alone. Clay, bricks, terracotta and quartz building blocks are candidates,
not finalized offers. Do not require many identical workers for a modest build.

## Villager identity and progression — requested directions

### Names

Villagers gain a random personal name as their relationship develops.
Recommend assigning once at the first promotion and keeping it afterward;
the exact naming milestone and name pool remain open. Preserve player-given
names. A stable identity should not be replaced by another random name at
every promotion.

### Permanent careers and no rerolls

Once an adult first acquires a trading profession and its offers are selected,
the same individual keeps that profession and commercial identity. Do not wait
for the player's first trade to commit it. Breaking/replacing jobsite blocks,
reopening the interface or reloading must not reroll that identity.

Persist the selected career, individual offer plan and specialization result.
Future levels add their planned offers; stock replenishment does not redraw
offer types. Keep uses, demand, discounts, level progression and legitimate
restocking mutable. Reapplying a pristine snapshot every tick must not reset
stock or prices. Keep normal AI and workstation access requirements; allow
rebinding to another workstation for the same profession.

Unemployed adults and babies remain uncommitted until their first profession.
This does not invent trades for nitwits. Exact locking implementation needs a
prototype: test rapid jobsite changes, first GUI opening, promotions, reloads,
unloaded chunks and zombie conversion/curing. Conversion identity needs explicit
handling. Administrative commands and conflicting mods are not guaranteed
boundaries. Blocking one individual's reroll does not prevent replacing or
breeding villagers; rare-offer design must also consider that incentive.

### Variable individual catalogs

**Approved initial core:** professions should have a small useful, thematic
guaranteed core alongside variable offers. The latest Toolsmith selection is
two Novice purchases: Flint is fixed, and the other is Coal OR Charcoal.
Apprentice adds the other fuel; its second purchase is open. Iron Ingots are
no longer a fixed early purchase. The separate approved sales
track starts with two Copper/Iron tool families at Novice, followed by the
other two families at Apprentice. Iron Pickaxe is not a guaranteed Novice
sale. Earlier unlocked offers persist.

Profession/level offer pools may produce different selections per villager.
Decide a small guaranteed useful core plus optional offers; not every candidate
must appear on every individual. Pool weights and selection counts remain open.
Make important opportunities attainable without endless random searches.

### Trade-list presentation — selected direction

Group all unlocked offers by direction, independently of unlock level:
first goods the villager sells to the player, then goods the villager buys
from the player. Retain a stable order within each group. A newly unlocked
sale joins the sales group rather than appearing after the purchases merely
because its level is higher. Classify special sixth-stage offers the same way.

Use the order of the entity's Offers.Recipes list; the ordinary trading screen
remains one list, without custom tabs/headings. Reorder complete offer records
so uses, demand, discounts, quantities and XP remain intact. Prototype client
synchronization before implementation: do not silently change offer indices
while a player is selecting/trading. Apply changes safely between sessions,
with reopening if necessary; do not reset offers to pristine stock.

In the official 1.21.11 server code, Villager selects profession/level listings
and AbstractVillager randomly removes candidates as offers are added. These
are internal trade pools, not ordinary editable loot tables. The later
[26.1 Snapshot 1](https://www.minecraft.net/en-us/article/minecraft-26-1-snapshot-1)
introduces data-driven villager-trade registries. Do not use that newer schema
for this target. Iota needs its own persistent selection and entity-offer edits.

### Secret sixth stage and treasure trade

Every trading profession receives an internal post-Master stage that unlocks
one special treasure trade. Keep native displayed level at Master (5): no sixth
badge, title or progress bar. The unlocked trade itself appears in the normal
offer list. The progression threshold remains undefined.

All eligible villagers have a special sixth-stage offer; the draw can select
which one, rather than leaving some with no reward. Netherite Scrap is a rare
Toolsmith candidate selected through specialization, not a guaranteed offer
for every Toolsmith. Draw once and persist; no repeat attempts through jobsite
changes. Probability, alternative treasures and stock remain open. "Treasure
trade" here does not automatically mean a treasure enchantment.

## Toolsmith — selected catalog scope

Start with this profession, review its complete loop, then generalize the method
to other artisans. No kit-opening mechanic or discarded diamond ban is revived.

### Equipment eligible for purchases and sales

The four productive tool families have the following eligible material scope.
Purchased equipment progresses from unenchanted Copper/Iron at Journeyman
to enchanted Iron/Gold at Expert and Gold/Diamond at Master. Retail enchantments follow
the separate level caps below; Netherite remains eligible for secret-stage sales.

| Family | Copper | Iron | Gold | Diamond | Netherite |
| --- | --- | --- | --- | --- | --- |
| Pickaxe | Buy plain at Journeyman / sell | Buy/sell | Buy/sell | Buy enchanted at Master / sell | Sell |
| Axe | Buy plain at Journeyman / sell | Buy/sell | Buy/sell | Buy enchanted at Master / sell | Sell |
| Shovel | Buy plain at Journeyman / sell | Buy/sell | Buy/sell | Buy enchanted at Master / sell | Sell |
| Hoe | Buy plain at Journeyman / sell | Buy/sell | Buy/sell | Buy enchanted at Master / sell | Sell |

Purchase candidates cover Copper/Iron plain tools, Iron/Gold enchanted
tools at Expert and Gold/Diamond enchanted tools at Master. Each individual selects only its career
plan, not every candidate. The latest selection supersedes Netherite purchase
eligibility; Netherite sales remain. No weapons or armor are bought by the
Toolsmith: only Pickaxes, Axes, Shovels and Hoes. Swords/spears belong to the
separate Weaponsmith review.

### Purchase quality groups

- **Plain crafted tools (Journeyman):** Copper or Iron, without enchantments.
- **Initial enchanted tools:** Efficiency I+ OR Unbreaking I+; either or both
  qualify. Expert candidates use Iron or Gold, across all four families;
  Diamond tool purchases begin only at Master.
- **Master enchanted tools:** Efficiency II+ OR Unbreaking II+; either or both
  qualify. Fortune I+ is a tentative additional independent qualifying option,
  relevant only to compatible equipment. Master candidates use Gold or
  Diamond; Iron is excluded from newly unlocked Master tool purchases.
  Earlier Iron offers persist. Compatible Treasure enchantments may also qualify as an alternative;
  the exact list/levels remain open (Mending is a candidate, not a finalized
  purchase requirement). Fortune is not classified as Treasure.
- Higher qualifying levels and extra compatible enchantments should not
  disqualify an item. Pricing multiple/higher enchantments remains open; one
  submitted tool receives one payment.
- Level material limits apply to newly unlocked purchase offers. Earlier
  unlocked offers persist under the existing retention rule, including the
  Journeyman plain-Copper offer if selected; it is not upgraded into a Copper
  enchanted offer at Expert/Master.
- Full durability is a proposal, not a settled acceptance rule. Verify native
  matching for minimum levels, extra enchantments and OR conditions before
  committing to an interface.
- "Player-made" describes the intended production route, not an implemented
  provenance detector. Compare found loot and other suppliers as alternatives.
  Names/mastery do not automatically add a separate price premium.
- Tool Mastery rewards may satisfy an enchantment requirement, but Trading
  must function without either expansion.

### Material offers

| Material | Toolsmith buys from player | Toolsmith sells to player | Placement |
| --- | --- | --- | --- |
| Coal | Included in the two-fuel starting pool | Not selected | Novice if selected; otherwise Apprentice |
| Charcoal | Included in the two-fuel starting pool | Not selected | Novice if selected; otherwise Apprentice; the player supplies fuel to the Toolsmith |
| Flint | Fixed initial tool-production input | Never sold by Toolsmith; reserve retail for Mason | Novice purchase guaranteed |
| Copper Ingots | Journeyman purchase-pool candidate | Included in ingot pools | Journeyman purchase if selected; Journeyman/Expert retail if selected |
| Iron Ingots | Journeyman/Expert purchase-pool candidate; no fixed Apprentice purchase | Included in ingot pools | Drawn purchase; Journeyman/Expert retail if selected |
| Gold Ingots | Expert/Master purchase-pool candidate | Included in Expert ingot pool | Drawn purchase; Expert retail if selected |
| Diamond | Master purchase-pool candidate | Secret-stage candidate | Drawn Master purchase; secret retail if selected |
| Netherite Scrap | Not selected | Rare specialization candidate | Secret sixth stage; random capability, chance/stock open |

Netherite Ingots are not selected as raw-material sales. Selling complete
Netherite tools is separately included in the equipment scope above. Buying
and selling metals requires retail/purchase margins and a review of iron/gold
farm income. Flint's price also needs comparison with Drops and natural supply.

### Current level distribution — sales first

The latest sales track adds two retail offers at each ordinary level, plus
one special sale at the secret stage. The previously approved purchases are
retained separately. This supersedes the earlier two-offers-total cap: Novice
adds two sales and two purchases. Apprentice has two sales, the remaining fuel
purchase and an open second purchase slot. Later purchase counts remain to be settled. Do not remove purchases merely
because the new retail track uses two slots.

Each row lists additions; earlier offers remain available. All sales are
listed before all purchases in the actual trading interface.

| Level | Toolsmith vende | Toolsmith compra |
| --- | --- | --- |
| Novice | Two different families drawn from Pickaxe/Axe/Shovel/Hoe; each is Copper or Iron | Flint (fixed) + Coal OR Charcoal (draw once) |
| Apprentice | The other two families not selected at Novice; each is Copper or Iron | Add the other fuel; second purchase open |
| Journeyman | One ingot offer drawn from Copper/Iron + one tool drawn from the Gold/Diamond pool | Unenchanted Copper/Iron tools + raw-material pool Copper Ingots / Iron Ingots; selected offers/count open |
| Expert | One ingot drawn from Copper/Iron/Gold, excluding the ingot selected at Journeyman + one Gold/Diamond tool, optionally enchanted up to II | Iron/Gold tools with Efficiency I+ OR Unbreaking I+ + raw-material pool Iron Ingots / Gold Ingots; selected offers/count open |
| Master | Two tools from the expanded Gold/Diamond pool, optionally enchanted at I, II or III | Gold/Diamond tools with Efficiency II+ OR Unbreaking II+, or eligible Treasure; Fortune I+ tentative; raw-material pool Gold Ingots / Diamond |
| Secret VI — name pending | One draw: Diamond, Netherite Scrap, or a Diamond/Netherite tool optionally enchanted up to V | No special purchase selected |

For Novice/Apprentice, draw tool families without replacement so both stages
together supply all four families. Copper versus Iron is a separate material
choice per selected family, not two versions of the same family consuming
both Novice slots. The probabilities remain undefined.

Raw-material purchases follow the same material staircase as tools:
Journeyman Copper/Iron, Expert Iron/Gold, Master Gold/Diamond. These are player
sales to the Toolsmith; retail ingot pools above remain separate. The user
removed guaranteed Iron purchases at Apprentice. Choose selection counts and
repeated-material rules before finalizing the pools; no complementary Gold/
Diamond guarantee is selected. Each level also needs its appropriate tool
purchase group. Earlier unlocked offers remain available.

Journeyman/Expert ingot draws are complementary: if Journeyman sells Copper,
Expert draws Iron or Gold; if Journeyman sells Iron, Expert draws Copper or
Gold. Select once in the persistent career plan. Exact tool repetition rules
for later pools remain open; avoid identical duplicate offers by default.

Enchantment caps apply per enchantment and respect its vanilla maximum and
compatibility. "Up to V" does not create Unbreaking V, Fortune V or other
above-vanilla levels. Enchanted probability, enchantment sets, Treasure
eligibility, quantities, prices and stock remain open. Novice/Apprentice and
Journeyman retail have no newly approved enchantment roll.

Suggested internal secret-stage name: **Renowned**. This is a recommendation,
not yet a selected name, and it does not replace the visible Master label.
The secret unlock threshold and weights among the selected special outcomes
remain open. Flint retail belongs to Mason; Toolsmith only buys it.

## Research, validation and installation

The user accepted the three-loop study:
[Trading Loop Research](Research/TRADING_LOOP_RESEARCH.md). First equipment access,
specific-enchantment discovery/recurring supply and bulk construction capacity
are different balance problems. Measurements are not yet executed.

**Required World integration test:** compare stock depletion and replenishment
with World on/off, including daytime sleep, night skipping, loaded work time
and equal real-time observation windows. This is explicitly tracked in
[the test checklist](../TEST_CHECKLIST.md). Extended-day impact is unmeasured,
not a confirmed restocking defect.

Study worlds use official Villager Trade Rebalance as a reference. The final
module must work in ordinary worlds without manual feature activation and
avoid conflicting behavior in worlds that already enable the experiment.

Compare equivalent usable outcomes, useful leveling purchases, first investment
and repeat supply. Include seeds, stage of development, risk, active/passive
production, prices/discounts and capacity on both sides of the market. Current
base Tools affects repair costs; Hearts affects replacement pressure; Recipes
and Drops affect inputs. Measure optional expansions separately.

## Future concepts — retained, not selected mechanics

### Everyday supplies pool — under consideration

**Sequence selected by the user:** evaluate this in depth only after closing
the Toolsmith template. It is deferred and must not add offers to the current
Toolsmith draft or block completion of that template.

User proposal: an additional early purchase by a villager, selected at Novice
or Apprentice from useful everyday supplies such as Sticks, String, Flint or
food. The player sells these goods to the villager; this is not a shared retail
sale pool. It could make common collected goods broadly useful as income.

Evaluate profession-appropriate subsets, avoiding identical buyers everywhere
and preserving the two-way exchange between playstyles. Candidate examples
are not a complete approved item list. Respect profession exceptions, including
Fisherman not buying fish and Toolsmith not selling Flint. Low-value renewable
goods still need effort/scale and conversion-arbitrage review. Decide whether
the offer adds a slot or occupies an early variable slot, how it avoids
duplicates of fixed offers, and its level, quantities, prices and stock before
implementation. No automatic extra offer is approved by this discussion.

### Farmer seed trading — requested direction

Record the user's interest in exchanging seeds with Farmers. Eligible seed
types, whether the Farmer buys, sells or supports both directions, progression,
prices and stock remain open. Compare Iota Wheat-to-Seeds and vegetation drops;
do not accidentally approve rare/exploration seed access through a generic
all-seeds pool. This is future catalog work, not an implemented trade.

### Other retained concepts

- Specialization through found items/bundles across professions; teaching a
  Librarian from a found book is one application, not a unique free shop editor.
- Earned control over desired offers; do not make the ideal shop trivial to
  configure. Exact acquisition beyond the permanent random plan remains open.
- Commissions: e.g. a written request near a Mason to produce Stone Bricks.
  Ownership, payment, acceptance, manufacturing, delivery and cancellation
  require a separate prototype after basic catalogs.
- Regional demand/imports supporting multiple settlements and logistics.
  Consider bounded stock and cheap modded teleportation, not travel time alone.
- Capacity growth through commercial relationships and useful infrastructure;
  avoid population-only scaling, opaque upkeep and villager prisons.
- Books in shelves influencing enchanting, and Mending's place in maintenance.
  These do not bypass native-table limits or resume frozen expansion development.

## Next decisions

1. Finalize later purchase offers/counts alongside the approved retail track;
   preserve the settled early purchases and sales-first grouping.
2. Choose tool/ingot probabilities, repeated-tool rules, enchantment pools,
   the sixth-stage name and its progression condition.
3. Finalize acceptance requirements and prototype native matching/career
   persistence without UI stock resets or item/emerald loss.
4. Price productive routes and set stock, including cross-vendor arbitrage,
   enchanting/repair costs and World timing.
5. Prototype one complete Toolsmith loop before implementing other professions.
   Detailed specialization/commissions follow the basic catalogs.
