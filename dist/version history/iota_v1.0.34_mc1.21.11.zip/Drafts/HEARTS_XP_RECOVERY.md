# Hearts — recoverable death XP (1.0.34)

## Player behavior

Survival deaths store `floor(total XP points / 4)` in one personal recovery orb.
The remaining points stay with the player. This uses total spendable points
reconstructed from current level and progress, not 25% of levels or the historic
`XpTotal` counter. Inventory preservation remains enabled. There is no additional
vanilla XP drop. Totals below four points produce no orb and lose no points.

The orb is a small suspended, fully lit XP-themed head rendered by an
item_display, with green/yellow dust and a 0.55 × 0.55 interaction box. It is not
a placed Player Head and does not use an automatically collected XP entity.
Right-click or left-click to recover the stored points. Only the UUID owner
receives anything; other players cannot consume it. Successful recovery plays
an XP pickup sound and particles. No confirmation, item reward or Mending repair
is performed: recovered points go directly to the XP bar.

A new death forfeits any unrecovered previous amount. It stores only the new
25% loss, not both losses added together. A zero-XP death also invalidates the
previous orb. There is no time-based expiration. Records survive reloads and
disconnects. Already paid or superseded visuals disappear when their chunk is
processed; an unloaded obsolete orb cannot grant XP when it returns.

## Placement and lifecycle

For an ordinary grounded death, try LastDeathLocation. Grounded means the last
live player tick reported OnGround. Airborne, flight, falling and void cases
use the actual resolved respawn location instead. That observes the bed,
respawn anchor or world-spawn result without implementing a second spawn
resolver. This conservative rule can also send a jumping player's orb to
respawn. The fallback does not remember the last bed placed.

Before placing at a loaded death site, require two air blocks and reject
air/fluid/fire/cactus/magma/powder-snow support. Otherwise use the recorded
respawn location. This is a conservative geometric check, not a guarantee that
the route is walkable or free of mobs. It does not search for distant land.
The player's actual respawn is the final fallback; later terrain changes are
not continuously rerouted. Bedrock chambers or player-built traps can still
make retrieval inconvenient.

Death processing invalidates the old record before click processing. The XP
deduction and final placement happen at respawn. A pending death survives a
disconnect at the death screen. A fresh record has a generation, owner UUID,
amount and location. Entity scores reference that generation; the record is
authoritative even while its owner is offline. Only a successful XP grant
marks a record paid, and a second interaction cannot pay it again.

The owner retries creation while online, but only if the destination chunk is
loaded. Missing displays/hitboxes are recreated independently at that location.
No forceload is used. Entities carry no dropped-item payload and are independent
of the archived Mastery Orb. Other heads, decorations and datapack entities
are not scanned or modified. Runtime entity cleanup covers the three vanilla
dimensions; custom dimensions are outside this version's tested scope.

Command-created XP beyond the supported signed-point range is left untouched
instead of risking a reset. An attempted recovery exceeding
the signed-point limit leaves the orb unclaimed. Native floating-point XP
progress and command behavior still require in-game verification, especially
at unusually high levels. Commands or other packs that change XP while the
player is dead are not transaction-coordinated with this module.

## Tests

Death/respawn sends no automatic chat announcement about XP or the orb.
Explicit test/diagnostic commands still print their requested results.

Feedback revision: the head already uses maximum display brightness (15/15).
Its aura is more visible; successful owner pickup emits green/gold dust and
happy-villager particles with XP pickup and a soft amethyst chime on the master
sound channel. No world light is placed. Confirm effects occur once and never
for an unauthorized or repeated click; sound still follows master volume.

User reported the XP mechanic working in-game on 2026-11-18. This validates
the reported test, not every edge case below. Follow-up: recovery entities and
their rendered head are named `Experience Orb`, with no permanent overhead
label; existing loaded orbs are updated automatically.

Automated: `node tools/validate-hearts-xp.mjs` executes the actual scoreboard
total-calculation source against an independently accumulated XP curve, checks
rounding/conservation across supported values and models owner-only single
claim, replacement, independent owners and stale/zero-XP invalidation. It also
checks relevant source guards, deferred spawning and function references.
It does not execute Minecraft or validate rendering, hit detection or live XP
precision. The existing JSON/recipe and broken-tool validators remain separate.

Manual (not yet validated):

- [ ] Install the revised 1.0.34 ZIP alone, `/reload`, then use Survival.
- [ ] `/function iota_hearts:xp/test_setup` sets exactly 1,000 points (overwrites
  current XP; use a disposable test world). `/function iota_hearts:xp/diagnose`
  reports the calculated balance and current record without changing them.
- [ ] On safe solid ground, `/kill @s`, respawn: expect 750 points and an orb
  at the death location. Click it: expect 1,000, one pickup sound and no orb.
  Do not collect unrelated XP during this comparison.
- [ ] Repeat at zero and at 1–3 points: no loss or orb. Test partial-level XP
  around levels 16/17 and 31/32; confirm points rather than displayed levels.
- [ ] Leave the 250-point orb, die again with 750: expect 563 retained and a
  new 187-point orb. The old orb must never pay, including after chunk unload.
- [ ] Another player clicks first: no XP, disappearance or ownership transfer.
  Owner clicks repeatedly/with both buttons: one payout only. Test two owners.
- [ ] Leave/rejoin and `/reload` before recovery. Also disconnect on the death
  screen and respawn later: only one deduction and one active record.
- [ ] Test Nether/End deaths and cross-dimensional respawn; unload the death
  chunk before respawning, revisit and verify deferred creation.
- [ ] Test void/flight/falling deaths, lava and obstructed locations. Verify
  the fallback at the actual bed, anchor or world-spawn location.
- [ ] Change/destroy the bed before respawn: the fallback follows the actual
  resolved respawn, not a stale bed coordinate.
- [ ] Check suspended head texture, particles, clicks, pickup sound and lighting.
  Verify ordinary Player Heads and unrelated interaction entities are unaffected.
- [ ] Hearts loss/recovery, campfire acceleration and broken-tool feedback still
  work. Creative deaths do not start this Survival XP-loss mechanic.

## Texture and implementation references

Texture: [Minecraft Heads, Experience Orb #105296](https://minecraft-heads.com/custom-heads/head/105296-experience-orb),
using its published texture property. This requires no bundled resource pack;
skin texture fetching/caching is handled by the client. The visual is a custom
head, not the native animated XP-orb sprite. Dust is a particle effect, not a
collectible source of XP.

The native interaction entity records clicks and supports execute-on target
and attacker dispatch: [Java 1.19.4 official notes](https://www.minecraft.net/en-us/article/minecraft-java-edition-1-19-4).
