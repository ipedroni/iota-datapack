# Trading — three player loops

Desk research: 2026-11-18. Target: Minecraft Java 1.21.11.
Companion to [Trading Design Guidelines](../TRADING_DESIGN_GUIDELINES.md).

## Scope and evidence

The comparison baseline is vanilla with Villager Trade Rebalance enabled.
It is a research configuration, not a dependency of the final Iota module.
These findings do not restore the discarded Trading prototype, approve a new
catalog or change gameplay. Expansions remain frozen.

Official release notes establish the design changes below. Target-version
generated experimental tags independently identify desert Efficiency and swamp
Mending in `vendor/generated/data/minecraft/datapacks/trade_rebalance/data/minecraft/tags/enchantment/trades/`.
Historical notes explain intent; they are not a measured 1.21.11 price table.
Exact offer probabilities, quantities, costs and throughput must be captured in
the target game before numeric balancing. No emerald/hour or completion-time
results are claimed here.

Separate first access from repeat supply. A demanding initial expedition can
produce a convenient recurring service; repeating that expedition for every
purchase is a different design. Also separate material production, converting
goods into emeralds, and converting emeralds into the desired item. Each can
become the bottleneck independently.

## 1. Initial equipment acquisition

Example goal: acquire an iron pickaxe and useful protection, then consider a
diamond upgrade. This is a player goal across professions, not an approved kit.

**Route:** find a village → identify the relevant workers/offers → earn emeralds
from an available buyer → develop the sellers when necessary → buy the equipment
→ use, maintain or replace it. Compare against mining, crafting and found loot.

| Dimension | What to examine |
| --- | --- |
| Access | Distance to a village, available workers, workstation materials and safety. A nearby village is a substantial world-seed advantage. |
| Discovery | Seeing a current offer is straightforward; knowing which future level provides the desired piece is less transparent. Record failed searches separately from useful travel. |
| Price | Include the effort to obtain goods the village actually buys, intermediate sales and purchases used to level a worker. Deduct useful outputs from those transactions rather than treating everything as waste. |
| Capacity | One player's first equipment requires few units. Offer availability and unlocks can matter more than stock; replacements or multiplayer change that. |
| Replenishment | A recurring replacement supplier has greater long-term value than the first purchase suggests. Measure wear and repair alternatives too. |
| Progression | Trading can offer a legitimate farming-to-equipment route. It becomes dominant if it outperforms gathering/crafting at almost every stage with no meaningful trade-off. |
| Geography | Regional armorer differences create reasons to travel, but not every early purchase should require a continental search. |
| Infrastructure | A safe workplace and a useful income source are understandable investments. Determine whether additional workers support distinct services or merely duplicate exhausted stock. |
| Alternatives | Compare the same usable outcome, including enchantments, durability and travel; an enchanted purchased item is not equivalent to an unenchanted crafted one. |

The experimental armorer asks for diamonds alongside emeralds for diamond
armor, while supporting early iron equipment and shields. This preserves some
material acquisition while offering a service. It does not establish a general
rule that all smith professions use that payment or that diamond equipment is
removed from commerce. [Official armorer changes](https://www.minecraft.net/en-us/article/minecraft-1-20-2-pre-release-1).

**Interpretation:** choosing between self-supply and commerce, protecting a
worker and building income can be meaningful. Buying unwanted goods solely to
fill a progress bar, repeatedly searching for one missing offer, or standing
idle for stock adds weaker decisions. The same progression purchase can be
useful to one playstyle and filler to another; record the outcome rather than
labeling every leveling transaction a tax.

**Question for catalog design:** what useful service does each equipment
profession provide before, during and after the player's first diamond gear?
Do not answer this merely by adding more equipment entries.

## 2. Obtaining a specific enchantment

Study Mending as a maintenance-changing goal and Efficiency as a repeatable
performance goal. They should not be valued solely by their displayed level.

**Route:** identify a source → reach the appropriate region → obtain/develop a
matching librarian → finance the book and any prerequisite trades → obtain the
book → apply it with an anvil → return for later copies if desired.

The experiment assigns special books to regional master librarians, including
Mending to swamp and Efficiency to desert. Jungle and swamp variants have no
naturally generated villages. This moves part of acquisition from workstation
rerolling toward travel and settlement work. It also creates an information
problem: a new player must discover the regional rule and the missing-village
exception. [Official librarian changes](https://www.minecraft.net/en-us/article/minecraft-snapshot-23w31a).

| Dimension | What to examine |
| --- | --- |
| Access | Geography, suitable villager variant, safe workplace and route back; an existing developed village differs sharply from starting from nothing. |
| Discovery | Separate learning where a book belongs from random offer searches. External wiki lookup is a cost the game UI may fail to communicate. |
| Price | Book payment plus ordinary book ingredients, worker development and application XP. If combining lower-level books, include every copy and anvil operation. |
| Capacity | One Mending purchase solves one item's need; equipping a collection or replacing losses creates repeated demand. |
| Replenishment | Once established, a supplier turns a discovery into recurring access. Test the second and tenth purchase separately from the first. |
| Progression | Mending changes maintenance toward XP collection; Efficiency changes work rate. Their effects extend into other resource markets. |
| Geography | Compare visiting a regional settlement, maintaining a satellite base and transporting workers. Do not assume transport is the intended or only solution. |
| Infrastructure | Routes, protection, income and XP sources can support several activities. Count shared benefits and avoid charging their entire cost to one book. |
| Alternatives | Compare structure loot and other eligible sources. The Enchanting Table is an alternative for eligible enchantments, not a vanilla route to Mending. |

Experimental loot changes also favor Mending books in Ancient Cities and
Efficiency books in mineshafts. These are alternative acquisition opportunities,
not guaranteed success from each chest. [Official loot changes](https://www.minecraft.net/en-us/article/minecraft-1-20-2-pre-release-1).

**Interpretation:** finding a region and making a durable relationship there
can be a conquest. Repeatedly replacing a workstation is chiefly another draw
from a random pool. However, replacing rerolls with long mandatory transport
does not automatically produce a better experience. Assess how much the player
can plan, choose and learn, and how reliably the investment reaches its goal.

Mending's first copy and its permanent supply are distinct rewards. It is
possible to make initial access demanding without making every replacement
tedious. Conversely, cheap permanent supply can overwhelm finite loot as a
source after the first purchase. No restriction or guarantee is selected yet.

In Iota comparisons, keep base Tools anvil changes separate from vanilla costs.
Only run optional Tool Mastery/Magical Discovery comparisons afterward; their
rewards and discovery behavior would otherwise obscure the Trading baseline.
Teaching books to librarians remains a future specialization concept.

## 3. Buying building materials in bulk

Example goals: obtain 1,024 finished bricks, then 1,024 quartz blocks. These are
test quantities, not proposed trade outputs. Test more than one material:
different gathering and processing chains produce different opportunity costs.

**Route:** select a palette → locate/develop a Mason with the relevant offer →
produce saleable goods → earn emeralds → buy stock → wait, diversify suppliers
or gather the remainder → transport and place the materials.

| Dimension | What to examine |
| --- | --- |
| Access | Availability of the precise material matters more than the number of superficially similar entries. |
| Discovery | Choosing a palette can be enjoyable; repeated worker searches for one color can obstruct the construction goal. |
| Price | Compare finished usable blocks. Include gathering, smelting fuel, transformations, trips and sales, not just the price of raw ingredients. |
| Capacity | A financially affordable building may still require many stock cycles. Calculate both emerald demand and purchase capacity. |
| Replenishment | Observe real working schedules and accessible workplaces. Distinguish stock exhausted, seller not working and unloaded chunks. |
| Progression | Construction supply can reduce repetitive extraction without replacing the achievement of acquiring high-performance equipment. Treat these goals separately. |
| Geography | Local availability, collection trips and regional outposts can support exploration. Repeated empty travel after establishing supply can instead become overhead. |
| Infrastructure | Transport and storage are useful investments. Check whether throughput mainly rewards practical logistics or sheer villager multiplication. |
| Alternatives | Direct extraction, processing and mixed sourcing should remain credible, especially for modest projects and nearby deposits. |

Vanilla prices respond to demand and reputation, and working villagers can
restock up to twice per day. A displayed unit price therefore does not describe
the whole supply contract. [Official trading changes](https://www.minecraft.net/en-us/article/village---pillage-out-java-).

For a measured offer producing `q` items per purchase with `u` remaining uses,
current stock supplies `q × u` items. A project needing `B` items requires
`ceil(B / q)` purchases before price changes. Capture actual refills rather than
assuming a fixed hourly output. Initial stock is separate from recurring output.

**Interpretation:** bulk construction is where stock can matter more than
price. Increasing payment generosity alone may leave the builder idle and
encourage more duplicate villagers. Compare limits before increasing catalog
size or emerald income. This supports the Mason-as-supplier idea without yet
approving any particular product, quantity or price.

## Iota interactions requiring separate measurement

- **World:** the extended day/night cycle and sleep time jumps can interact
  with work windows and restocking. Do not multiply a vanilla hourly rate by a
  guessed factor; measure stock recovery with and without World, including
  daytime sleep. This is an integration question, not a confirmed restock bug.
- **Recipes:** compare finished building quantities using Iota's shape yields,
  stonecutter routes and reversible recipes. Reject buy/transform/sell loops
  that create unbounded profit solely through conversion.
- **Drops:** changed resource supplies can change the effort behind an emerald.
- **Tools:** repair ingredients, prior-work clearing and anvil enchantment costs
  affect equipment ownership and the value of replacement/Mending.
- **Hearts:** preservation of inventory changes equipment replacement pressure.
  Do not assume vanilla death losses describe Iota demand.
- **Expansions:** test separately and optionally; the base Trading design must
  work without either expansion.

## Measurement protocol — not yet executed

Run the same goals in (A) unmodified 1.21.11 with the experiment and (B) that
baseline plus Iota base. Document seed, difficulty, feature flags, installed
modules, starting resources and whether the player already knows the route.
Use fresh offers for clean comparisons; distinguish natural progression from
controlled fixtures. Test ordinary prices first, then discounts as sensitivity
cases. Do not require curing or raid rewards for the baseline to be viable.

For each goal, record first completion and repeat supply with these fields:

| Record | Purpose |
| --- | --- |
| Starting/ending resources and useful intermediate outputs | Reveal actual net cost and co-products. |
| Active gathering, travel, processing, trading and idle time | Separate play from waiting without reducing the analysis to duration. |
| Income offers and output offers, counts and price changes | Find the bottleneck on either side of the market. |
| Worker levels, offer availability, stock/refills and loaded work time | Separate unlock, capacity and schedule constraints. |
| Infrastructure built and later uses | Distinguish first investment from recurring cost. |
| Decisions, newly learned information, danger and repeated actions | Assess the quality of the journey. |
| Direct gathering/crafting/loot alternative | Check whether commerce is an option or an overwhelmingly dominant route. |

Compare farming, mining and exploration income at similar development stages.
Report active yield, sustainable session throughput, investment and idle
production separately. A mature automated farm is not comparable to a new
player gathering by hand solely because both sessions lasted thirty minutes.
Use multiple seeds or explicitly label one-world observations as such.

## Findings and next decisions

User accepted the three-loop analysis on 2026-11-18. This approves its design
reasoning, not unexecuted measurements or any new trade catalog. The World
restocking interaction is explicitly tracked in ../../TEST_CHECKLIST.md as required
integration work; it remains unmeasured.
Subsequent approved directions and the evolving Toolsmith catalog are kept in
[Trading Design Guidelines](../TRADING_DESIGN_GUIDELINES.md). This research document
retains its original comparison scope and does not supersede those decisions.

The three loops emphasize different constraints: first-access cost for basic
equipment, discovery plus recurring access for books, and throughput for bulk
construction. These are design interpretations, not measured balance results.

Proceed to basic profession roles and catalogs using these findings. For each
proposed offer, state its player purpose, first-access conditions, recurring
capacity and credible alternative before choosing numbers. Carry exact pricing,
restock throughput and the World interaction into the measurement pass. Only
after basic catalogs should specialization, regional demand or commissions be
designed. None of those mechanics is approved by this study alone.
