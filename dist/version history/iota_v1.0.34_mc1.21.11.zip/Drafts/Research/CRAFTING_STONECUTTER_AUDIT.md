# Crafting table and Stonecutter audit

Baseline scope: Minecraft Java 1.21.11 vanilla registry data plus the current Iota module sources. This includes staged Recipes additions. The experimental Mastery Orb and recipes with dynamic outputs are outside the comparison.

This audit compares each Stonecutter recipe with all fixed-output crafting recipes for the same item. A direct overlap has at least one input material that can be used in every crafting slot. Yield is measured per unit of that common material. An alternate route uses different crafting inputs. Some outputs appear in both sections because the Stonecutter can accept several source blocks.

| Measure | Count |
| --- | ---: |
| Stonecutter recipes | 254 |
| Outputs also crafted at the table | 171 |
| Stonecutter recipes with a direct overlap | 152 |
| Stonecutter recipes with only alternate crafting inputs | 102 |
| Stonecutter recipes without a fixed-output crafting equivalent | 0 |
| Direct overlaps: Same yield | 91 |
| Direct overlaps: Better yield | 61 |

## Review of the 91 equal-yield recipes

| Family | Recipes | Crafting table batch | Stonecutter batch |
| --- | ---: | --- | --- |
| Slabs | 48 | 3 blocks → 6 slabs | 1 block → 2 slabs |
| Walls | 26 | 6 blocks → 6 walls | 1 block → 1 wall |
| Polished blocks, bricks and other variants | 17 | 4 → 4, or 2 → 2 for quartz pillars | 1 → 1 |

## Final decisions and automated review — 1.0.19

The tables below record the VANILLA baseline; they are not current Iota yields.
Finished variants are Stonecutter-exclusive, except moss addition and waxing.
Shape production remains at both stations: slabs 3→6, stairs 6→12 (mirrored),
walls 6→6 at the table; slabs/stairs 1→2 and walls 1→1 at the Stonecutter.
The 254 vanilla cutting routes are retained with updated stair outputs; 26
wooden routes are added. Stonecutter construction retains its vanilla recipe.
All raw-copper stair shortcuts now output two; processing Cut Copper first is
more efficient. This is intentional under the uniform two-stair decision.

Exact filters cover 197 lower-pack recipes. The module restores 145 shape
recipes under their original IDs; the remaining 52 finishing recipes are absent
from the crafting table. Filters do not target other namespaces. Compatible
packs using those exact Minecraft IDs at lower priority are also filtered.
Mossy recipes, waxing, Chiseled Bookshelves and multi-ingredient assembly remain.
The complete filter manifest is STONECUTTER_REMOVED_RECIPES.json.

Recovery at the table consists of 203 recipes with inventory unlocks:
61 slab recoveries (two identical slabs vertically → one block), 116 stair
recoveries (58 materials, horizontal or vertical pairs → one block), and 26 wall
recoveries (two rows of three identical walls → six blocks). Final material,
species, moss, oxidation and wax are retained.

Automated validation: all 827 module JSON/metadata files parse; all recovery
patterns/unlocks match; all 58 stair crafting recipes yield twelve. The material
graph contains 1,095 single-material edges and no multiplying cycles, including
copper shortcuts and reclaiming. It excludes tag expansion and exchanges with
multiple different ingredients; world placement and UI behavior require manual
tests. Run node tools/build-stonecutter.mjs then node tools/validate-recipes.mjs.
No server-loading test is performed; the user will validate in a test world.

## Direct overlaps

| Output | Stonecutter | Crafting table | Stonecutter yield | Stonecutter recipe ID |
| --- | --- | --- | --- | --- |
| andesite_slab | 1 × andesite → 2 | 3 × andesite → 6 | Same yield | andesite_slab_from_andesite_stonecutting |
| andesite_stairs | 1 × andesite → 1 | 6 × andesite → 4 | Better yield | andesite_stairs_from_andesite_stonecutting |
| andesite_wall | 1 × andesite → 1 | 6 × andesite → 6 | Same yield | andesite_wall_from_andesite_stonecutting |
| blackstone_slab | 1 × blackstone → 2 | 3 × blackstone → 6 | Same yield | blackstone_slab_from_blackstone_stonecutting |
| blackstone_stairs | 1 × blackstone → 1 | 6 × blackstone → 4 | Better yield | blackstone_stairs_from_blackstone_stonecutting |
| blackstone_wall | 1 × blackstone → 1 | 6 × blackstone → 6 | Same yield | blackstone_wall_from_blackstone_stonecutting |
| brick_slab | 1 × bricks → 2 | 3 × bricks → 6 | Same yield | brick_slab_from_bricks_stonecutting |
| brick_stairs | 1 × bricks → 1 | 6 × bricks → 4 | Better yield | brick_stairs_from_bricks_stonecutting |
| brick_wall | 1 × bricks → 1 | 6 × bricks → 6 | Same yield | brick_wall_from_bricks_stonecutting |
| cobbled_deepslate_slab | 1 × cobbled_deepslate → 2 | 3 × cobbled_deepslate → 6 | Same yield | cobbled_deepslate_slab_from_cobbled_deepslate_stonecutting |
| cobbled_deepslate_stairs | 1 × cobbled_deepslate → 1 | 6 × cobbled_deepslate → 4 | Better yield | cobbled_deepslate_stairs_from_cobbled_deepslate_stonecutting |
| cobbled_deepslate_wall | 1 × cobbled_deepslate → 1 | 6 × cobbled_deepslate → 6 | Same yield | cobbled_deepslate_wall_from_cobbled_deepslate_stonecutting |
| cobblestone_slab | 1 × cobblestone → 2 | 3 × cobblestone → 6 | Same yield | cobblestone_slab_from_cobblestone_stonecutting |
| cobblestone_stairs | 1 × cobblestone → 1 | 6 × cobblestone → 4 | Better yield | cobblestone_stairs_from_cobblestone_stonecutting |
| cobblestone_wall | 1 × cobblestone → 1 | 6 × cobblestone → 6 | Same yield | cobblestone_wall_from_cobblestone_stonecutting |
| copper_grate | 1 × copper_block → 4 | 4 × copper_block → 4 | Better yield | copper_grate_from_copper_block_stonecutting |
| cut_copper | 1 × copper_block → 4 | 4 × copper_block → 4 | Better yield | cut_copper_from_copper_block_stonecutting |
| cut_copper_slab | 1 × cut_copper → 2 | 3 × cut_copper → 6 | Same yield | cut_copper_slab_from_cut_copper_stonecutting |
| cut_copper_stairs | 1 × cut_copper → 1 | 6 × cut_copper → 4 | Better yield | cut_copper_stairs_from_cut_copper_stonecutting |
| cut_red_sandstone | 1 × red_sandstone → 1 | 4 × red_sandstone → 4 | Same yield | cut_red_sandstone_from_red_sandstone_stonecutting |
| cut_red_sandstone_slab | 1 × cut_red_sandstone → 2 | 3 × cut_red_sandstone → 6 | Same yield | cut_red_sandstone_slab_from_cut_red_sandstone_stonecutting |
| cut_sandstone | 1 × sandstone → 1 | 4 × sandstone → 4 | Same yield | cut_sandstone_from_sandstone_stonecutting |
| cut_sandstone_slab | 1 × cut_sandstone → 2 | 3 × cut_sandstone → 6 | Same yield | cut_sandstone_slab_from_cut_sandstone_stonecutting |
| dark_prismarine_slab | 1 × dark_prismarine → 2 | 3 × dark_prismarine → 6 | Same yield | dark_prismarine_slab_from_dark_prismarine_stonecutting |
| dark_prismarine_stairs | 1 × dark_prismarine → 1 | 6 × dark_prismarine → 4 | Better yield | dark_prismarine_stairs_from_dark_prismarine_stonecutting |
| deepslate_brick_slab | 1 × deepslate_bricks → 2 | 3 × deepslate_bricks → 6 | Same yield | deepslate_brick_slab_from_deepslate_bricks_stonecutting |
| deepslate_brick_stairs | 1 × deepslate_bricks → 1 | 6 × deepslate_bricks → 4 | Better yield | deepslate_brick_stairs_from_deepslate_bricks_stonecutting |
| deepslate_brick_wall | 1 × deepslate_bricks → 1 | 6 × deepslate_bricks → 6 | Same yield | deepslate_brick_wall_from_deepslate_bricks_stonecutting |
| deepslate_bricks | 1 × polished_deepslate → 1 | 4 × polished_deepslate → 4 | Same yield | deepslate_bricks_from_polished_deepslate_stonecutting |
| deepslate_tile_slab | 1 × deepslate_tiles → 2 | 3 × deepslate_tiles → 6 | Same yield | deepslate_tile_slab_from_deepslate_tiles_stonecutting |
| deepslate_tile_stairs | 1 × deepslate_tiles → 1 | 6 × deepslate_tiles → 4 | Better yield | deepslate_tile_stairs_from_deepslate_tiles_stonecutting |
| deepslate_tile_wall | 1 × deepslate_tiles → 1 | 6 × deepslate_tiles → 6 | Same yield | deepslate_tile_wall_from_deepslate_tiles_stonecutting |
| deepslate_tiles | 1 × deepslate_bricks → 1 | 4 × deepslate_bricks → 4 | Same yield | deepslate_tiles_from_deepslate_bricks_stonecutting |
| diorite_slab | 1 × diorite → 2 | 3 × diorite → 6 | Same yield | diorite_slab_from_diorite_stonecutting |
| diorite_stairs | 1 × diorite → 1 | 6 × diorite → 4 | Better yield | diorite_stairs_from_diorite_stonecutting |
| diorite_wall | 1 × diorite → 1 | 6 × diorite → 6 | Same yield | diorite_wall_from_diorite_stonecutting |
| end_stone_brick_slab | 1 × end_stone_bricks → 2 | 3 × end_stone_bricks → 6 | Same yield | end_stone_brick_slab_from_end_stone_brick_stonecutting |
| end_stone_brick_stairs | 1 × end_stone_bricks → 1 | 6 × end_stone_bricks → 4 | Better yield | end_stone_brick_stairs_from_end_stone_brick_stonecutting |
| end_stone_brick_wall | 1 × end_stone_bricks → 1 | 6 × end_stone_bricks → 6 | Same yield | end_stone_brick_wall_from_end_stone_brick_stonecutting |
| end_stone_bricks | 1 × end_stone → 1 | 4 × end_stone → 4 | Same yield | end_stone_bricks_from_end_stone_stonecutting |
| exposed_copper_grate | 1 × exposed_copper → 4 | 4 × exposed_copper → 4 | Better yield | exposed_copper_grate_from_exposed_copper_stonecutting |
| exposed_cut_copper | 1 × exposed_copper → 4 | 4 × exposed_copper → 4 | Better yield | exposed_cut_copper_from_exposed_copper_stonecutting |
| exposed_cut_copper_slab | 1 × exposed_cut_copper → 2 | 3 × exposed_cut_copper → 6 | Same yield | exposed_cut_copper_slab_from_exposed_cut_copper_stonecutting |
| exposed_cut_copper_stairs | 1 × exposed_cut_copper → 1 | 6 × exposed_cut_copper → 4 | Better yield | exposed_cut_copper_stairs_from_exposed_cut_copper_stonecutting |
| granite_slab | 1 × granite → 2 | 3 × granite → 6 | Same yield | granite_slab_from_granite_stonecutting |
| granite_stairs | 1 × granite → 1 | 6 × granite → 4 | Better yield | granite_stairs_from_granite_stonecutting |
| granite_wall | 1 × granite → 1 | 6 × granite → 6 | Same yield | granite_wall_from_granite_stonecutting |
| mossy_cobblestone_slab | 1 × mossy_cobblestone → 2 | 3 × mossy_cobblestone → 6 | Same yield | mossy_cobblestone_slab_from_mossy_cobblestone_stonecutting |
| mossy_cobblestone_stairs | 1 × mossy_cobblestone → 1 | 6 × mossy_cobblestone → 4 | Better yield | mossy_cobblestone_stairs_from_mossy_cobblestone_stonecutting |
| mossy_cobblestone_wall | 1 × mossy_cobblestone → 1 | 6 × mossy_cobblestone → 6 | Same yield | mossy_cobblestone_wall_from_mossy_cobblestone_stonecutting |
| mossy_stone_brick_slab | 1 × mossy_stone_bricks → 2 | 3 × mossy_stone_bricks → 6 | Same yield | mossy_stone_brick_slab_from_mossy_stone_brick_stonecutting |
| mossy_stone_brick_stairs | 1 × mossy_stone_bricks → 1 | 6 × mossy_stone_bricks → 4 | Better yield | mossy_stone_brick_stairs_from_mossy_stone_brick_stonecutting |
| mossy_stone_brick_wall | 1 × mossy_stone_bricks → 1 | 6 × mossy_stone_bricks → 6 | Same yield | mossy_stone_brick_wall_from_mossy_stone_brick_stonecutting |
| mud_brick_slab | 1 × mud_bricks → 2 | 3 × mud_bricks → 6 | Same yield | mud_brick_slab_from_mud_bricks_stonecutting |
| mud_brick_stairs | 1 × mud_bricks → 1 | 6 × mud_bricks → 4 | Better yield | mud_brick_stairs_from_mud_bricks_stonecutting |
| mud_brick_wall | 1 × mud_bricks → 1 | 6 × mud_bricks → 6 | Same yield | mud_brick_wall_from_mud_bricks_stonecutting |
| nether_brick_slab | 1 × nether_bricks → 2 | 3 × nether_bricks → 6 | Same yield | nether_brick_slab_from_nether_bricks_stonecutting |
| nether_brick_stairs | 1 × nether_bricks → 1 | 6 × nether_bricks → 4 | Better yield | nether_brick_stairs_from_nether_bricks_stonecutting |
| nether_brick_wall | 1 × nether_bricks → 1 | 6 × nether_bricks → 6 | Same yield | nether_brick_wall_from_nether_bricks_stonecutting |
| oxidized_copper_grate | 1 × oxidized_copper → 4 | 4 × oxidized_copper → 4 | Better yield | oxidized_copper_grate_from_oxidized_copper_stonecutting |
| oxidized_cut_copper | 1 × oxidized_copper → 4 | 4 × oxidized_copper → 4 | Better yield | oxidized_cut_copper_from_oxidized_copper_stonecutting |
| oxidized_cut_copper_slab | 1 × oxidized_cut_copper → 2 | 3 × oxidized_cut_copper → 6 | Same yield | oxidized_cut_copper_slab_from_oxidized_cut_copper_stonecutting |
| oxidized_cut_copper_stairs | 1 × oxidized_cut_copper → 1 | 6 × oxidized_cut_copper → 4 | Better yield | oxidized_cut_copper_stairs_from_oxidized_cut_copper_stonecutting |
| polished_andesite | 1 × andesite → 1 | 4 × andesite → 4 | Same yield | polished_andesite_from_andesite_stonecutting |
| polished_andesite_slab | 1 × polished_andesite → 2 | 3 × polished_andesite → 6 | Same yield | polished_andesite_slab_from_polished_andesite_stonecutting |
| polished_andesite_stairs | 1 × polished_andesite → 1 | 6 × polished_andesite → 4 | Better yield | polished_andesite_stairs_from_polished_andesite_stonecutting |
| polished_basalt | 1 × basalt → 1 | 4 × basalt → 4 | Same yield | polished_basalt_from_basalt_stonecutting |
| polished_blackstone | 1 × blackstone → 1 | 4 × blackstone → 4 | Same yield | polished_blackstone_from_blackstone_stonecutting |
| polished_blackstone_brick_slab | 1 × polished_blackstone_bricks → 2 | 3 × polished_blackstone_bricks → 6 | Same yield | polished_blackstone_brick_slab_from_polished_blackstone_bricks_stonecutting |
| polished_blackstone_brick_stairs | 1 × polished_blackstone_bricks → 1 | 6 × polished_blackstone_bricks → 4 | Better yield | polished_blackstone_brick_stairs_from_polished_blackstone_bricks_stonecutting |
| polished_blackstone_brick_wall | 1 × polished_blackstone_bricks → 1 | 6 × polished_blackstone_bricks → 6 | Same yield | polished_blackstone_brick_wall_from_polished_blackstone_bricks_stonecutting |
| polished_blackstone_bricks | 1 × polished_blackstone → 1 | 4 × polished_blackstone → 4 | Same yield | polished_blackstone_bricks_from_polished_blackstone_stonecutting |
| polished_blackstone_slab | 1 × polished_blackstone → 2 | 3 × polished_blackstone → 6 | Same yield | polished_blackstone_slab_from_polished_blackstone_stonecutting |
| polished_blackstone_stairs | 1 × polished_blackstone → 1 | 6 × polished_blackstone → 4 | Better yield | polished_blackstone_stairs_from_polished_blackstone_stonecutting |
| polished_blackstone_wall | 1 × polished_blackstone → 1 | 6 × polished_blackstone → 6 | Same yield | polished_blackstone_wall_from_polished_blackstone_stonecutting |
| polished_deepslate | 1 × cobbled_deepslate → 1 | 4 × cobbled_deepslate → 4 | Same yield | polished_deepslate_from_cobbled_deepslate_stonecutting |
| polished_deepslate_slab | 1 × polished_deepslate → 2 | 3 × polished_deepslate → 6 | Same yield | polished_deepslate_slab_from_polished_deepslate_stonecutting |
| polished_deepslate_stairs | 1 × polished_deepslate → 1 | 6 × polished_deepslate → 4 | Better yield | polished_deepslate_stairs_from_polished_deepslate_stonecutting |
| polished_deepslate_wall | 1 × polished_deepslate → 1 | 6 × polished_deepslate → 6 | Same yield | polished_deepslate_wall_from_polished_deepslate_stonecutting |
| polished_diorite | 1 × diorite → 1 | 4 × diorite → 4 | Same yield | polished_diorite_from_diorite_stonecutting |
| polished_diorite_slab | 1 × polished_diorite → 2 | 3 × polished_diorite → 6 | Same yield | polished_diorite_slab_from_polished_diorite_stonecutting |
| polished_diorite_stairs | 1 × polished_diorite → 1 | 6 × polished_diorite → 4 | Better yield | polished_diorite_stairs_from_polished_diorite_stonecutting |
| polished_granite | 1 × granite → 1 | 4 × granite → 4 | Same yield | polished_granite_from_granite_stonecutting |
| polished_granite_slab | 1 × polished_granite → 2 | 3 × polished_granite → 6 | Same yield | polished_granite_slab_from_polished_granite_stonecutting |
| polished_granite_stairs | 1 × polished_granite → 1 | 6 × polished_granite → 4 | Better yield | polished_granite_stairs_from_polished_granite_stonecutting |
| polished_tuff | 1 × tuff → 1 | 4 × tuff → 4 | Same yield | polished_tuff_from_tuff_stonecutting |
| polished_tuff_slab | 1 × polished_tuff → 2 | 3 × polished_tuff → 6 | Same yield | polished_tuff_slab_from_polished_tuff_stonecutting |
| polished_tuff_stairs | 1 × polished_tuff → 1 | 6 × polished_tuff → 4 | Better yield | polished_tuff_stairs_from_polished_tuff_stonecutting |
| polished_tuff_wall | 1 × polished_tuff → 1 | 6 × polished_tuff → 6 | Same yield | polished_tuff_wall_from_polished_tuff_stonecutting |
| prismarine_brick_slab | 1 × prismarine_bricks → 2 | 3 × prismarine_bricks → 6 | Same yield | prismarine_brick_slab_from_prismarine_stonecutting |
| prismarine_brick_stairs | 1 × prismarine_bricks → 1 | 6 × prismarine_bricks → 4 | Better yield | prismarine_brick_stairs_from_prismarine_stonecutting |
| prismarine_slab | 1 × prismarine → 2 | 3 × prismarine → 6 | Same yield | prismarine_slab_from_prismarine_stonecutting |
| prismarine_stairs | 1 × prismarine → 1 | 6 × prismarine → 4 | Better yield | prismarine_stairs_from_prismarine_stonecutting |
| prismarine_wall | 1 × prismarine → 1 | 6 × prismarine → 6 | Same yield | prismarine_wall_from_prismarine_stonecutting |
| purpur_slab | 1 × purpur_block → 2 | 3 × purpur_block or purpur_pillar → 6 | Same yield | purpur_slab_from_purpur_block_stonecutting |
| purpur_stairs | 1 × purpur_block → 1 | 6 × purpur_block or purpur_pillar → 4 | Better yield | purpur_stairs_from_purpur_block_stonecutting |
| quartz_bricks | 1 × quartz_block → 1 | 4 × quartz_block → 4 | Same yield | quartz_bricks_from_quartz_block_stonecutting |
| quartz_pillar | 1 × quartz_block → 1 | 2 × quartz_block → 2 | Same yield | quartz_pillar_from_quartz_block_stonecutting |
| quartz_slab | 1 × quartz_block → 2 | 3 × chiseled_quartz_block or quartz_block or quartz_pillar → 6 | Same yield | quartz_slab_from_stonecutting |
| quartz_stairs | 1 × quartz_block → 1 | 6 × chiseled_quartz_block or quartz_block or quartz_pillar → 4 | Better yield | quartz_stairs_from_quartz_block_stonecutting |
| red_nether_brick_slab | 1 × red_nether_bricks → 2 | 3 × red_nether_bricks → 6 | Same yield | red_nether_brick_slab_from_red_nether_bricks_stonecutting |
| red_nether_brick_stairs | 1 × red_nether_bricks → 1 | 6 × red_nether_bricks → 4 | Better yield | red_nether_brick_stairs_from_red_nether_bricks_stonecutting |
| red_nether_brick_wall | 1 × red_nether_bricks → 1 | 6 × red_nether_bricks → 6 | Same yield | red_nether_brick_wall_from_red_nether_bricks_stonecutting |
| red_sandstone_slab | 1 × red_sandstone → 2 | 3 × red_sandstone or chiseled_red_sandstone → 6 | Same yield | red_sandstone_slab_from_red_sandstone_stonecutting |
| red_sandstone_stairs | 1 × red_sandstone → 1 | 6 × red_sandstone or chiseled_red_sandstone or cut_red_sandstone → 4 | Better yield | red_sandstone_stairs_from_red_sandstone_stonecutting |
| red_sandstone_wall | 1 × red_sandstone → 1 | 6 × red_sandstone → 6 | Same yield | red_sandstone_wall_from_red_sandstone_stonecutting |
| resin_brick_slab | 1 × resin_bricks → 2 | 3 × resin_bricks → 6 | Same yield | resin_brick_slab_from_resin_bricks_stonecutting |
| resin_brick_stairs | 1 × resin_bricks → 1 | 6 × resin_bricks → 4 | Better yield | resin_brick_stairs_from_resin_bricks_stonecutting |
| resin_brick_wall | 1 × resin_bricks → 1 | 6 × resin_bricks → 6 | Same yield | resin_brick_wall_from_resin_bricks_stonecutting |
| sandstone_slab | 1 × sandstone → 2 | 3 × sandstone or chiseled_sandstone → 6 | Same yield | sandstone_slab_from_sandstone_stonecutting |
| sandstone_stairs | 1 × sandstone → 1 | 6 × sandstone or chiseled_sandstone or cut_sandstone → 4 | Better yield | sandstone_stairs_from_sandstone_stonecutting |
| sandstone_wall | 1 × sandstone → 1 | 6 × sandstone → 6 | Same yield | sandstone_wall_from_sandstone_stonecutting |
| smooth_quartz_slab | 1 × smooth_quartz → 2 | 3 × smooth_quartz → 6 | Same yield | smooth_quartz_slab_from_smooth_quartz_stonecutting |
| smooth_quartz_stairs | 1 × smooth_quartz → 1 | 6 × smooth_quartz → 4 | Better yield | smooth_quartz_stairs_from_smooth_quartz_stonecutting |
| smooth_red_sandstone_slab | 1 × smooth_red_sandstone → 2 | 3 × smooth_red_sandstone → 6 | Same yield | smooth_red_sandstone_slab_from_smooth_red_sandstone_stonecutting |
| smooth_red_sandstone_stairs | 1 × smooth_red_sandstone → 1 | 6 × smooth_red_sandstone → 4 | Better yield | smooth_red_sandstone_stairs_from_smooth_red_sandstone_stonecutting |
| smooth_sandstone_slab | 1 × smooth_sandstone → 2 | 3 × smooth_sandstone → 6 | Same yield | smooth_sandstone_slab_from_smooth_sandstone_stonecutting |
| smooth_sandstone_stairs | 1 × smooth_sandstone → 1 | 6 × smooth_sandstone → 4 | Better yield | smooth_sandstone_stairs_from_smooth_sandstone_stonecutting |
| smooth_stone_slab | 1 × smooth_stone → 2 | 3 × smooth_stone → 6 | Same yield | smooth_stone_slab_from_smooth_stone_stonecutting |
| stone_brick_slab | 1 × stone_bricks → 2 | 3 × stone_bricks → 6 | Same yield | stone_brick_slab_from_stone_bricks_stonecutting |
| stone_brick_stairs | 1 × stone_bricks → 1 | 6 × stone_bricks → 4 | Better yield | stone_brick_stairs_from_stone_bricks_stonecutting |
| stone_brick_wall | 1 × stone_bricks → 1 | 6 × stone_bricks → 6 | Same yield | stone_brick_wall_from_stone_bricks_stonecutting |
| stone_bricks | 1 × stone → 1 | 4 × stone → 4 | Same yield | stone_bricks_from_stone_stonecutting |
| stone_slab | 1 × stone → 2 | 3 × stone → 6 | Same yield | stone_slab_from_stone_stonecutting |
| stone_stairs | 1 × stone → 1 | 6 × stone → 4 | Better yield | stone_stairs_from_stone_stonecutting |
| tuff_brick_slab | 1 × tuff_bricks → 2 | 3 × tuff_bricks → 6 | Same yield | tuff_brick_slab_from_tuff_bricks_stonecutting |
| tuff_brick_stairs | 1 × tuff_bricks → 1 | 6 × tuff_bricks → 4 | Better yield | tuff_brick_stairs_from_tuff_bricks_stonecutting |
| tuff_brick_wall | 1 × tuff_bricks → 1 | 6 × tuff_bricks → 6 | Same yield | tuff_brick_wall_from_tuff_bricks_stonecutting |
| tuff_bricks | 1 × polished_tuff → 1 | 4 × polished_tuff → 4 | Same yield | tuff_bricks_from_polished_tuff_stonecutting |
| tuff_slab | 1 × tuff → 2 | 3 × tuff → 6 | Same yield | tuff_slab_from_tuff_stonecutting |
| tuff_stairs | 1 × tuff → 1 | 6 × tuff → 4 | Better yield | tuff_stairs_from_tuff_stonecutting |
| tuff_wall | 1 × tuff → 1 | 6 × tuff → 6 | Same yield | tuff_wall_from_tuff_stonecutting |
| waxed_copper_grate | 1 × waxed_copper_block → 4 | 4 × waxed_copper_block → 4<br>1 × copper_grate + 1 × honeycomb → 1 | Better yield | waxed_copper_grate_from_waxed_copper_block_stonecutting |
| waxed_cut_copper | 1 × waxed_copper_block → 4 | 4 × waxed_copper_block → 4<br>1 × cut_copper + 1 × honeycomb → 1 | Better yield | waxed_cut_copper_from_waxed_copper_block_stonecutting |
| waxed_cut_copper_slab | 1 × waxed_cut_copper → 2 | 3 × waxed_cut_copper → 6<br>1 × cut_copper_slab + 1 × honeycomb → 1 | Same yield | waxed_cut_copper_slab_from_waxed_cut_copper_stonecutting |
| waxed_cut_copper_stairs | 1 × waxed_cut_copper → 1 | 6 × waxed_cut_copper → 4<br>1 × cut_copper_stairs + 1 × honeycomb → 1 | Better yield | waxed_cut_copper_stairs_from_waxed_cut_copper_stonecutting |
| waxed_exposed_copper_grate | 1 × waxed_exposed_copper → 4 | 4 × waxed_exposed_copper → 4<br>1 × exposed_copper_grate + 1 × honeycomb → 1 | Better yield | waxed_exposed_copper_grate_from_waxed_exposed_copper_stonecutting |
| waxed_exposed_cut_copper | 1 × waxed_exposed_copper → 4 | 4 × waxed_exposed_copper → 4<br>1 × exposed_cut_copper + 1 × honeycomb → 1 | Better yield | waxed_exposed_cut_copper_from_waxed_exposed_copper_stonecutting |
| waxed_exposed_cut_copper_slab | 1 × waxed_exposed_cut_copper → 2 | 3 × waxed_exposed_cut_copper → 6<br>1 × exposed_cut_copper_slab + 1 × honeycomb → 1 | Same yield | waxed_exposed_cut_copper_slab_from_waxed_exposed_cut_copper_stonecutting |
| waxed_exposed_cut_copper_stairs | 1 × waxed_exposed_cut_copper → 1 | 6 × waxed_exposed_cut_copper → 4<br>1 × exposed_cut_copper_stairs + 1 × honeycomb → 1 | Better yield | waxed_exposed_cut_copper_stairs_from_waxed_exposed_cut_copper_stonecutting |
| waxed_oxidized_copper_grate | 1 × waxed_oxidized_copper → 4 | 4 × waxed_oxidized_copper → 4<br>1 × oxidized_copper_grate + 1 × honeycomb → 1 | Better yield | waxed_oxidized_copper_grate_from_waxed_oxidized_copper_stonecutting |
| waxed_oxidized_cut_copper | 1 × waxed_oxidized_copper → 4 | 4 × waxed_oxidized_copper → 4<br>1 × oxidized_cut_copper + 1 × honeycomb → 1 | Better yield | waxed_oxidized_cut_copper_from_waxed_oxidized_copper_stonecutting |
| waxed_oxidized_cut_copper_slab | 1 × waxed_oxidized_cut_copper → 2 | 3 × waxed_oxidized_cut_copper → 6<br>1 × oxidized_cut_copper_slab + 1 × honeycomb → 1 | Same yield | waxed_oxidized_cut_copper_slab_from_waxed_oxidized_cut_copper_stonecutting |
| waxed_oxidized_cut_copper_stairs | 1 × waxed_oxidized_cut_copper → 1 | 6 × waxed_oxidized_cut_copper → 4<br>1 × oxidized_cut_copper_stairs + 1 × honeycomb → 1 | Better yield | waxed_oxidized_cut_copper_stairs_from_waxed_oxidized_cut_copper_stonecutting |
| waxed_weathered_copper_grate | 1 × waxed_weathered_copper → 4 | 4 × waxed_weathered_copper → 4<br>1 × weathered_copper_grate + 1 × honeycomb → 1 | Better yield | waxed_weathered_copper_grate_from_waxed_weathered_copper_stonecutting |
| waxed_weathered_cut_copper | 1 × waxed_weathered_copper → 4 | 4 × waxed_weathered_copper → 4<br>1 × weathered_cut_copper + 1 × honeycomb → 1 | Better yield | waxed_weathered_cut_copper_from_waxed_weathered_copper_stonecutting |
| waxed_weathered_cut_copper_slab | 1 × waxed_weathered_cut_copper → 2 | 3 × waxed_weathered_cut_copper → 6<br>1 × weathered_cut_copper_slab + 1 × honeycomb → 1 | Same yield | waxed_weathered_cut_copper_slab_from_waxed_weathered_cut_copper_stonecutting |
| waxed_weathered_cut_copper_stairs | 1 × waxed_weathered_cut_copper → 1 | 6 × waxed_weathered_cut_copper → 4<br>1 × weathered_cut_copper_stairs + 1 × honeycomb → 1 | Better yield | waxed_weathered_cut_copper_stairs_from_waxed_weathered_cut_copper_stonecutting |
| weathered_copper_grate | 1 × weathered_copper → 4 | 4 × weathered_copper → 4 | Better yield | weathered_copper_grate_from_weathered_copper_stonecutting |
| weathered_cut_copper | 1 × weathered_copper → 4 | 4 × weathered_copper → 4 | Better yield | weathered_cut_copper_from_weathered_copper_stonecutting |
| weathered_cut_copper_slab | 1 × weathered_cut_copper → 2 | 3 × weathered_cut_copper → 6 | Same yield | weathered_cut_copper_slab_from_weathered_cut_copper_stonecutting |
| weathered_cut_copper_stairs | 1 × weathered_cut_copper → 1 | 6 × weathered_cut_copper → 4 | Better yield | weathered_cut_copper_stairs_from_weathered_cut_copper_stonecutting |

## Alternate routes to the same output

| Output | Stonecutter | Crafting table | Stonecutter recipe ID |
| --- | --- | --- | --- |
| chiseled_copper | 1 × copper_block → 4 | 2 × cut_copper_slab → 1 | chiseled_copper_from_copper_block_stonecutting |
| chiseled_copper | 1 × cut_copper → 1 | 2 × cut_copper_slab → 1 | chiseled_copper_from_cut_copper_stonecutting |
| chiseled_deepslate | 1 × cobbled_deepslate → 1 | 2 × cobbled_deepslate_slab → 1 | chiseled_deepslate_from_cobbled_deepslate_stonecutting |
| chiseled_nether_bricks | 1 × nether_bricks → 1 | 2 × nether_brick_slab → 1 | chiseled_nether_bricks_from_nether_bricks_stonecutting |
| chiseled_polished_blackstone | 1 × blackstone → 1 | 2 × polished_blackstone_slab → 1 | chiseled_polished_blackstone_from_blackstone_stonecutting |
| chiseled_polished_blackstone | 1 × polished_blackstone → 1 | 2 × polished_blackstone_slab → 1 | chiseled_polished_blackstone_from_polished_blackstone_stonecutting |
| chiseled_quartz_block | 1 × quartz_block → 1 | 2 × quartz_slab → 1 | chiseled_quartz_block_from_quartz_block_stonecutting |
| chiseled_red_sandstone | 1 × red_sandstone → 1 | 2 × red_sandstone_slab → 1 | chiseled_red_sandstone_from_red_sandstone_stonecutting |
| chiseled_resin_bricks | 1 × resin_bricks → 1 | 2 × resin_brick_slab → 1 | chiseled_resin_bricks_from_resin_bricks_stonecutting |
| chiseled_sandstone | 1 × sandstone → 1 | 2 × sandstone_slab → 1 | chiseled_sandstone_from_sandstone_stonecutting |
| chiseled_stone_bricks | 1 × stone → 1 | 2 × stone_brick_slab → 1 | chiseled_stone_bricks_stone_from_stonecutting |
| chiseled_stone_bricks | 1 × stone_bricks → 1 | 2 × stone_brick_slab → 1 | chiseled_stone_bricks_from_stone_bricks_stonecutting |
| chiseled_tuff | 1 × tuff → 1 | 2 × tuff_slab → 1 | chiseled_tuff_from_tuff_stonecutting |
| chiseled_tuff_bricks | 1 × polished_tuff → 1 | 2 × tuff_brick_slab → 1 | chiseled_tuff_bricks_from_polished_tuff_stonecutting |
| chiseled_tuff_bricks | 1 × tuff → 1 | 2 × tuff_brick_slab → 1 | chiseled_tuff_bricks_from_tuff_stonecutting |
| chiseled_tuff_bricks | 1 × tuff_bricks → 1 | 2 × tuff_brick_slab → 1 | chiseled_tuff_bricks_from_tuff_bricks_stonecutting |
| cut_copper_slab | 1 × copper_block → 8 | 3 × cut_copper → 6 | cut_copper_slab_from_copper_block_stonecutting |
| cut_copper_stairs | 1 × copper_block → 4 | 6 × cut_copper → 4 | cut_copper_stairs_from_copper_block_stonecutting |
| cut_red_sandstone_slab | 1 × red_sandstone → 2 | 3 × cut_red_sandstone → 6 | cut_red_sandstone_slab_from_red_sandstone_stonecutting |
| cut_sandstone_slab | 1 × sandstone → 2 | 3 × cut_sandstone → 6 | cut_sandstone_slab_from_sandstone_stonecutting |
| deepslate_brick_slab | 1 × cobbled_deepslate → 2 | 3 × deepslate_bricks → 6 | deepslate_brick_slab_from_cobbled_deepslate_stonecutting |
| deepslate_brick_slab | 1 × polished_deepslate → 2 | 3 × deepslate_bricks → 6 | deepslate_brick_slab_from_polished_deepslate_stonecutting |
| deepslate_brick_stairs | 1 × cobbled_deepslate → 1 | 6 × deepslate_bricks → 4 | deepslate_brick_stairs_from_cobbled_deepslate_stonecutting |
| deepslate_brick_stairs | 1 × polished_deepslate → 1 | 6 × deepslate_bricks → 4 | deepslate_brick_stairs_from_polished_deepslate_stonecutting |
| deepslate_brick_wall | 1 × cobbled_deepslate → 1 | 6 × deepslate_bricks → 6 | deepslate_brick_wall_from_cobbled_deepslate_stonecutting |
| deepslate_brick_wall | 1 × polished_deepslate → 1 | 6 × deepslate_bricks → 6 | deepslate_brick_wall_from_polished_deepslate_stonecutting |
| deepslate_bricks | 1 × cobbled_deepslate → 1 | 4 × polished_deepslate → 4 | deepslate_bricks_from_cobbled_deepslate_stonecutting |
| deepslate_tile_slab | 1 × cobbled_deepslate → 2 | 3 × deepslate_tiles → 6 | deepslate_tile_slab_from_cobbled_deepslate_stonecutting |
| deepslate_tile_slab | 1 × deepslate_bricks → 2 | 3 × deepslate_tiles → 6 | deepslate_tile_slab_from_deepslate_bricks_stonecutting |
| deepslate_tile_slab | 1 × polished_deepslate → 2 | 3 × deepslate_tiles → 6 | deepslate_tile_slab_from_polished_deepslate_stonecutting |
| deepslate_tile_stairs | 1 × cobbled_deepslate → 1 | 6 × deepslate_tiles → 4 | deepslate_tile_stairs_from_cobbled_deepslate_stonecutting |
| deepslate_tile_stairs | 1 × deepslate_bricks → 1 | 6 × deepslate_tiles → 4 | deepslate_tile_stairs_from_deepslate_bricks_stonecutting |
| deepslate_tile_stairs | 1 × polished_deepslate → 1 | 6 × deepslate_tiles → 4 | deepslate_tile_stairs_from_polished_deepslate_stonecutting |
| deepslate_tile_wall | 1 × cobbled_deepslate → 1 | 6 × deepslate_tiles → 6 | deepslate_tile_wall_from_cobbled_deepslate_stonecutting |
| deepslate_tile_wall | 1 × deepslate_bricks → 1 | 6 × deepslate_tiles → 6 | deepslate_tile_wall_from_deepslate_bricks_stonecutting |
| deepslate_tile_wall | 1 × polished_deepslate → 1 | 6 × deepslate_tiles → 6 | deepslate_tile_wall_from_polished_deepslate_stonecutting |
| deepslate_tiles | 1 × cobbled_deepslate → 1 | 4 × deepslate_bricks → 4 | deepslate_tiles_from_cobbled_deepslate_stonecutting |
| deepslate_tiles | 1 × polished_deepslate → 1 | 4 × deepslate_bricks → 4 | deepslate_tiles_from_polished_deepslate_stonecutting |
| end_stone_brick_slab | 1 × end_stone → 2 | 3 × end_stone_bricks → 6 | end_stone_brick_slab_from_end_stone_stonecutting |
| end_stone_brick_stairs | 1 × end_stone → 1 | 6 × end_stone_bricks → 4 | end_stone_brick_stairs_from_end_stone_stonecutting |
| end_stone_brick_wall | 1 × end_stone → 1 | 6 × end_stone_bricks → 6 | end_stone_brick_wall_from_end_stone_stonecutting |
| exposed_chiseled_copper | 1 × exposed_copper → 4 | 2 × exposed_cut_copper_slab → 1 | exposed_chiseled_copper_from_exposed_copper_stonecutting |
| exposed_chiseled_copper | 1 × exposed_cut_copper → 1 | 2 × exposed_cut_copper_slab → 1 | exposed_chiseled_copper_from_exposed_cut_copper_stonecutting |
| exposed_cut_copper_slab | 1 × exposed_copper → 8 | 3 × exposed_cut_copper → 6 | exposed_cut_copper_slab_from_exposed_copper_stonecutting |
| exposed_cut_copper_stairs | 1 × exposed_copper → 4 | 6 × exposed_cut_copper → 4 | exposed_cut_copper_stairs_from_exposed_copper_stonecutting |
| oxidized_chiseled_copper | 1 × oxidized_copper → 4 | 2 × oxidized_cut_copper_slab → 1 | oxidized_chiseled_copper_from_oxidized_copper_stonecutting |
| oxidized_chiseled_copper | 1 × oxidized_cut_copper → 1 | 2 × oxidized_cut_copper_slab → 1 | oxidized_chiseled_copper_from_oxidized_cut_copper_stonecutting |
| oxidized_cut_copper_slab | 1 × oxidized_copper → 8 | 3 × oxidized_cut_copper → 6 | oxidized_cut_copper_slab_from_oxidized_copper_stonecutting |
| oxidized_cut_copper_stairs | 1 × oxidized_copper → 4 | 6 × oxidized_cut_copper → 4 | oxidized_cut_copper_stairs_from_oxidized_copper_stonecutting |
| polished_andesite_slab | 1 × andesite → 2 | 3 × polished_andesite → 6 | polished_andesite_slab_from_andesite_stonecutting |
| polished_andesite_stairs | 1 × andesite → 1 | 6 × polished_andesite → 4 | polished_andesite_stairs_from_andesite_stonecutting |
| polished_blackstone_brick_slab | 1 × blackstone → 2 | 3 × polished_blackstone_bricks → 6 | polished_blackstone_brick_slab_from_blackstone_stonecutting |
| polished_blackstone_brick_slab | 1 × polished_blackstone → 2 | 3 × polished_blackstone_bricks → 6 | polished_blackstone_brick_slab_from_polished_blackstone_stonecutting |
| polished_blackstone_brick_stairs | 1 × blackstone → 1 | 6 × polished_blackstone_bricks → 4 | polished_blackstone_brick_stairs_from_blackstone_stonecutting |
| polished_blackstone_brick_stairs | 1 × polished_blackstone → 1 | 6 × polished_blackstone_bricks → 4 | polished_blackstone_brick_stairs_from_polished_blackstone_stonecutting |
| polished_blackstone_brick_wall | 1 × blackstone → 1 | 6 × polished_blackstone_bricks → 6 | polished_blackstone_brick_wall_from_blackstone_stonecutting |
| polished_blackstone_brick_wall | 1 × polished_blackstone → 1 | 6 × polished_blackstone_bricks → 6 | polished_blackstone_brick_wall_from_polished_blackstone_stonecutting |
| polished_blackstone_bricks | 1 × blackstone → 1 | 4 × polished_blackstone → 4 | polished_blackstone_bricks_from_blackstone_stonecutting |
| polished_blackstone_slab | 1 × blackstone → 2 | 3 × polished_blackstone → 6 | polished_blackstone_slab_from_blackstone_stonecutting |
| polished_blackstone_stairs | 1 × blackstone → 1 | 6 × polished_blackstone → 4 | polished_blackstone_stairs_from_blackstone_stonecutting |
| polished_blackstone_wall | 1 × blackstone → 1 | 6 × polished_blackstone → 6 | polished_blackstone_wall_from_blackstone_stonecutting |
| polished_deepslate_slab | 1 × cobbled_deepslate → 2 | 3 × polished_deepslate → 6 | polished_deepslate_slab_from_cobbled_deepslate_stonecutting |
| polished_deepslate_stairs | 1 × cobbled_deepslate → 1 | 6 × polished_deepslate → 4 | polished_deepslate_stairs_from_cobbled_deepslate_stonecutting |
| polished_deepslate_wall | 1 × cobbled_deepslate → 1 | 6 × polished_deepslate → 6 | polished_deepslate_wall_from_cobbled_deepslate_stonecutting |
| polished_diorite_slab | 1 × diorite → 2 | 3 × polished_diorite → 6 | polished_diorite_slab_from_diorite_stonecutting |
| polished_diorite_stairs | 1 × diorite → 1 | 6 × polished_diorite → 4 | polished_diorite_stairs_from_diorite_stonecutting |
| polished_granite_slab | 1 × granite → 2 | 3 × polished_granite → 6 | polished_granite_slab_from_granite_stonecutting |
| polished_granite_stairs | 1 × granite → 1 | 6 × polished_granite → 4 | polished_granite_stairs_from_granite_stonecutting |
| polished_tuff_slab | 1 × tuff → 2 | 3 × polished_tuff → 6 | polished_tuff_slab_from_tuff_stonecutting |
| polished_tuff_stairs | 1 × tuff → 1 | 6 × polished_tuff → 4 | polished_tuff_stairs_from_tuff_stonecutting |
| polished_tuff_wall | 1 × tuff → 1 | 6 × polished_tuff → 6 | polished_tuff_wall_from_tuff_stonecutting |
| purpur_pillar | 1 × purpur_block → 1 | 2 × purpur_slab → 1 | purpur_pillar_from_purpur_block_stonecutting |
| stone_brick_slab | 1 × stone → 2 | 3 × stone_bricks → 6 | stone_brick_slab_from_stone_stonecutting |
| stone_brick_stairs | 1 × stone → 1 | 6 × stone_bricks → 4 | stone_brick_stairs_from_stone_stonecutting |
| stone_brick_wall | 1 × stone → 1 | 6 × stone_bricks → 6 | stone_brick_walls_from_stone_stonecutting |
| tuff_brick_slab | 1 × polished_tuff → 2 | 3 × tuff_bricks → 6 | tuff_brick_slab_from_polished_tuff_stonecutting |
| tuff_brick_slab | 1 × tuff → 2 | 3 × tuff_bricks → 6 | tuff_brick_slab_from_tuff_stonecutting |
| tuff_brick_stairs | 1 × polished_tuff → 1 | 6 × tuff_bricks → 4 | tuff_brick_stairs_from_polished_tuff_stonecutting |
| tuff_brick_stairs | 1 × tuff → 1 | 6 × tuff_bricks → 4 | tuff_brick_stairs_from_tuff_stonecutting |
| tuff_brick_wall | 1 × polished_tuff → 1 | 6 × tuff_bricks → 6 | tuff_brick_wall_from_polished_tuff_stonecutting |
| tuff_brick_wall | 1 × tuff → 1 | 6 × tuff_bricks → 6 | tuff_brick_wall_from_tuff_stonecutting |
| tuff_bricks | 1 × tuff → 1 | 4 × polished_tuff → 4 | tuff_bricks_from_tuff_stonecutting |
| waxed_chiseled_copper | 1 × waxed_copper_block → 4 | 2 × waxed_cut_copper_slab → 1<br>1 × chiseled_copper + 1 × honeycomb → 1 | waxed_chiseled_copper_from_waxed_copper_block_stonecutting |
| waxed_chiseled_copper | 1 × waxed_cut_copper → 1 | 2 × waxed_cut_copper_slab → 1<br>1 × chiseled_copper + 1 × honeycomb → 1 | waxed_chiseled_copper_from_waxed_cut_copper_stonecutting |
| waxed_cut_copper_slab | 1 × waxed_copper_block → 8 | 3 × waxed_cut_copper → 6<br>1 × cut_copper_slab + 1 × honeycomb → 1 | waxed_cut_copper_slab_from_waxed_copper_block_stonecutting |
| waxed_cut_copper_stairs | 1 × waxed_copper_block → 4 | 6 × waxed_cut_copper → 4<br>1 × cut_copper_stairs + 1 × honeycomb → 1 | waxed_cut_copper_stairs_from_waxed_copper_block_stonecutting |
| waxed_exposed_chiseled_copper | 1 × waxed_exposed_copper → 4 | 2 × waxed_exposed_cut_copper_slab → 1<br>1 × exposed_chiseled_copper + 1 × honeycomb → 1 | waxed_exposed_chiseled_copper_from_waxed_exposed_copper_stonecutting |
| waxed_exposed_chiseled_copper | 1 × waxed_exposed_cut_copper → 1 | 2 × waxed_exposed_cut_copper_slab → 1<br>1 × exposed_chiseled_copper + 1 × honeycomb → 1 | waxed_exposed_chiseled_copper_from_waxed_exposed_cut_copper_stonecutting |
| waxed_exposed_cut_copper_slab | 1 × waxed_exposed_copper → 8 | 3 × waxed_exposed_cut_copper → 6<br>1 × exposed_cut_copper_slab + 1 × honeycomb → 1 | waxed_exposed_cut_copper_slab_from_waxed_exposed_copper_stonecutting |
| waxed_exposed_cut_copper_stairs | 1 × waxed_exposed_copper → 4 | 6 × waxed_exposed_cut_copper → 4<br>1 × exposed_cut_copper_stairs + 1 × honeycomb → 1 | waxed_exposed_cut_copper_stairs_from_waxed_exposed_copper_stonecutting |
| waxed_oxidized_chiseled_copper | 1 × waxed_oxidized_copper → 4 | 2 × waxed_oxidized_cut_copper_slab → 1<br>1 × oxidized_chiseled_copper + 1 × honeycomb → 1 | waxed_oxidized_chiseled_copper_from_waxed_oxidized_copper_stonecutting |
| waxed_oxidized_chiseled_copper | 1 × waxed_oxidized_cut_copper → 1 | 2 × waxed_oxidized_cut_copper_slab → 1<br>1 × oxidized_chiseled_copper + 1 × honeycomb → 1 | waxed_oxidized_chiseled_copper_from_waxed_oxidized_cut_copper_stonecutting |
| waxed_oxidized_cut_copper_slab | 1 × waxed_oxidized_copper → 8 | 3 × waxed_oxidized_cut_copper → 6<br>1 × oxidized_cut_copper_slab + 1 × honeycomb → 1 | waxed_oxidized_cut_copper_slab_from_waxed_oxidized_copper_stonecutting |
| waxed_oxidized_cut_copper_stairs | 1 × waxed_oxidized_copper → 4 | 6 × waxed_oxidized_cut_copper → 4<br>1 × oxidized_cut_copper_stairs + 1 × honeycomb → 1 | waxed_oxidized_cut_copper_stairs_from_waxed_oxidized_copper_stonecutting |
| waxed_weathered_chiseled_copper | 1 × waxed_weathered_copper → 4 | 2 × waxed_weathered_cut_copper_slab → 1<br>1 × weathered_chiseled_copper + 1 × honeycomb → 1 | waxed_weathered_chiseled_copper_from_waxed_weathered_copper_stonecutting |
| waxed_weathered_chiseled_copper | 1 × waxed_weathered_cut_copper → 1 | 2 × waxed_weathered_cut_copper_slab → 1<br>1 × weathered_chiseled_copper + 1 × honeycomb → 1 | waxed_weathered_chiseled_copper_from_waxed_weathered_cut_copper_stonecutting |
| waxed_weathered_cut_copper_slab | 1 × waxed_weathered_copper → 8 | 3 × waxed_weathered_cut_copper → 6<br>1 × weathered_cut_copper_slab + 1 × honeycomb → 1 | waxed_weathered_cut_copper_slab_from_waxed_weathered_copper_stonecutting |
| waxed_weathered_cut_copper_stairs | 1 × waxed_weathered_copper → 4 | 6 × waxed_weathered_cut_copper → 4<br>1 × weathered_cut_copper_stairs + 1 × honeycomb → 1 | waxed_weathered_cut_copper_stairs_from_waxed_weathered_copper_stonecutting |
| weathered_chiseled_copper | 1 × weathered_copper → 4 | 2 × weathered_cut_copper_slab → 1 | weathered_chiseled_copper_from_weathered_copper_stonecutting |
| weathered_chiseled_copper | 1 × weathered_cut_copper → 1 | 2 × weathered_cut_copper_slab → 1 | weathered_chiseled_copper_from_weathered_cut_copper_stonecutting |
| weathered_cut_copper_slab | 1 × weathered_copper → 8 | 3 × weathered_cut_copper → 6 | weathered_cut_copper_slab_from_weathered_copper_stonecutting |
| weathered_cut_copper_stairs | 1 × weathered_copper → 4 | 6 × weathered_cut_copper → 4 | weathered_cut_copper_stairs_from_weathered_copper_stonecutting |
