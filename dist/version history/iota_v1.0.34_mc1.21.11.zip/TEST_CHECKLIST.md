# Iota — current manual verification

Target: Java 1.21.11, base 1.0.34. This is a regression checklist, not a claim
that every item remains untested. The user confirmed the recent Hearts fixes
and the requested recipe adjustments. Retest relevant cases after changes.

## Installation

- [ ] Enable only one Iota base ZIP. Expansions are optional, separate 0.0.1 ZIPs.
- [ ] Trading is vanilla; no old Iota kits or trade overrides are installed.
- [ ] For Trading research, explicitly enable the official experiment when creating the test world; Iota does not activate it.
- [ ] Required Trading/World integration test: compare stock exhaustion and
  restocking with World enabled versus disabled, including daytime sleep,
  night skipping, loaded work time and equal real-time observation windows.
  Measure actual throughput; extended-day impact is not yet a confirmed defect.

## Recipes and Drops

- [ ] Wooden sword: five sticks in a cross; shovel: three vertically. Wooden spear: three diagonally; stone spear: flint tip plus two sticks. Test mirrored layouts.
- [ ] Repeater: R R / SRS / BBB; comparator: TTT / BQB or RRR / SSS / BQB. R redstone dust, S stick, B stone, Q quartz, T redstone torch.
- [ ] Lamp: alternating redstone/glowstone ring, center empty, both arrangements.
- [ ] Leather → four Rabbit Hide; four hides in a square → Leather.
- [ ] Check wheat-to-seeds, log chests, alternative dispenser and reverse ice conversions against DESIGN_DIRECTIONS.md.
- [ ] Table yields: three blocks → six slabs; six blocks → twelve stairs (mirrored); six blocks → six walls.
- [ ] Stonecutter yields: two slabs, two stairs or one wall per block; includes wood. Raw-copper stair shortcuts yield two, while processing Cut Copper first is more efficient.
- [ ] Table recovery: identical vertical slab pair → one block; identical horizontal OR vertical stair pair → one block; six identical walls in two rows → six blocks.
- [ ] Species, moss, wax and oxidation survive recovery. Mixed materials do not match. Test shift-click and repeated cycles.
- [ ] Audited polished, brick, pillar and chiseled finishes are Stonecutter-only; moss addition, waxing, material assembly and Chiseled Bookshelf stay on the table.
- [ ] Recovery recipe unlocks work; test limited crafting if used.
- [ ] Grass seed drops are 8% (statistical check); vegetation and bundle loot remain appropriate.

## World and Hearts

- [ ] Daytime sleep advances three game hours; night sleep reaches dawn; both clear rain.
- [ ] Death preserves inventory and removes one maximum heart, capped at five; every death resets five-minute recovery.
- [ ] Death at the cap refreshes Hunger III for sixty seconds, without further heart loss.
- [ ] Recovery restores all maximum-heart slots together, stops its timer and plays feedback.
- [ ] Relog with lost hearts; test legacy penalty migration and missing saved counters.
- [ ] A lit campfire or soul campfire within four block-grid units accelerates recovery to one minute, with green particles. Multiple fires do not stack.
- [ ] Countdown shows real estimated waiting time; leaving/extinguishing the fire switches to normal rate within one second.
- [ ] Check /function iota_hearts:recover_in_10s and :diagnose when troubleshooting. Maximum-health restoration does not instantly fill empty hearts.

## Optional frozen expansions

- [ ] Test existing mastery XP/rank and discoveries when migrating to the new expansion namespaces.
- [ ] Test level-up rewards, particles/sounds and armor/shield XP; no duplicate milestone rewards after anvil use.
- [ ] Anvil repair, rename and combination keep left-item mastery/custom data; right XP is not added.
- [ ] Base Tools supplies enchantment anvil-cost reductions; installing Tool
  Mastery must not change those definitions. Total operation cost is not uniformly halved.
- [ ] Direct inventory books/equipment register discoveries; closed container contents are excluded.
- [ ] A mastery reward immediately updates shared world_status; lower discoveries do not reduce the recorded maximum.
- [ ] Each expansion works without the other. Native Enchanting Table offers remain unchanged.

## Automated verification

Run node tools/validate-recipes.mjs and build using tools/build-integrated.ps1.
These validate static resources, recipe invariants and packaging, not Minecraft
loading, UI behavior or every possible interaction.

## Anvil ownership migration

- [ ] Base alone applies the reduced enchantment cost definitions.
- [ ] Refreshed Tool Mastery 0.0.1 has no enchantment overrides.
- [ ] Managed netherite tools/weapons repair with Scrap; armor repair remains vanilla.

## Repair ingredients — 1.0.31

- [ ] Hold existing/new wooden, stone and netherite equipment in either hand before using the anvil; test all six families including spears.
- [ ] Stick repairs wood; Flint repairs stone; Netherite Scrap repairs netherite. Old materials no longer match these tools.
- [ ] Item names, enchantments, mastery and unrelated custom data survive repair-property assignment.
- [ ] Armor and netherite smithing upgrades remain vanilla; scrap cannot replace the upgrade ingot.
- [ ] Each unit still repairs up to 25%; the full-repair proposal is not shipped.

## Tools 1.0.32

- [ ] Give a managed item repair_cost=31, name/enchantments/custom data; verify only repair_cost becomes zero, including after an anvil operation.
- [ ] Repeat across hotbar, inventory, offhand and cursor in Survival.
- [ ] Armor/modded items and nested-container contents remain unchanged.
- [ ] Test the marked broken pickaxe per BROKEN_TOOL_PROTOTYPE.md. Ordinary tools must not receive the prototype marker.

## Hearts recoverable XP — revised 1.0.34

Command audit and retained test IDs: TEST_COMMANDS.md. For refreshed expansions,
check the updated help and personal Discovery reset/status (all 41 entries),
automatic re-discovery, shared-world preservation and five Mastery level-ups.

- [x] User confirmed orb replacement after a subsequent death on 2026-11-18;
  the initially reported missing orb was present.
- [ ] Death feedback particles appear once, ten live ticks after respawn,
  including at five lost hearts; moving before they appear follows the player.

- [ ] While maximum hearts are lost, verify subtle red/gray particles once per
  second; campfire proximity substitutes the existing green recovery particles.
- [ ] Crouching immediately shows Full recovery in m:ss; standing clears it.
  Check accelerated campfire time, crouch toggles and full recovery while crouched.
- [ ] With maximum hearts restored, no timer/aura should appear, even if normal
  current health is below full. Recovery completion feedback remains visible.

- [ ] Follow Drafts/HEARTS_XP_RECOVERY.md: 1,000 → 750 + 250 → 1,000; repeated death
  without recovery leaves 563 + a new 187-point orb, forfeiting the old 250.
- [ ] Verify owner-only single claim, zero-XP invalidation, offline/reload state,
  unloaded chunks, all three vanilla dimensions and respawn fallbacks.
- [ ] Confirm texture, dust, pickup sound and existing Hearts/broken behavior.

## Broken-state fixture regression

Tool Mastery feedback revision: use all five level-up fixtures. Expect 12 blue
particles for I–V, plus 32 enchantment particles for III–V; no gold, End Rod or
Treasure-purple effects and no action-bar message. Bigorna (0.40) precedes
level-up (0.40) by eighteen ticks. Death during the delay cancels the second sound.

- [x] User confirmed on 2026-11-18 that normal and enchanted test pickaxes survive and enter broken state. Other scenarios below remain separate checks.

- [ ] Follow Drafts/BROKEN_TOOL_PROTOTYPE.md: exhaust a newly issued test pickaxe by mining and by attacks; repair and repeat.
- [ ] Repeat with Unbreaking, fast actions, swaps and relogs.
- [ ] No normal item gains the technical guard; no fixture duplicates or loses data.
