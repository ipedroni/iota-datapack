# Iota — release history

## Iota 1.0.34 — Minecraft Java 1.21.11

- Removes automatic XP-orb death/respawn chat announcements; manual diagnostics
  remain available.
- Consolidates repair-cost evidence into ../Drafts/Research/ANVIL_BEHAVIOR.md and repository layout
  into DESIGN_DIRECTIONS.md; removes their redundant standalone documents.

- Tool Mastery 0.0.1 feedback revision: every level emits the same 12 blue
  particles; III, IV and V additionally emit 32 enchantment particles.
  Removes per-level gold/End Rod effects and the extra purple Treasure burst.
  Bigorna sound is 0.40, followed eighteen ticks later by level-up at 0.40;
  level-up and reward action-bar messages are removed.

- Development-command audit removes the duplicate Drops container loot helper;
  keeps useful Hearts, XP and broken-tool fixtures. See TEST_COMMANDS.md.
- Refreshed optional expansions 0.0.1: removes four legacy Discovery
  Efficiency-only/manual-enchant functions; fixes personal reset/status coverage
  to all 41 registered enchantments and updates help/diagnoses. Mastery levels,
  rewards and automatic Discovery behavior remain frozen.

- Increases the ongoing lost-heart aura from 5 to 20 particles per second
  (12 red and 8 gray), preserving its size, cadence and campfire substitution.

- Delays lost-heart respawn particles by ten live player ticks (0.5 seconds
  at normal tick rate), following the player's current position. A new death
  restarts the delay; the existing respawn sound remains immediate.

- Hearts recovery timer appears immediately while sneaking and clears once
  when standing. It no longer continuously occupies the action bar.
- Lost maximum hearts produce a restrained red/gray dust aura once per second;
  near a lit campfire the existing green accelerated-recovery effect takes over.
  All ongoing recovery particles stop when maximum hearts are restored.

- Strengthens the XP orb's green/gold aura. Its head remains at maximum
  display brightness without changing world lighting.
- Successful owner recovery triggers a larger green/gold particle burst,
  happy-villager sparks, XP pickup sound and a soft amethyst chime.

- Names the recovery display, hitbox and rendered head `Experience Orb`;
  existing loaded recovery entities receive the name automatically.

- Hearts stores 25% of total spendable XP points per Survival death in one
  owner-only recoverable orb. New deaths forfeit the prior unrecovered amount.
  Zero-XP deaths invalidate old orbs too; successful claims pay only once.
- Safe grounded deaths use the death location; airborne/void and unsafe sites
  fall back to actual respawn. Deferred creation, generation checks and cleanup
  avoid forced chunks and stale payouts across reloads and dimension changes.
- XP-head display, green/yellow dust and click hitbox require no resource pack;
  neither ordinary Player Heads nor the archived Mastery Orb are involved.
- Adds xp/test_setup, xp/diagnose, automated XP checks and an in-game checklist
  in HEARTS_XP_RECOVERY.md. Live behavior remains pending user validation.

- Broken prototype items show a red `Broken` lore line. Repair removes only
  lines carrying the Iota broken-status marker; other lore and names remain.
- Entering broken state plays the vanilla item-break sound with a small burst
  of crit and smoke particles for the owner, once per transition.
- The item model stays unchanged. No resource pack or expansion update.

Historical entries describe their releases, not necessarily current behavior.
Trading prototypes 1.0.27–1.0.28 were discarded in 1.0.29. Expansions are
separate and frozen at 0.0.1; see CHANGELOG_EXPANSION_STATUS.md.

## Iota 1.0.19 — Minecraft Java 1.21.11

- Stonecutter-exclusive finishing: audited bricks, polished blocks, chiseled
  blocks and pillars. Moss addition, waxing and ingredient assembly stay at
  the crafting table; the Stonecutter recipe is unchanged.
- Slabs, stairs and walls remain craftable at both stations. Stair crafting
  yields 12 from six blocks, with mirrored matching; all Stonecutter stair
  routes yield two, including raw-copper shortcuts (formerly four).
- Adds 26 wooden Stonecutter recipes and 203 recovery recipes with unlocks:
  vertical slab pairs, horizontal/vertical stair pairs, and six-wall batches.
- Adds wheat-to-seed, reverse ice conversions, log-to-chest crafting, and
  alternative dispenser, repeater and redstone lamp recipes.
- Short/tall grass wheat seed probability is 8%.
- Heart-loss sound uses beacon deactivation instead of the descending bass
  sequence. Existing heart-loss particles remain.
- Integrated packaging merges module resource filters. Documentation is
  consolidated and the repeatable recipe validator checks material cycles.

Validation is static. Loading and gameplay testing remain manual.


## Iota 1.0.20 — Minecraft Java 1.21.11

- Distinct release filename to distinguish the updated recipes from earlier 1.0.19 copies.
- Wooden spear: three sticks diagonally. Stone spear: one flint tip and two sticks diagonally.
- Repeater: sticks in upper corners, redstone across the middle, stone across the bottom.
- Redstone lamp: alternating glowstone/redstone ring, center empty; either dust may occupy the corners.
- Automated validation now explicitly checks all twelve wooden/stone equipment recipes for forbidden ingredients.
- Includes the building and recovery changes from 1.0.19. No other gameplay changes.


## Iota 1.0.21 — Minecraft Java 1.21.11

Consolidates the recipe adjustments manually validated by the user.

- Wooden sword: five sticks in a cross, including the center.
- Wooden spear: three sticks diagonally; stone spear: flint tip and two sticks.
- Repeater: R R / SRS / BBB.
- Comparator: TTT / BQB, with an empty top row allowed; alternative RRR / SSS / BQB.
- Lamp: alternating redstone and glowstone ring, empty center, either arrangement.
- R = redstone dust, S = stick, B = stone, Q = quartz, T = redstone torch.
- Retains building and reclaiming changes from 1.0.19.

Validation: user confirmed the requested recipe tests. Static checks passed;
424 normalized explicit-ingredient shaped patterns had no different-output
collisions, including horizontal mirroring and shifted grid placement.
This collision check excludes tags, ingredient alternatives and shapeless recipes.
No Minecraft server load test was run.


## Iota 1.0.22

- Recipes: one leather crafts into four rabbit hide, reversing vanilla leather assembly.

- Six-module base, with two separately installable optional expansions.
- Iota Expanded: Tool Mastery uses namespace iota_exp_tool_mastery.
- Iota Expanded: Magical Discovery uses namespace iota_exp_magical_discovery.
- Source folders moved to expansions/; generators and hooks updated.
- Persistent scores, item fields and legacy storage/lore IDs retained.
- No changes to recipe balance or enchantment availability.

Remove the former integral ZIP before installing the base and desired expansions.
New command examples: /function iota_exp_tool_mastery:status and
/function iota_exp_magical_discovery:status.

- Hearts: heart-loss feedback now uses 24 damage-indicator particles around the torso, replacing faint ash. Sound unchanged.


## Iota 1.0.23

- Hearts: lit campfires and soul campfires within four block-grid units grant 2x recovery speed; no stacking, one-second proximity refresh.
- Magical Discovery: automatic non-destructive scanning of direct inventory enchantments, including stored book enchantments, armor and offhand.
- Shared discovery records include all non-curse enchantments and maximum levels. Approved initial enchantments are initialized at level I.
- Nested containers excluded; native enchanting offers remain unchanged pending a separate prototype.
- No dependencies installed.


## Iota 1.0.24

- Hearts: campfire recovery increases from 2x to 5x. Five minutes of recovery finish in approximately one minute beside a lit fire.
- Eight happy-villager particles around the player each second while campfire recovery is active.
- Radius, lit-fire requirement and no-stacking rule unchanged.
- No expansion gameplay changes.


## Iota 1.0.25

- Hearts: recognize the saved iota_life_death:death_penalty modifier from before the namespace rename.
- Applying or recovering health removes all three known Iota death-penalty IDs before rebuilding the current modifier, preventing stacked legacy penalties.
- Existing loss count and timer are retained during migration. Other max-health modifiers and base health are untouched.
- Expansions remain frozen at 0.0.1.


## Iota 1.0.26

- Hearts checks persisted penalty modifiers before clearing scores, and reconstructs missing loss state from known modifiers. Missing timers are initialized.
- Known legacy penalty IDs are normalized before recovery. Unrelated health attributes are untouched.
- Campfire countdown shows estimated real remaining time at current speed: 1:00 at the beginning, rather than five accelerated minutes.
- Display updates once per second independently of accelerated timer increments.
- Adds /function iota_hearts:diagnose for total/base health, saved attributes and timer scores.
- Unknown penalties/base-health changes require diagnosis; this patch does not overwrite max-health base or remove unrelated modifiers.


## Iota 1.0.27

- Adds Trading, covering all thirteen employed villager professions.
- Replaces emerald-paying purchases with 41 themed offers; preserves other sales.
- Butchers buy eggs, carrots, potatoes, beetroot and milk; sell cooked meat. Milk payment includes the consumed bucket.
- Purchases unlock at levels 1–3 and have eight uses per restock; stock is also refreshed on profession/level transitions.
- Original offer backup retained per villager. Existing villagers are updated as loaded.
- Wandering Traders, unemployed villagers and nitwits unchanged.
- Expansions remain frozen at 0.0.1.


## Iota 1.0.28

- Replaces Armorer, Toolsmith and Weaponsmith sales with five cumulative offers each.
- Eleven multi-item kits open by holding use for 0.8 seconds; four single-item sales deliver equipment directly.
- Kits use non-stackable named paper and item-consumption events, preserving unrelated items; overflow uses vanilla /give drops.
- Diamond/netherite equipment removed from these three sale catalogs. Purchases unchanged.
- Existing merchants update once using catalog revision 2; original backups retained. Other professions' sales unchanged.
- No custom texture/resource pack required; expansions stay frozen at 0.0.1.


## Iota 1.0.29

- Removes the Trading prototype, purchase overrides and equipment kits.
- Discards all earlier Trading design decisions; future study starts from vanilla.
- Base returns to six modules. Other modules unchanged; expansions remain frozen.

## Iota 1.0.30

- Moves 43 enchantment anvil-cost definitions from Tool Mastery to base Tools without changing values.
- Refreshes Tool Mastery 0.0.1 packaging only to remove these definitions.
- Audits repair materials and XP penalties; no new repair-material or prior-work changes.

## Iota 1.0.31

- Tools assigns dedicated repair ingredients to wood/stone/netherite pickaxes, axes, shovels, hoes, swords and spears in either hand: Stick, Flint, Netherite Scrap.
- Other item components, crafting/smithing ingredient tags and armor repair materials are unchanged.
- Native quarter-durability repair, XP cost growth and level cap remain; full repair and broken-item retention are not implemented.

## Iota 1.0.32

- Tools clears repair_cost on 42 managed vanilla tools/weapons across accessible player slots. Other item data is untouched.
- Adds an opt-in broken diamond-pickaxe state fixture; ordinary tools still follow native breakage.
- Hard anvil limit, 25% material-repair amount and armor remain unchanged. Expansions remain frozen.

## Iota 1.0.33

- Opt-in broken-tool prototype now intercepts native wear on marked test pickaxes using a technical item_damage enchantment and two-point reserve.
- Mining/attacks lead into broken state; native repair restores function, retaining the guard for later cycles.
- Adds Unbreaking test variant and fixes missing .mcfunction extension on the test command.
- Normal tools, repair fractions and frozen expansions unchanged.
