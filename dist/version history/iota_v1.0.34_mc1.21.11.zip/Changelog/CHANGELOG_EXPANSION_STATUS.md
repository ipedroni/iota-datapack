# Iota Expanded — frozen at 0.0.1

Tool Mastery and Magical Discovery are paused after the discovery-register
milestone. Future active development targets the Iota base.

Magical Discovery records non-curse maximum levels from direct inventory items
and books, preserving the items. Closed container contents are excluded.
Tool Mastery reward hooks update the shared world register immediately; the
hook is optional when Discovery is absent. Higher recorded levels imply lower
levels. Initial level-I entries remain available in the register.

Inspect with /function iota_exp_magical_discovery:status or :world_status.
Native Enchanting Table offers are NOT restricted or refreshed by this register.
The automatic scanner can rediscover items after a personal reset; personal
reset does not erase the world register.

Install the base plus either, both, or neither expansion. Remove older expansion
ZIPs before installing 0.0.1. Existing scoreboards and item data are retained.

Manual freeze checks: obtain an enchanted book; verify world_status; earn a
Tool Mastery level-up enchantment and verify its level appears immediately;
repeat at a lower level and verify the maximum is unchanged. Test Tool Mastery
without Discovery. Static checks do not replace in-game verification.

## Native enchanting interface boundary

Approved feedback revision on 2026-11-18: all five mastery level-ups share
12 blue particles. Levels III–V add 32 enchantment particles. There are no
extra gold, End Rod or Treasure-purple effects. Progression/reward rules remain
frozen; replace the Tool Mastery 0.0.1 ZIP to receive this visual adjustment.
The anvil sound plays at 0.40, then player level-up at 0.40 eighteen live ticks
later (900 ms at normal tick rate). Death cancels the pending sound. No mastery
level-up or reward messages are sent to the action bar.

Timing evidence: official 1.21.11 asset index 29, `random/anvil_use.ogg`
(SHA-1 f789417f40eee40b4d8ae6422d78f0ce06a94211). The Vorbis stream has
55,126 samples at 44,100 Hz: 1.250023 seconds at pitch 1, or 1.000018 seconds
at the configured pitch 1.25. Eighteen ticks starts level-up about 0.1 seconds
before the anvil file ends at normal game speed. Actual mixing/tail audibility
can vary with the client; no decoder software was installed to measure this.

Command maintenance on 2026-11-18 refreshes both 0.0.1 ZIPs without resuming
feature development. Legacy Efficiency-only register/application POC functions
are removed. Personal status/reset now cover all 41 scanner enchantments;
shared discoveries remain untouched. See [Test Commands](../TEST_COMMANDS.md).

The discovery register does not filter native offers. Static registry/tag files
are not dynamically rewritten by scoreboards; globally selecting enchantment
IDs also does not independently cap each level just for table offers. Changing
vanilla max_level would alter global definitions. Custom interaction or external
support would require a future separate prototype; development remains frozen.
Do not grant an enchantment and strip it afterward as a substitute for gating.

## Anvil behavior

See ../Drafts/Research/ANVIL_BEHAVIOR.md for verified resource changes, vanilla persistence findings
and limits. Enchantment anvil-cost overrides were relocated to base Tools in 1.0.30.
The refreshed Tool Mastery 0.0.1 ZIP no longer includes those definitions;
its progression remains frozen. Replace older copies to avoid stale overrides.
